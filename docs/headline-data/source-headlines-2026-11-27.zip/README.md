# Source headlines export

Generated: 2026-11-27T03:34:08.826Z
Cache ref: origin/cache-data
Digest date: 2026-11-27

Format: `SOURCE: name` followed by one newest-first headline per line. Related sources continue directly after the previous source block; blank lines separate source-groups in the relation tree. `99-unmatched-sources.md` uses single line breaks throughout because no curated relation is known.

Input stories from digest.json, stories.json, raw-new.json, and currents-api.json: 20161; after id/URL dedupe: 11534 (8535 duplicate ids, 92 duplicate URLs).
Sources: 695; matched to relation tree: 522; unmatched: 173; unique headlines per source: 11461.
Cross-member relation-tree sources are emitted only at their first depth-first tree position, so no source line repeats.
