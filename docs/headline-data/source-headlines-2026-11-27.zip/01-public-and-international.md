SOURCE: BBC
New Zealand's ruling coalition falls short of parliamentary majority by one seat
Newspaper headlines: 'Scores' of Labour MPs oppose Rosebank and 'Shameless Huw'
From £250 job to £9,000 bill: Inside the rogue trader networks scamming customers at scale
I spend £200 a month on fancy meals by myself - would you dine solo?
The young hikers finding friendship and fresh air offline
Met Police ruined my life, says Kenyan man wrongly sentenced over attack on UK couple
Death-sentenced Sheikh Hasina's planned return puts Bangladesh on edge - and India in a bind
Australia's sandpapergate probe to also include 2017-18 Ashes against England
NHS boss warns of 'horrible spike' in flu as hospital admissions surge
'Priceless' Duran proves 'the man' but is he papering over cracks at Celtic?
Inside the control room feeding your weather app
Why is there a shortage of 'wizard' elevator mechanics?
Hearts' European hopes hang by a thread but Vrancken proud
UK to pay 'participation' fee to deliver EU deals
Asia made a big AI bet on Nvidia. What happens now?
My dad's watch stopped the moment he died - I found it in the ashes of Hong Kong tower fire
My partner has ME and it's kept her in bed for five years
'We feed and wash her': Severe ME leaves woman bedbound for five years
US too focused on Middle East and not pushing Russia hard enough, Zelensky tells BBC
Bournemouth 'allowed to dream' as fans book Europa League final hotels
Watch: Man and dog narrowly escape powerful king tide in Oregon
Fury 'never received' schizophrenia diagnosis
Taylor and Lewis lose all five pairs matches on return
The baby who gives Christmas tractor run special meaning
Watch: Roofs torn off and streets under water as severe weather hits US
Huntingdon train attacker found guilty of all 14 counts of attempted murder
Chief medical officer Gregor Smith resigns on mental health grounds
Weekly quiz: Which music icon's house did Miley Cyrus get married at?
Drug rape husband says wife 'would have been terrified', court hears
Schools given emergency action plans for power outages and extreme weather
Did Scotland's departing chief medical officer actually do anything wrong?
The government unit with millions to spend on socials
When will Poundland shops close? Five key questions answered
GB win decider to reach Davis Cup semis for first time since 2019
Germany's Freigang given 16-month ban over drugs test issues
Huw Edwards gives first interviews since child abuse image conviction
Burnham says UK net migration now under 'sufficient' control
Watch: Sadiq Khan proud of 'various identities' in Lords maiden speech
Burnham joined by former PMs at Ann Widdecombe service
Fofana has apologised for interview - Alonso
Mandelson kept shares as ambassador despite conflict of interest fears, documents show
Italy says two citizens killed in Iranian strike in Kuwait
Students vote to retain university campus' historic name
Nearly 100 Labour MPs including ministerial aides oppose Rosebank oil field
India's Pant joins New Zealand club match under false name
Nine injured, three critically, after Bangkok oil refinery explosion
Princess of Wales drops in on arts project in the Borders
Fireball steals the show during Thanksgiving drone display in Indiana
Russell says Verstappen's criticism 'quite amusing'
Scotland's chief medical officer Gregor Smith resigns on mental health grounds
Irish runner Beggs wins award for Boston fair play
Skupski and Patten win to send GB into Davis Cup semi-finals
Selby faces tough UK Championship opener, with Allen set to feature
Could the Huntingdon attack have been prevented?
Violent knifeman told doctor his psychosis drugs weren't working days before train attack
Former England scrum-half and commentator Starmer-Smith dies aged 81
How the train attack unfolded - carriage by carriage
Diesel tanker carrying up to 7,000 tonnes capsizes near Ibiza, killing one
Lammens - the Man Utd goalkeeper under scrutiny like never before
UK net migration at lowest level since 1997 as asylum claims also fall
Tommy Robinson charged with failing to give phone Pin code to police
Gérard Depardieu to stand trial for alleged rape of actress in 2018, court rules
Pregnant US inmate escapes in prison vehicle after medical appointment
Ministers hiding behind data protection on Sir Galahad bombing files, says veteran
Norse Atlantic suspends all flights as it faces potential collapse
School plagued by leaks could be demolished just 10 years after opening
Private dentists too expensive for millions, watchdog warns
Millions of people to see average monthly mortgage payments rise by £100
Number of young people out of work or training still stubbornly high, data shows
Simon Jack: Is Poundland's US owner to blame for its collapse?
Heathrow third runway plans 'should be grounded'
UK reservists contacted as 'threat environment' rises, Streeting says
Not even making a 12-man bench - what next for Garnacho?
Burnham caught in north-south satellite deal battle
Cost of living roadshow highlights support on offer
Egyptian authorities arrest motorist over tanker crash that killed 31
New boss appointed to lead Travelodge
Government's antisemitism adviser launches investigation into BBC
Every day is living hell, says dad of boy, 2, murdered by grandparents
Faldo urges LIV stars to 'chip in' for unpaid firms
MP says her likeness used in deepfake AI porn
Drivers over 70 face eye tests every three years under new plans
Hope for millions as cheaper HIV prevention jab reaches Africa
440 players, three days, one venue - the Nations Championship logistics logjam
Myanmar refuses to comply with parts of ICJ genocide ruling
Hamas political official and wife among eight Palestinians killed in Israeli strikes on Gaza
Politics and peek-a-boo in Australian parliament as senator brings baby to work
UK signs £8bn deal to ensure submarines are 'warfighting ready'
Watch: Alaskan flying team airdrops Thanksgiving turkeys to remote communities
Deadly fire erupts near Cairo killing dozens of people
Why is it so hard to get ADHD or autism diagnosis on the NHS?
Two screenings of Pakistani TV show cancelled in India after backlash
Government preparing to publish more Mandelson papers
Guinea orders residents to clean up the capital months after deadly rubbish dump collapse
Constitutional experts challenge PM's rejection of more Welsh powers
FedEx plane overshoots Miami runway, causing brief suspension of flights at airport
Thirteen dead as mine disaster highlights illegal hunt for gold
Why KMI Panel frustrates referees too - and impacts their salary
DR Congo demands answers over Ugandan general's threats
Knee surgery rules Sinner out of Australian Open
Who am I? Plus today's other quizzes
Bellingham's backing of reporter praised after viral clip
Hundred adds semi-finals from 2027
Parents cutting basics at Christmas, charity warns
Manic Street Preachers frontman feels 'more pressure' playing in Wales
Desperate appeals from women on death row in Iran after protests
Schools built using private money cost executive an extra £1bn
Government set to double spending on social media unit to £25m
I regret surviving the e-bike fire that killed my family
Watch: BBC confronts German man suspected of supplying migrant gangs with small boats
German boat dealer suspected of supplying Channel smuggling gangs, BBC finds
UK government set to publish new treaties agreed with EU
As foreign troops withdraw from Somalia, could al-Shabab take over?
California braces for potential Thanksgiving flooding as storms threaten US coasts
Newspaper headlines: 'Six-day streak "smashes" global temperature record' and 'Gord speed'
Frustration reigns for Pochettino in chaotic start to Man Utd job
The US pastor who wants to see women's right to vote overturned
Spanish elections: What you need to know and what's at stake
France's political mainstream risks presidential vote debacle with no clear candidate
US Army says controlled blast of explosives in Iowa was 'huge success'
Divots, howlers and bad decisions - dissecting Man Utd's draw in Lisbon
Has global jihadism failed, or is it simply changing shape?
What UK season changes mean for you
BBC launches partnership with Met Office for weather coverage
Expect fewer frosts and more hot days as UK seasons shift, says Met Office
US approves SpaceX plan to send a million data satellites to space
Stalking law simplified to become one offence
Guitar wars - the transatlantic battle over the Stratocaster
Macy's postpones Thanksgiving parade due to weather
Motorcycle rider who took stunning cricket catch found
How Isak and Wirtz are becoming Liverpool's 'big-game players'
A renovation to upgrade these Hong Kong homes ended in an inferno that killed 168
'All coming together' - Isak repaying Liverpool faith
Angelina Jolie and Brad Pitt settle legal battle over French winery
Long waits 'a tragedy' as thousands seek ADHD and autism assessments
Lammens howler denies Man Utd victory against Sporting in incident-packed game
Duran Duran guitarist Andy Taylor dies aged 65
Thirty-one killed in massive fire as fuel tanker crashes on Cairo highway
Andy Taylor: Duran Duran's livewire guitarist who was a true Wild Boy
Six members re-elected to Sark's Chief Pleas
Isak scores twice as clinical Liverpool beat Brugge
North Korea expels Swiss diplomat in sanctions row
Regulator chief 'has stomach' to face Man City
Hotels need 'minimum standards' to keep women safe
Body found in search for missing 20-year-old woman
Moment Nasa spacecraft hit asteroid - and what happened next
Israeli judges recommend dropping most serious charges against Netanyahu
MP calls for action after her likeness used for AI porn deepfakes
Farage helps launch new campaign against the UK rejoining the EU
UK Town of Culture bid withdrawn in Strabane after it causes 'great division'
Martin Lewis' tips on staying warm this winter
Poundland collapses putting 11,000 jobs at risk
Gordon Ramsay to host Top Gear as show revived after Flintoff crash
US stocks fall further as fears over AI intensify
Man and daughter who dumped body in canal jailed
Formula 1: Williams exceeded cost cap by £627,000
'Top Gear is back': Gordon Ramsay announced as new host
Images of asteroid targeted to test Earth's defences reveal stadium-sized crater
Energy price increase 'could put me in hospital'
GB, France and Germany launch new swimming competition
Scots react to news of rising energy prices
'Best midfielder in the world' - where does Bellingham rank?
Badenoch challenges Burnham over university fees for EU students
EU offers UK fresh deal on 'Made in Europe' scheme
Badenoch presses PM over university fees for EU students
Confusion and anger - Yoro red card rescinded, but row goes on
Why has Poundland collapsed and what happens next?
Greatest catch ever? Man on motorbike takes incredible grab
US announces new tariffs on host of countries including China
Colombian police storm supermarket to free 20 held hostage for 17 hours
Leicester no longer for sale as owner looks to future
NHS Grampian surgeon operated on patient while recovering from endoscopy
Stockdale back as Ireland make two changes for Australia game
Fisilau starts as England change five for All Blacks rematch
South Africa's Ramaphosa wins court battle over impeachment threat
Wife drugged and raped by husband asked police if she was to blame, mass-sexual offence trial hears
Canadian astronaut welcomes baby girl from space station
Two men charged with trying to steal cufflinks and clock from Royal home
Reality TV star backs extending sex education to 18
Sacked police officer showed 'all the hallmarks of predatory behaviour'
How much has the Iran war put up your energy bills?
Five Russian military jets hit in airfield strike, says Ukraine
No 10 does not rule out inviting back influencer at centre of video row
Fuel price hike will make life 'almost impossible'
Why four-time MVP Rodgers may have played last NFL game
Nuclear test veterans will get full truth, says Burnham, as he confirms independent panel
Israeli strike kills senior Hamas security official and family in Gaza City
Raheem Sterling given suspended jail sentence for dangerous driving and nitrous oxide possession
Energy bills to rise by 26% from January after gas prices surge
Why are bills going up?
None of UK government's £2.5bn steel package spent in Wales, figures show
Raheem Sterling - from national icon to suspended jail sentence
Veteran Nigerian Nollywood actor Pete Edochie dies aged 79
Russia's own figures show it has lost nearly 500,000 people in Ukraine war
'I only use the washing machine on a Sunday' - how we're keeping our energy bills down
Boy, 3, died after choking in nursery, inquest hears
Hundreds complain about I'm A Celebrity after Mariella Frostrup called AJ Odudu 'aggressive'
Huawei found guilty of stealing US trade secrets but acquitted of racketeering
Why has China sent the first Pakistani astronaut to space?
EA adds AI-generated John Motson to FC 27 video game
Protesters call on Israel to free Palestinian student held without charge
Zoe Kleinman: Nobody is irreplaceable - unless you're Jensen Huang
Missed chances to save boy, 2, murdered by grandparents despite dad's concerns, review finds
Interest rate affect on Guernsey's housing market
What will the energy cap changes mean for my bills?
Ministers ask public for views on changing age of consent
Three reasons why your energy bill is so high
Two children among six dead after plane crash off Mississippi coast
Lies, a disguise and surfboard bags: How a jealous Sydney policeman tried to cover up double murder
Blade Runner 2099 not just about AI, say star Hunter Schafer and series creator
What does it take to make a world champion dumpling?
Pupils served life lessons from pickleball-playing pensioners
A question of trust in the NHS could be Swinney's most dangerous political moment
Asian women 'never heard' on health, says director
Festive market cancels bookings after backlash over misleading AI images
UK sent sex offender refugee to African country in undisclosed deal
Moment Chinese space mission lifts off with first Pakistan astronaut aboard
She spent decades as an FBI agent and this is the case she could not let go
Thomas Markle charged in US for possessing child sex abuse images
The rising cost of putting food on the table in India
Shot in the face at 15: The lives shattered by Cameroon's decade of conflict
Clashing political visions reflect a divided Spain ahead of election
My family died in Ukraine and my mum blamed Zelensky's troops - the truth is complicated
Why tiny cars are taking off across Europe
Third of young Brits have never had sex, but many are sexting and watching porn
Is China behind a wave of AI fake videos targeting Taiwan?
These North Koreans say they were spied on, beaten and jailed for being Christian
Nuclear test veterans speak to BBC about 'search for justice'
Watch: Flock of turkeys chases woman on Massachusetts pavement
Business Daily
Tech Life
How can we better understand neurodiversity and diagnoses?
US attorney general dodges questions about Nvidia investigation
DUP accused of 'anti-Irish bigotry' as education bill blocked
Faisal Islam: Fears over the AI boom haven't gone away
GP surgery suspends routine appointments due to 'tsunami' of demand
Watch: Would you let Meta's AI agent run parts of your life?
Indian government has 'lost the plot', says 'cockroach' leader barred from UK flight
'I miss being on court' - Sinner has 'minor surgery' on knee
Sacked London Pride boss given suspended prison sentence
Man charged with murder of missing 20-year-old woman
Businesses supporting Ukraine told to 'act now' to protect against Russian sabotage
Disability benefit review calls for closer link with claimant costs
Weak and immature management putting patients at risk at failing health board, review finds
Reform ends Senedd boycott
Reform breaks boycott of Welsh Parliament with call to remove presiding officer
Sheehan out of Wallabies Test after two-game ban
Former police chief inspector jailed for rape
Girl, 14, repeatedly stabbed by boy told friends he 'begged' to see her, murder trial hears
Nephew demands reforms after uncles killed by schizophrenic man released from custody
Klopp advice and Iraola confidence boosts Wirtz
Senegal reinstated as winners of the 2025 Africa Cup of Nations after appeal upheld
Inquiry into Birmingham housing scheme 'exploitation' after BBC investigation
Andy Burnham defends inviting influencers to Downing Street
Zimbabwean convicted in South Africa of trying to fight in Ukraine
Yoro red card overturned, but refs' chief Webb backs decision
French ex-President Sarkozy and wife Carla Bruni to face trial
Four generations of a family working in one factory
DR Congo says military aircraft missing as rebels claim to shoot down plane
Nurses vote for industrial action over pay
Huntley murderer handed new whole life jail term
'I'm proud of it': Killer confesses after murdering Ian Huntley
Record 5,200 heat-linked deaths estimated in England this year
Public are sick of 'out of control' welfare system - Tories
Two arrested on suspicion of burglary at Prince and Princess of Wales's Norfolk home
Tories accuse Burnham of turning No 10 into 'joke' after influencer video row
'There was no warning sign' - calls for more education to reduce suicide in men and boys
Catherine's cancer documentary makes me feel less alone, says Strictly's Amy Dowden
Southport survivors' parents 'disgusted' by school recovery funding
Israeli air strike kills Hamas internal security chief in Gaza
Land mine casualties soar in Syria, two years after war
Sooryavanshi, 15, breaks sixes record by scoring 204 off 53 balls
Man baffled after accidentally travelling to Spain on wife's passport
Tory plan to sell off London's Victorian jails to raise £1.4bn
Key takeaways from the Timms review into Pip disability benefit
Baby P's mother given open prison recommendation
'The rest of the world noticed' - Welshman Donald demolishes Aussies
Frustration after generator failure forces school to close again
Russian governor detained in rare criminal case against regional leader
Prince of Wales makes first ever Downing Street visit
'Life is not infinite': Princess Catherine in new documentary
Car bomb tears through Colombian city wounding more than 20
Prince William meets Burnham on first Downing Street visit
What is Pip?
Pope Francis' diary reveals claims he saw the devil three times
Nato chief vows defence against space threat after Russian nuclear satellite reports
From dancing on the Tube to being sectioned: Sabrina Bahsoon on her psychosis misdiagnosis
Helpful but awkward: My week with Meta's Muse ahead of its UK launch
Watch: Moment troops raid home and capture Mexican drug lord
Watch: Delia Smith says data centre will be bad for county
Bangladesh's ex-PM Sheikh Hasina says she plans to return on 16 December
I'm angry my Jehovah's Witness mum died - she didn't want to 'disobey God'
State failing to keep public safe, warns victims' commissioner
Cheers and applause as Jensen Huang returns to Nvidia office
Chris Mason: Can Burnham turn volume down on EU debate?
No 10 North will face greater scrutiny as Burnham's 10-year plan looms
The shake-up facing renters as a new kind of landlord emerges
King Charles and Elton John pay tribute to Australian music legend Molly Meldrum
BBC secret filming shows dog breeder selling sick puppies for £2k each
Dad who discovered daughter's murder on Facebook feels ignored by South African police
I pay £250 a month for someone else to do my life admin - it's worth it
Why I don't always tell potential employers I'm dyslexic
US to blacklist Asian AI firm Megaspeed after Nvidia scandal
Outrage after ICE arrest father and daughter at Seattle airport
'Life is not infinite': Catherine talks about 'mortality' in new documentary clip
Gisèle Pelicot 'humiliated' after nude photos sent to media to promote book
What strike on Russian ship in Libya says about spread of Ukraine war
US rapper Don Toliver postpones O2 arena show after Manchester evacuation
My approach to EU is pragmatic, says Burnham
Burnham does not view Wales as an equal nation, claims first minister
Watch: Experts react to Jensen Huang's return to Nvidia
Woman faces hour-long drive to give birth as hospital suspends maternity services
Iranian authorities flog singer who performed without hijab, lawyers say
Pip assessments need 'fundamental overhaul', report to say
England's Freeman in contention for All Blacks rematch
Nvidia shares up nearly 33% and tech stocks rally after Jensen Huang returns
What failure of COP31 reveals about a divided world
Teenage girl stabbed multiple times by 14-year-old boy, murder trial told
Faisal Islam: Why Jensen Huang proved too big to fire
Israeli attacks have turned Gaza into 'toxic wasteland', Oxfam says
'A forced decision' - Gallagher retires from MMA
'People were screaming in pain' during Co-op Live evacuation
'No-one's coming to save us' - but how can Man Utd save themselves?
When is the Euro 2028 qualifying draw?
Jury out in train stabbing attempted murder trial
Mother and son riot ringleaders jailed for 'disgraceful' acts
Raya to miss Dortmund game but injury 'not serious'
Prominent Zimbabwean preacher arrested on sexual assault allegations
Mexican soldiers attacked in wake of drug lord's arrest
Nvidia reinstates CEO after affair with alleged spy
How Ukraine attacked Russian ships in Libya
Friends were wary of me holidaying with my ex's former wife and kids - but our blended family works
Nigeria's president says he is also hit by water and power cuts plaguing country
England's tearaway quick bowler reinvented as a top-order batter
'They were all asleep': Ukrainians describe deadly overnight Russian apartment strike
Burnham rejects EU deal criticism from former PMs
GTA 6 hacker released on licence with warning 'don't let this happen again'
Welsh Greens back plan to separate from English party
Welfare cuts: What's been happening with Pip and universal credit?
India pledges $1.6bn to Nepal in reset of ties
Two men admit sex offences in drugged wife case
Flights cancelled in Belgium due to cost-of-living strike
'I want to destroy capitalism, not France': On the streets with the French ultra left
'Right on time' - Kildunne on Quins exit stories
Striking doctor says they are advocating for the health service
Search and rescue teams race against time to find survivors after Nigeria boat tragedy
Mild Atlantic air collides with cold air across the UK, a recipe for some snow
Next data accessed in cyber breach
Paralympian charged with 11 counts of rape
Ukraine shares video of strikes on Russian ships off Libya
Capita shares plunge 70% as boss quits after civil service pensions failure
Antibiotics saved my life - then nearly killed me
Parents in Wales 'paying £1,000 for transport to school in England'
'I was left broken' - Woman taking civil case against 'church that failed her'
South East Water reports loss after supply issues
Poundland is facing collapse - what's gone wrong?
Catering giant to switch main share listing to US in further blow to UK
Tyson Fury reveals schizophrenia diagnosis
Who is taking part in France's recent street protests?
Kenya and DR Congo agree to restore ties after tensions over conflict
De Villiers claims ball-tampering from first 2018 Test
Watch: Coughing, confusion and boos as Co-op Live concert cancelled
Witness History
Five takeaways from the failed climate talks COP31
Can AI improve breast cancer diagnosis?
Inside the heated debate over Scotland's data centres
Househunter swaps Australia for Wales' most affordable town - where locals are struggling to buy
What six grazing horses tell us about England's housing crisis
Energy bills will soar - here's how you can ease the pain
Can AI spot breast cancer earlier? NHS launches world's largest trial to find out
San Francisco is enjoying an AI boom, but worries about a crash are growing
Boy, 7, pulled alive from rubble hours after Russian strike in Ukraine, rescuers say
A 'wow' player - why Ngumoha is already a Liverpool game-changer
Burnham to tell MPs 'landmark' EU deal could make next decade 'much better'
'Danger seems greater all the time': Ukrainians search for missing after Russian strikes
Thitikul wins third title in a row at LPGA finale
'World's best could've lost 4-0' - but should Man Utd have done more at Anfield?
Miley Cyrus marries Maxx Morando in California ceremony
Chaotic week, nightmare start and huge reality check for Pochettino
Price wins Grand Slam to end wait for major title
Pepe did not injure eyes staring at sun, say Villarreal
Man Utd plotting Toney move - Monday's gossip
Explosion on Russian ship at Libya port caused by suspected drone attack, officials say
Democrats win largest House majority since 1992 after flipping North Carolina seat
Alcaraz outplays Zverev for first ATP Finals triumph
Bundesliga
McBurnie stoppage-time double earns Hull win over 10-man Brighton
Ngumoha stars as Liverpool thrash 10-man Man Utd
What's next after no deal at COP31 climate talks?
US Army to detonate tonnes of unstable explosives in Iowa despite court order
COP31 fails to reach major climate deal as talks expose deep divisions
Long-lost Chevalier landscape found in charity shop
Russell Brand's wife says she'll honour prison rules after message row
RAF's next fighter jet could be last crewed combat plane, air chief says
Three killed and dozens missing after fire at Indonesian factory
Boss of British Gas owner Centrica 'hugely concerned' over impact of soaring energy bills
BBC apologises after noise disruption during Strictly
Tories would scrap Burnham's deal with EU, deputy leader says
Man dies in M42 crash near Birmingham Airport
School wins mental health and wellbeing award
Theresa May 'aghast' at Burnham's EU plans and says 'Brexit is done'
Health expert's advice on checking your baby's sleeping bag
My son donated his body to science and became a 'silent teacher'
Will the Scotland-England border landmark star ever shine?
Why are so many more young Scots claiming disability benefits?
South Korea education minister resigns over exam cheating scandal
Joanna Page says she nearly messed up Gavin and Stacey audition
Men's fishing group is the hook to better mental health
Midwives told to expect fewer jobs as recruitment drive is paused
MP criticises Guernsey and Jersey company ownership register plans
From a village bakery to headlining Glastonbury: How Harry Styles became a star
Widow fears losing home built by husband after support payments end
Italian jeweller and businessman Paolo Bulgari dies aged 89
Village vote 'sent powerful message', say politicians
'Move on!' Former PMs pile in with advice for Andy Burnham, but will he listen?
The real people finding their work copied and stolen by AI characters
BBC apologises for 'any offence caused' by Strictly noise disruption
Nigerian youth have shown their power in the past - why aren't they shaping this election?
How a teen gamer and his mother helped rescue a missing girl
From pit-stops to go-to destinations: The transformation of service stations
Employers are being asked to give interview feedback - here's what applicants want
Why Nicola Coughlan's new drama might leave viewers uncomfortable
Mexican drug lord on FBI's 10 most wanted list arrested in shoot-out
Will COP31 end with a new global climate deal?
Kim holds one-shot lead at LPGA finale as Korda closes in
Can win over All Blacks finally break England's boom-bust cycle?
Australia hold on for narrow win against Wales
France secure Nations Championship final with Springboks
Fight over fossil fuels leaves COP31 climate talks in deadlock
Lock of former US President George Washington's hair sells for $4,000
Rising star Stirling knocks out Prochazka
Spitting Image co-creator Peter Fluck dies aged 85
Raya set to have scan on injury - how much would Arsenal miss him?
Ireland remind themselves that the best are beatable
Hirst key for Stoke, injuries derail Millwall - Sam Parkin's EFL takeaways
AC Milan monitoring Man Utd's Fernandes - Sunday's gossip
'We lost two points' - Arteta on 'unacceptable' Newcastle draw
Nine wins in a row - Bournemouth & Evanilson continue to make history
Arsenal go six points clear after lively draw at Newcastle
Evanilson strikes again as Bournemouth beat Forest
Leeds dominate Chelsea for first Stamford Bridge win since 1999
Man City drop points to Fulham despite superb Anderson volley
Teenager Williams-Barnett shines as Spurs beat Ipswich
Villa's home woes continue as Sunderland earn point
Coventry beat Palace in Frank's first game after late own goal
Village votes to 'leave UK' over migrant plan
UK should only rejoin EU if it innovates on technology, Blair warns
Rare Titanic items sell for record-breaking sums
Russia-bound ship attacked in Gulf of Finland
'Fragile' and 'miles off it' - Alonso's Chelsea honeymoon is over
Former journalist and Lost Lives author David McKittrick dies
FBI reportedly investigating apparent hack of its criminal database
Man dies putting up shopping centre festive lights
Streeting calls Putin a 'cold-blooded killer' as he meets Zelensky in Kyiv
British man swims through Strait of Hormuz to highlight environmental impact of war
England run up record win over New Zealand in rugby union's Nations Championship
Independent review ordered into surgery carried out by NHS Grampian
Scouts say they face £1m tourist tax cost for overnight trips
Zelensky says Crimean Bridge strikes 'fair response' as he meets Wes Streeting
Money Box
Bad Girls star Helen Fraser dies aged 84
'We're not meant to carry life's challenges alone', Catherine says in first clip
Sessions offer advice on rising energy costs
Man charged with attempted murder after Bradford councillor stabbed
Catherine talks openly about how cancer changed her in documentary on BBC
Consumer Fight Back
I lost my dad, mum and sister to the same aggressive brain cancer
Deal with EU not dependent on tuition fees agreement, Miliband says
Trafalgar Square Christmas tree felled in Norway
PM to meet pub bombings families in new year
How online predator duped 70 girls into believing he loved them
'We're being left behind' - tourist hotspot struggles with one of UK's worst phone signals
Calls to relax 'Dickensian' Peak District house-buying rules
Plans unveiled for one of UK's biggest solar farms
Staff gagging clauses lifted ahead of probe into culture at data watchdog
Man convicted of starting Palisades fire in Los Angeles
They were fined $811m for conning detained migrants, but the scams didn't stop
Tech Now
South Africa's local elections: ANC fights to keep control of cities after election setback
Poppy Jay: An exhausting two days in the shoes of a British tradwife
Phoebe Bridgers: Fans use art to visualise phone-free concert era
Black Friday 2026: Can ChatGPT and other AI tools find you the best bargains?
Who will be Robert Pattinson's 'Bond girl' - and does the role need to change?
NI doctors' strike due to end, with separate walkout planned for Monday
Sales of baby sleeping bag halted by Next after new mum raises alarm
Mamdani announces plan to close New York's Rikers Island jail by 2032
Price beats Kotaskova to become undisputed champion
A new Nepal, an old neighbour - Balendra Shah's India test
Dead dogs keep turning up in the Philippines - and their owners want justice
Cost of Man Utd hiring and firing managers nears £100m
US declassifies more UFO footage filmed in the Middle East
In a year of AI solving maths problems, Anthropic may have just solved the biggest
Kim moves clear at LPGA finale after hole-in-one
Birds killed in blaze at one of the largest foie gras farms in the US
First defeat and first red for Ferguson as Glentoran falter
'My biggest fear was getting changed in front of them' - why teenage girls stop playing sport
French police officers sentenced for beating of music producer Michel Zecler
NFL great Brady could buy Chelsea stake
Price survives match darts to reach Grand Slam semis
Lampard calls for fairness after Coventry penalty row
Denmark accuses Russia of plotting to assassinate US-Ukrainian rapper
What new UK-EU deal could mean for future post-Brexit relations
Gérard Depardieu and French author investigated over sexual allegations
Burnham rejects calls for devolution of powers in letter to Welsh FM
Indian man sentenced to 19-plus years in plot to assassinate US-based Sikh separatist leader
Miami or Vice City? Tour the real-world inspiration for GTA 6
Man guilty of murdering woman he groomed on fetish site
UK to explore even closer ties with EU after agreeing deal, says Burnham
Man jailed for murder of woman drowned in Thames
Two men dead after glider crashes into Loch Leven
Stacked England aim to pile on style and add to All Black misery
Cost of living protests sweep across Europe
Faisal Islam: This cost-cutting UK-EU deal doesn't mean lower prices will follow
Mum's fatal BBL an accident - but risk of more deaths
What is the EU-UK youth experience scheme and when will it start?
We want to have a positive impact - Pochettino
Daniel Thomas jailed for 15 months for slashing dinghy
Nearly 600 women killed in South Africa within three months
Catherine Zeta-Jones' daughter says parents warned her about 'nepo baby' label
Guests no longer asked to wash up as new Airbnb rules come into force
Burnham's first taste of EU deal-making unlikely to be his last
Anthropic shares fall a day after blockbuster opening
Could you spot a fake banknote?
Man charged after 'knives and other weapons' seized from train
Why injured Joao Pedro may be Chelsea's most important player
What we know about the latest Russian missile strikes on Ukraine
Filming training by drones should be illegal - Iraola
The secret cyber scramble to protect UK fridge freezers
'Isla was let down and hopefully this will save other families'
House ramming charges in connection with A66 crash
'Dishonest' police officers sacked for lying over fatal crash searches
Alcaraz puts aside injury concerns to take apart Cobolli
Thousands join cost of living protests across Europe
New Brexit deal 'won't solve' all issues, but is a 'step in the right direction'
Teacher misses sentencing for indecent assault on pupils
SFA should not change to pander to clubs - McLeish
Arteta warns Arsenal players over FPL team news leak
Man who nearly died during liver surgery at Aberdeen hospital says mistakes were made
Calls for consent defence change after Joanne Young rape case
Russian missile hits Poland as Kyiv's allies hold military exercise, says Tusk
Pair charged over RAF Fairford plot to face trial next November
Pontins holiday park fined £1m after grandmother's death
GTA 6 drives spike in download demand, as estimated sales top $2.3bn
Russia targets Kyiv crossings days after Ukraine hits Crimean Bridge
Texas death-row inmate screams as execution takes more than one hour
Striking doctors warn staff will leave NI for better pay
GB's Davis Cup-winning captain ends 17-year stint
Stabbed councillor 'protecting staff member during street clean'
I've only sold five copies of GTA 6, says game shop owner
Some doctors in Northern Ireland go on strike over pay
Percy Jackson returns as teen stars adapt to life in the limelight
Babydoll singer Jamie Miller covers Christmas classic
Northern line upgrades give green light to colour blind London tube drivers
South Korea catches 111 students with new measures against exam cheating
Cummins retains Cricket Australia support as captain
Tinned food and long-life milk boost retail sales after 'Be Ready' campaign launch
Reform selects Robert Jenrick to fight to keep seat
Missing fishing boat Kilda recovered from waters off Orkney
Watch: Start talks to rejoin EU now, says ex-minister
PM has no 'democratic mandate' for Brexit changes, Farage tells BBC
UK braces for coldest night of autumn so far with temperature of -10C forecast
What the Brussels summit could mean for the UK-EU Brexit deal
Should AI be judging our credit worthiness?
'Better results for patients' since SWAH surgery suspended, says health chief
Fine Gael leader wants border poll criteria talks with London
Nigeria moves to end jail terms for attempted suicide
Social poker with £5 stake is booming, says dealer
Loneliness & mood swings - what's it like to miss a season through injury?
Survey reveals 'major increase' in cost of living
'It's a lifeline': Breast cancer support group that's helped thousands
'My frustrating 10-year wait for arthritis diagnosis'
Community hub to close citing financial challenges
Girls as young as five targeted for upskirting as charges continue to rise
More young hikers lost using Google Maps, say rescuers
Mouldy, infested housing for vulnerable people sold as ethical investments abroad
Mysterious Mercury is about to get a visitor - after spacecraft's eight-year epic voyage
More climate money for Africa? Europe says use what's already pledged
China issues Mount Fuji warning as family of missing climber offers reward
Does our ethnicity change how we experience dying?
US army warns detonation of unstable explosives will create toxic plume
Europe ready for talks with Russia on ending war in Ukraine, leaders say
Why Canada is embracing AI data centres while the US pushes back
'I tell my son it's just fireworks': Life inside Yemeni city besieged by Houthis
Eating at your desk? The dos and don'ts of lunch at work
Massive hope for pancreatic cancer pill after trial saw tumours vanish
Secret UK cyber operation protected tens of thousands of fridges from hackers
How did Anthropic's stock market debut unfold?
Question Time
Fiona the hippo dies after swallowing a hat at Cincinnati Zoo
Anthropic becomes one of world's most valuable public companies in stock market debut
Cumin-laced fizzy sodas are giving cola giants a tough fight in India
California targets Nvidia in China AI chip probe
From premature baby to social media star - Famed hippo Fiona dies
Judge finds Thomas Markle mentally fit to stand trial on child abuse charges
Weekly quiz: Which star played cricket with Catherine in India?
Rohingya genocide: What was said in court and what happens now?
Susan Smith denied parole again 32 years after drowning her two sons
'You can be believed and understood': Joanne Young speaks after verdict
Dutch watchdog tells people not to buy AI smart glasses
Men guilty of abusing woman drugged and advertised for sex by husband
'Inconceivable' that Irish government would not hold Omagh inquiry - Sir Chris Bryant
EU-UK talks going down to the wire, says No 10
Myanmar committed genocide against Rohingya minority, top UN court rules
Struggling Blackpool sack head coach Evatt
Two-hour ambulance target missed more than 2,000 times
Timetable set out for dismantling leasehold system in England and Wales
Dozens missing after boat carrying migrants sinks off Senegal's coast
Faults not fixed in 90% of homes in government insulation scheme
Attempted murder arrest after councillor stabbed in Bradford
Flag injunction case 'spiralling out of control'
Surgeon calls for corporate homicide probe over claims patients unnecessarily bled to death
More support for households reliant on heating oil
Nicholls sets record for jump winners by British trainer
Discrimination claims by McDonald's workers can go ahead, court says
Covid inquiry urges UK–Ireland pandemic co-ordination in future
Culture, defence, Fernandes - Pochettino's priorities at Man Utd
Glampsite owner appeals £135k bill after blocking neighbours from using their driveway
Watch: Moment Van Gogh painting sells for record $190.4m (£144.8m)
Cummins' Australia captaincy at a crossroads - Agnew
Cleverly to run as Tory London mayor candidate
Furbank leads returning England trio for All Blacks visit
A 'tsunami river' destroyed my kids' childhood in one day
Ireland hooker Sheehan named at number eight for Springboks game
Welsh NHS in strongest pre-winter position ever, says health minister
Fiona Harvey, who allegedly inspired Baby Reindeer, to appear in court on harassment charge
Viagogo may have broken law on hidden fees, watchdog provisionally finds
Badenoch defends amputee marathon runners claim in benefits cut row
Venezuela signs military deal with US less than a year after Maduro's removal
Premier League clubs to cover legal costs if Man City sponsors sue
Bob Mortimer returns to Middlesbrough and reflects on childhood
US consortium wins huge Kenya mining deal, beating Chinese rivals
Covid inquiry report: key findings on testing, tracing and 'the pingdemic'
UK joins in GTA 6 frenzy as game becomes available worldwide
Florence Pugh hits out at weight loss and cosmetic surgery speculation
Ella Langley sweeps Country Music Awards as Taylor Swift performs
The Brexit debate is back – and there are nerves about what happens next
Florida pastor found guilty over role in assassination of Haitian president
'Frustrated' - Democrats remain a divided party despite winning big in midterms
Indian driver wins $1.3m in life-changing lottery prize
'Whole nation behind you' - Nessa delivers rallying cry for Wales rugby team
Tennis my 'saviour' after trying to take my own life - Riedi
'It's a dream come true' – South African DJ celebrates featuring in GTA 6
UK to provide Ukraine with 1,000 long-range strike drones
Survivors of Uganda's deadly landslide seek justice at the UN
Westside Cowboy named BBC Introducing Artist of the Year 2026
Caterer went bust 36 hours before couple's wedding
UK firms owed thousands as Saudi-backed LIV paid golfers millions
Increase in direct cremations since pandemic
Parents live in fear paedophile nursery worker harmed their children
Hunger Games fan, 13, to get artwork shown on cinema screens before film
Leftover pumpkins help deliver 1,000th free meal
Anglo Saxon 'sand body' among new Sutton Hoo finds
This is a remarkable diplomatic moment for China's Xi - but it comes with pitfalls
Elon Musk says record $446m spending on US midterms was 'pretty foolish'
Who are the investors ready to jump on Anthropic?
Crimean Bridge attacked again, Russian official says
Van Gogh painting sells for record $190.4m after row over its Nazi history
India's religious make-up - what a new Pew study says about Hindus and Muslims
Is your child lying to you? That might not be a bad thing
Crew unaware of risks before Bayesian yacht accident, say investigators
Two-hour ambulance handover limit missed more than 2,000 times
McDonald's sex abuse: 'They were waiting for the younger girls to turn 18'
Why has Waymo pulled all its driverless cars from US freeways?
Claude-maker Anthropic poised for more than $1.4tn stock market debut
Google rejects UK request for Russell Brand YouTube video to be removed, sources say
Russian arrested for spying on US defence company Palantir over Ukraine support
Myanmar faces historic genocide verdict at UN court over Rohingya massacres
Gilts v kilts: What is happening with Scottish government bonds?
Israeli military launches rare ground operation in Gaza beyond Yellow Line
Man Utd pursuing Como's Paz - Thursday's gossip
Littler shocked by brilliant Wattimena at Grand Slam
Catherine visits Mumbai maternity hospital on the last day of royal trip
Buurman rescues late Chelsea win against PSG
Euro Leagues
Can Anthropic's record-breaking IPO stop the AI bubble bursting?
Prince Harry says he would rejoin army as he warns of Russia threat
FA explored legal challenge to Infantino staying on
TfL photocard breach exposes 265,000 customers
How high is UK inflation and how will you be affected?
Raise The Colours member guilty of dancefloor murder
Police chief says racists and misogynists working inside force
Is there bad news for young people in Wales' budget?
Council wins legal fight against flags on lamp-posts
Grand Theft Auto staff 'caught red-handed' in confidentiality breach, tribunal hears
Regulator mistakenly sent complaints about doctors to newspaper
Transport for young musicians withdrawn amid EA cuts
New video shows explosions moments before part of Crimea Bridge collapses
Inside the old gas pipeline where Ukraine is fighting an underground war with Russia
'The drones don't fly here' - BBC reports from Ukraine's new front line
Students face being 'turned away from college' over budget gap
Julio Iglesias facing court investigation over alleged sexual offences
Zverev to defend himself against fresh lawsuit
Sandpapergate: Cummins, Bancroft, Lehmann, Warner - who said what about Australia scandal?
The tightest survival scrap for years? Why it's not too early to worry
'Best night' of Dáithí's life all thanks to organ donation
Democrats nominate Hakeem Jeffries to be US Speaker of the House
Fiona the hippo undergoing care after swallowing a hat at Cincinnati Zoo
Alcaraz continues winning run despite injury concern
Parents jailed for torture and death of four-year-old girl found along French motorway in 1987
Police treating 'targeted' shooting of woman as attempted murder
Cathedral's staff review 'difficult but necessary'
Divide and conquer - how maverick Springboks coach Erasmus split the rugby world
Water queues build as 8,500 without supply
Grand Theft Auto 6 is a masterpiece, say critics
William and Kate meet Indian Prime Minister Modi in New Delhi
BBL filler found in heart and lungs after mum died
Seven Anthropic founders who are about to become multi-billionaires
Police investigate death of boy, 3, after nursery incident
Toilets: Are you a squatter or a sitter?
Burnham promises to 'move quickly' on Neets report
Typical energy bill forecast to go up by £443 a year from January as inflation rate rises again
What's behind the recent flurry of global tech outages?
Glastonbury 2027 headliners announced after year off for the festival
Heating bills, chocolate and cat food: What the inflation figures mean for you
'Good for the people' if politicians stopped doing media, says NI secretary of state
Kuwait says it repelled first Iranian attack in two months after US strikes island
Gamers react as New Zealand first to see Grand Theft Auto 6
Brain cancer patients demand public inquiry into chemotherapy scandal
Lammy urges Burnham to take UK back into the EU
Ivan Toney loses bid to avoid Euro 2028 court clash
Extra £500m for NHS as Reform boycott the Senedd
Joint-record six referee errors in last Premier League weekend
Minister criticises media for 'amplifying' Russell Brand's prison message
Duckett ton & impressive bowlers give England series win
Banned player says whole Australia team knew about sandpaper cheating plot
Joanna Page says male actor made 'awful' and 'inappropriate' comments to her on set
Watch: Emma Barnett pays tribute to 'decent journalism' in final Today episode
Democrats win Alaska Senate race two weeks after midterms counting began
British hacker who stole $11m through text message scheme jailed for six years in US
Ghana's new $60m presidential jet sparks public outrage
MP urges council to speed up heating oil payments
Security flaw found in Java, world's third-largest programming language
Kill or Be Killed
Harry Styles, Billie Eilish, Sam Fender and Cher to headline Glastonbury 2027
BBC drama Shetland to return for 12th series
States to debate social security contributions cut
Huge waste dump blamed on Environment Agency delays
What's gone wrong at Britain's worst bathing site?
'Real life' family ghost story inspires 'nightmarish' new TV drama
George thought his funeral was paid for – but now his wife will get nothing when he dies
Police boss vows to expel racists and misogynists
How one teenager's alpacas are helping children with additional needs
How important are Nvidia and Jensen Huang to the US economy?
Chris Mason: Milburn may have gifted Labour MPs a moral argument for welfare reform
'Human' is Cambridge Dictionary Word of the Year
Can a US-backed mineral highway bring peace and prosperity to DR Congo?
Watch: Marco Rubio says recent tech outages are 'completely unrelated' to one another
Rubio says US not 'under systemic attack' after series of tech outages
Jeff Bezos says he was 'heavily involved' in casting Robert Pattinson as new Bond
Waymo pulls driverless taxis from all US freeways
Irishman charged with destroying US military aircraft with axe
Nvidia says it won't reinstate Huang as firm reports bumper results
UK weather: Is any more snow on the way?
Voy at-home test kit adverts banned over low testosterone claims
Largest British study to check social media ban's effect on youth mental health
Government risks missing climate targets if EV rules weakened, adviser warns
The EU that Burnham is eyeing up is very different to the one Britain left
Europe plans to catch the next computer chip wave
Belief and bench help Northern Ireland scale new heights as promotion secured
Burnham to set out options next month for long-term EU relationship
Bellamy convinced of Wales credentials despite defeat by Portugal
Pakistan's solar revolution seems unstoppable - but there's a problem
Republic of Ireland talisman Parrott caps dream year with two more goals
Millions of red crabs start annual migration on Christmas Island
Humphries and Van Gerwen into Grand Slam knockouts
'It's hard to keep going': Neets speak to BBC about struggling to get a job
American soldier arrested by UK police on suspicion of spying taken into US military custody
Thomas Markle charged over child sex abuse material in Philippines
Fears toxic lagoon fire led to cancer and miscarriages
Home secretary plans to tackle 'perception of two-tier policing'
I want to know if toxic lagoon fire caused my husband's rare deadly cancer
US National Security Agency's classified internal network reportedly goes offline
Russian military plane crashes, killing all 19 on board
Former Conservative MP Sir David Evennett dies
Protest against talk by academic who made Arday plagiarism claim
Church of England should protect 'every belief', King says
Government backs welfare shake-up to prevent 'lost generation'
William and Kate celebrate Earthshot Prize winners in Mumbai
Who to watch in Spain's election race
Ex-Reform Wales leader Dan Thomas faces no further police action after assault arrest
Hunger Games prequel splits opinion: 'Surreally awful' or 'surprisingly strong'
Arsenal Double winner Storey dies aged 81
Woman's blocked nose led to nasal spray addiction
Train attacker feared 'conspiracy by devil'
'It was really scary': Mother describes sheltering during Russia strikes on Kyiv bridge
Putin's Crimea bridge partly collapses as Zelensky hails 'unprecedented' attack by Ukraine
Brad Pitt and Florence Pugh pitch for James Bond villain role
Jensen Huang says he would return as Nvidia boss if asked by the board
'Everyone's talking about it' - GTA 6 generates huge hype ahead of release
Charles Bronson denied parole for ninth time
Henry Nowak killer applies to appeal against conviction
US loses measles elimination status after 26 years amid record case numbers
British Airways plane veers off Heathrow taxiway
What does the Milburn report mean for Scotland?
South Africa head coach Erasmus banned for six matches
UK sanctions firms over Israeli West Bank settlements
We can't afford to hire under-25s, say firms. Will Milburn plans help?
Woods set to return next month after two years out
Watch: BBC reports from Kyiv bridge hit by Russian attack
FA wants to host Nations League finals in England
How the attack on Crimean Bridge unfolded
Palestinian woman, 72, shot dead by Israeli settlers in West Bank, health ministry says
Carney eyes 'other options' for embattled Canadian auto sector on China trip
Speed camera fault may have allowed drivers to escape fines
Hutchinson ruled out for season after celebration injury
NHS gets £500m boost in Wales' first budget under Plaid Cymru
Out of work and not in college: How quickly could Milburn's plans help you?
What in the World
How new US chip restrictions on South East Asia will hit China
Man pleads guilty to harassing Jess Phillips MP
Rooney says he considered taking his own life at Man Utd
E-motorbike killer's jail sentence increased
DeChambeau joins DP World Tour after LIV Golf collapse
Channel 4 admits it doesn't know number of Married At First Sight UK sex abuse complaints
School orchestra cuts penalise young people in rural areas, says principal
Six in court accused of high-value Pokemon card theft
Bethell to have more surgery and miss South Africa tour
Why Milburn's Neets reforms will only save £200m a year by 2036
Batman to James Bond: The clues about what to expect from Robert Pattinson's 007
Government must act now or lose Royal Mail, former minister warns
School offers prizes to pupils for turning up to class on day GTA 6 comes out
Restaurant with zero hygiene score fined thousands for 'stomach-churning' offences
NHS data contract to stay with Palantir until 2029
Gunmen kill Costa Rican journalist who reported on drugs trade
At a glance: Key proposals from Milburn's Neets report
Watch: What's in the Milburn review?
Nvidia partner Megaspeed being investigated by US government over chip exports
Gleneagles Hotel buys Scotland's 'ghost' golf course
Immigration arrests after organised crime blitz
Will Infantino feel he's already won as Fifa challengers are revealed?
Freshers' flu left me deaf in both ears - I'm now helping people like me drive
Woman who accuses Russell Brand of rape says prison message 'upsetting'
Inside Health
'We're a capitalist society': Grindr defends $120 a month premium tier
Indian woman gang-raped while pregnant in 2002 'heartbroken' after two perpetrators bailed
Dazzling Leonid meteor shower to peak on Tuesday night
'I spent more than two days waiting in A&E' - NHS bids to end corridor care
Why Lewis Hamilton is key to Oliver Bearman's future
Watch: Predatory Met detective's behaviour became increasingly extreme
Body of Melbourne Cup horse found dumped in Sydney skip
The Briton scouted while watching a friend, now on the brink of the NFL
Nursing union 'dissatisfied' with safe staffing legislation
How Met failed to stop rape-unit detective who abused women
Mystery of 2,000-year-old bog body solved in 'first of its kind' investigation
Ukraine accuses Russia of targeting rescue operation after 'double-tap' strike kills 72
Robert Pattinson to replace Daniel Craig as James Bond
Newspaper headlines: 'No savings for a decade' and 'The name's Pattinson'
Imran Khan seeks urgent medical care fearing he 'may not return alive'
Failed asylum seekers face removal without five-day notice period
New Zealand tricks and annual leave - the lengths fans are going to for GTA 6
What's the story with Scotland boss Pocognoli - is it time to go?
Customers report service outages at major US banks
Met Office yellow warning in place as snow could disrupt Tuesday morning travel
BBC launches programme for children forced from school by bandits and poverty in West Africa
The young people caught up in Britain's Neets crisis
Aged 16-24 and looking for work? Use our look-up to find out which areas have the most jobs
We couldn't afford a house alone, so we bought one with strangers
The AI start-ups fixing India's broken roads and messy land records
'Is that not match-fixing?' - Erasmus questions officiating
California sues OpenAI over Hugging Face attack
Taking Korea's toughest exam from behind bars
Littler hits triple-bull, but Price checkout doesn't add up
Woman who got hooked on nasal spray for 10 years says it cost her thousands
Pocognoli wants patience but Scotland 'don't have time' says Robertson
'Complete system reset' needed to get 440,000 young people into work, says major review
Children dropping out of school: What can politicians do about it?
Cass report author says she does not support draft conversion practices bill
Will enough Labour MPs back benefit cuts this time?
Houthi rebel advance in Yemen may further destabilise global economy
Wilson apologises for not declaring Israel debate interest
Pope Leo hit by flying rosary while waving to crowds in Peru
Forensic expert says his analysis of autopsy photos suggests Epstein was killed
Five-try Joseph set to start for England against All Blacks
'Parents are offering to pay kids' wages': Salon owner
Americast
Emma Barnett to leave Radio 4's Today for new BBC show
When will we see Robert Pattinson as Bond in cinemas?
Lindsay Clancy to face retrial next year for deaths of her three children
New Zealand let country down in loss to Wales - Rennie
Tributes as wife and daughter of DUP chairman die hours apart
Five EU countries announce migrant deportation centre in Rwanda
Miliband says he won't resign if government approves Rosebank oil field
Wales without Williams for Portugal as Bellamy makes Vitinha point
Klopp says Infantino worse than Blatter
Police officers lied about searches connected to fatal crash, hearing told
South Africa recall Etzebeth for Ireland match
David Chadwick confirmed as new leader of Welsh Lib Dems
Alcaraz 'best I've felt' in statement start at ATP Finals
Russell Brand prison message 'appalling' and being investigated, No 10 says
How Frank can restore reputation and save Crystal Palace
Should mobile phones be banned in schools?
Watch: Street cricket and metro ride as Prince and Princess of Wales visit India
From Batman to Bond - how Robert Pattinson landed the role of 007
Landmark Crimea bridge hit as Russia reports biggest Ukrainian drone attack of war
Raye, Rosalia and Dolly Parton recognised in Grammy nominations
Ratcliffe's Ineos settles £180m boat claim with Ainslie
UK budget leaves NI underfunded, O'Dowd says
Estonia to close Russia border crossings after attempted drone factory arson attack
Gérard Depardieu drops appeal against sexual assault conviction
GTA 6 hacker pleads guilty after release from secure hospital
Barristers must stop using rape myths in trials, justice secretary says
Has Trafford replaced Pickford as England No 1?
Ashes of exiled Nobel Laureate Miguel Ángel Asturias returned to Guatemala
Man sentenced for attempted murder of three children that sparked Dublin riots
Cap fits as Robertson poised to take King Kenny's crown
Tourette's film I Swear wins three Scottish Baftas
'Incredibly special' - William reveals his favourite view from first home with Catherine
Women's criminal records wiped for abortion offences
UK lost more than it gained from Brexit, Burnham to say ahead of EU summit
Yemeni forces retreat to defend port city from Houthis
Two mass shootings in South Africa leave 17 dead
I survived a fire that killed my boyfriend - it was started by his brother
Yellow weather warnings issued for snow as temperatures plummet
Avoid this Black Friday scam - how to check it's a real deal
UK and allies call on Israel to allow rapid humanitarian access to Gaza
Prince and Princess of Wales play street cricket in Mumbai
Prince and Princess of Wales arrive in India ahead of meeting with Modi
Gas starts flowing from Jackdaw after government green light
Workers should get paid time off to train for crises, say peers
Thrift shop asks shoppers to nominate a charity
'It felt like I was dying': Why some teenagers don't go to school
'I'd throw up in the car park': How school anxiety is harming children's futures
Poppy Jay explores the appeal of being a tradwife
'Break-in and rising costs could kill my business'
Watch: New York teen reunites with cat missing after building collapse
Lancashire's 'strong R' due to hidden tongue movement, study finds
Mexican drug lord Miguel Ángel Félix Gallardo dies age 80
Australian MP 'full of gratitude' upon leaving hospital after alleged car attack
Intel sued by investors after PC sales slump hits share price
Cancer 'sponge' tests could be offered to more people with bad indigestion
Is India rethinking its short-term military recruitment scheme?
Russia's mega-rich are already imagining a future after Putin
Town rebuilt after devastating floods becomes showcase for Libyan strongman's rule
Families of the Disappeared to meet the Pope
Teenager Andreeva caps stunning week with WTA Finals title
'Steering casualty' preceded New Orleans cruise ship collision, says NTSB
Cut national insurance for under-25s to create jobs, Milburn report to say
Police ban protests near 10 schools and five universities in Paris
Suspected China spy linked to Nvidia's ex-boss left Megaspeed in 2025, company says
Brand moved from Wandsworth to category C prison, his wife confirms on podcast
Who swaggered around like he owned the place? Spain v England ratings
Tories pledge to halt screen-based school exams and cut coursework
UK will have 'voice' but no vote on EU food rules in Brexit reset
Prince Harry praises war veterans on surprise visit to Ukraine
I had to explain to my teacher what a young carer was - we need more support
Trident submarine returns home after record-breaking undersea patrol
Czechs rally against plan to switch funding of public media
Townsend hails Scotland's defence in Australia 'arm wrestle'
Man Utd target Fulham's Bassey - Monday's gossip
London City's 'bravery' paying off in top three pursuit
Aston Villa beat Birmingham in WSL derby
Struggling Charlton make WSL history after defeat at West Ham
Zelensky urges US and Musk to lift Starlink restrictions and be on 'right side of history'
Ronaldinho, 46, makes comeback for Ravenna
Thousands of US flights still cancelled or delayed two days after grounding of planes nationwide
Pope Leo rides in helicopter cockpit during Peru trip
Clothing factories shut in Bangladesh as workers strike over pay
Aftermath of deadly Leeds car crash during police pursuit
'We've waited 73 years to be here' - Wales fans ecstatic after win over New Zealand
Club's first match since player's death abandoned because of serious injury
Bristol Rovers being let down by poor players - Evans
Pitch perimeters under review after Vigar death
Man in life-threatening state after shop robbery
Iran targets US military base in Bahrain with drone attack
South Korea's top scorer in tax accountancy exam admits cheating
Curran's best weapon? The 'moon ball' strikes again
Staggered age of consent to be discussed after Brand case, minister says
Man dies after being hit by ambulance near Sunderland
Branthwaite, Garner and King omitted for Spain game
Minister backs legal right to job support for young people
Skipper Bryce sets new Scotland run record in win over UAE
Eleven officers convicted of crimes still on Police Scotland payroll, chief confirms
Man and woman die and four arrested after police pursuit crash in Leeds
McIlroy targets 10 after equalling Montgomerie
Schoolboy imposter subjected ex-professor and wife to 'terrifying ordeal'
Banton hits century and bowlers sparkle for England to level ODI series against Australia
Three men sentenced to death in Jordan over fatal church mass shooting
Sunday with Laura Kuenssberg
I took in three children with my husband, who was adopted, then found out at 40 that I was too
Pope Leo speaks of community 'suffering' on visit to remote Andes town
Australia's Sayers 'took sandpaper from field' & rejects Cummins' claims
Fifth Canadian soldier dies from injuries caused by large fire at military base
Reality dawns after Wales dared to dream
Israel kills Hamas commander in strike on Gaza camp, officials say
Sea of phones at Christmas event prompts backlash
What happened after a small town introduced a balaclava ban
Call to review sentence for driver who killed boy and fled to Latvia
Mental health is no joke - but I've turned it into a stand-up routine
Ex-Met Police inspector lied about wife's death in Barbados hotel room, BBC learns
Hannah Fry feels 'unbelievably lucky' after cervical cancer treatment
Holly Humberstone: People can't connect to a pop star who's 'too polished'
My mother told me I would die if I sought treatment for Ebola - I am proof you can survive
Judo champion shakes up French presidential race with surprise candidacy
Can lessons in shaking hands and making eye contact help kids land jobs later in life?
Beauty advent calendars can cost hundreds but are they value for money?
Liverpool put three past Brighton to end winless run
Sabalenka apologises & says viral comment 'not directed at Svitolina'
Hallgrimsson rues 'painful' defeat for Republic of Ireland
Russell Brand: Alleged rape victim wants age of consent law changed
New Orleans port sues tanker owners over cruise ship collision for $1m
Ireland 43-15 Fiji: Seven-try hosts shake off sluggish start to secure bonus-point win
'Can you believe it?': SpaceX catches part of its Starship rocket on return to Earth
Nerveless Andreeva reaches WTA Finals showpiece
Arsenal target Nusa could cost £66m - Sunday's gossip
UK ethics watchdog chief steps back from role over sexual misconduct claims
Comeback kid Joseph thrills as England eye All Blacks
What Wales need to stay in Nations League top tier
'No racism in Spain' – De la Fuente message for Tuchel
Rice close to signing new Arsenal contract
'One of the greatest wins' - Wales stun All Blacks to go from no-hopers to heroes
Joseph enjoys dream return as England thrash Japan at Twickenham
Haaland helps Norway to win over Wales in Nations League
Copper wire upgrade caused nationwide flight suspension, US transport secretary says
Bompastor's risks pay off as Chelsea go top of WSL
Philippines takes the crown in first Eurovision Song Contest Asia
Italy fines Meta €805m over accessing users' photos
Philippines wins first Eurovision Song Contest Asia
Sotheby's auction of $180m Van Gogh challenged over claims it was 'sold under duress'
Thousands turn out in Edinburgh to protest against AI data centres
Welsh Labour 'didn't focus on improving people's lives'
Wales stun New Zealand to end 73-year losing streak
Highlights: Wales beat New Zealand for first time in 73 years
Milder weather coming before more cold health alerts take effect
Chelsea go top with 1-0 win against Man City
Nigeria cautions against travel via Ethiopia's main airport due to altitude
Man dies after being stabbed by gang of masked men
Young people should have legal guarantee of job or training, Milburn tells BBC
Bonnie Tyler remembers loved ones in posthumous Christmas single
Body found on French beach after attempted Channel crossing
Neets review won't be for the faint-hearted - and will test Burnham's appetite for a welfare fight
Burnham suggests Welsh Labour lost sight of devolution as review criticises ex-first minister
I never thought I'd make it as an actor but now I'm up for a Bafta
US has floated Ukraine ceding Donbas for Nato membership, Zelensky says
How to spot November's planetary parade in the pre-dawn sky
Hungarian authorities uncover $20m during probe of Orbán-era minister
Taylor-Brown wins in Dubai to top T100 standings
King jokes with Elton John as he marks 78th birthday with radio show
'Exciting' Moylan flourishing for club and country
NI target challenge of Nations League promotion
Fifteen taken to hospital after deliberate fire at Glasgow flats
Tuchel to remind England of anti-racism protocols before Spain game
Singer's Hall of Fame induction axed over Russell Brand comments
The rise of 'housefishing' by estate agents
England boxer missed Worlds over sex-test mix-up
What we know about the ground stop and what to do if you're affected
Warner accuses Cricket Australia of 'cover-up'
'I'm lucky to be alive': Woman's warning over black market weight-loss jabs
What do Christmas market traders say about rising prices?
Bluetongue virus confirmed on County Down farm
'I cycled across America in memory of my wife - I know she's proud of me'
Food bank sees donations drop by 10% each year
'We'll get home one day' - US travellers impacted by nationwide ground stop
When to put up a real Christmas tree - according to an expert
Even Grand Theft Auto's original creators haven't been able to play GTA 6
Family's two-year fight to bring killer driver back from Latvia
Brand, Walliams and Married at First Sight: Is this a reckoning for the entertainment industry?
UK weather: Frost and freezing fog forecast as cold health alerts continue
Newspaper headlines: 'Police launch investigation' into Walliams and Piddington asylum 'betrayal'
Jojo the gorilla has spent his life alone. Can he finally find a companion?
Arrested generals and a threatened VP: President's son fuels Ugandan succession fever
Setback for SpaceX Starship rocket's double-catch test
'Miracle on Mississippi' - All rescued after cruise ship hit by tanker in New Orleans
After a summer win, India's Gen Z protesters face a winter of uncertainty
France hold nerve to edge past South Africa in thriller
How the Jensen Huang scandal created a headache for business-friendly Singapore
Watch: Children in Need 2026... in 90 seconds
Woman with terminal cancer gets dream wedding on hospital ward
Ferguson 'made up' with first win as Glentoran boss
Fitness obsessed & 'control freak' - what can Man Utd expect from Pochettino?
Probation officers to take industrial action over pay and early release scheme
Goalkeeper involved in fatal collision gets 12-game ban
'If that penalty is given against you, you're furious'
US Air Force says it responded to 'suspected drones' over RAF Lakenheath
Salah scores twice as Egypt and Nigeria win Afcon 2027 qualifiers
Man Utd want Paz, Chelsea target Kounde - Saturday's gossip
'Gloves are off' - how Australian papers reacted to Cummins on Khawaja
New campaign against EU membership launches ahead of UK-EU summit
Dept Q crew member dies after being injured at Edinburgh film studio
Microsoft outage 'stark reminder' of how much we rely on tech
Watch: Cruise ship seen sinking after collision with cargo ship in New Orleans
Microsoft 'deeply sorry' for global outage after almost 24 hours of disruption
Any Questions?
Man who transported Omagh bomb was an MI5 and Garda agent, inquiry told
Democratic Senate leader Schumer set to face leadership challenge
Eurovision is finally coming to Asia - meet the stars gearing up to take the stage
Labour lost its connection with voters, says Welsh leader
Tories pay artist for Burnham images after legal threat
The Peruvian city that has embraced Pope Leo as one of its own
Are board games making a comeback this Christmas?
Estonia bans Russian athletes as backlash intensifies
Eleanor Donaldson given supervision order and placed on sex offenders' register
Man jailed for grooming at least 70 girls online
Mother whose newborn died after failed hospital checks was 'terrified and alone'
Police investigating David Walliams over reports alleging serious sexual offences
Rosenberg: Uncompromising Putin ups demands for peace with Ukraine
What are people emergency stockpiling?
Education minister cleared over Israel trip
German spies handed new powers to tackle 'hybrid threats' from abroad
'I felt awful wearing my school uniform because of how I looked'
Tearful Pochettino on 'difficult' decision to leave USA for Man Utd
Former Hamas bodyguard guilty of UK knife attack
At least 24 killed after bus collides with truck in north-east India
Watch: Divers explore US ship sunk off Florida coast to create new reef
Bessent blames Lutnick's Commerce Department for failing to block Megaspeed
Watch: BBC undercover reporter is offered fake art and awards for talent visa
Climate action discussed at youth COP meeting
'Hardest challenge of my life' - Owain Wyn Evans completes Children in Need ride
Piddington to bring legal challenge over asylum base plans
Reform and Tory spokesmen in angry clash over immigration at Piddington
What we know about the global outage
Shoplifters 'stealing to order' in Scottish shops
Are you affected by the Microsoft outage?
Arrest after woman, 80, 'doused and set on fire'
NHS, schools and police forces hit by Microsoft outage
McIlroy and Hatton tied as Chacarra stays in hunt
Courts, spies and MPs: How the Microsoft outage has been felt around the world
Russia hit by second car bomb in as many days as peace talks continue
Reform could try to remove Senedd presiding officer over member's speaking ban
UN watchdog 'increasingly concerned' over uninspected Iran nuclear site
More women make allegations against Russell Brand
How Ferguson-inspired Pochettino can succeed where Carrick failed at Man Utd
Global Microsoft outage affecting NI schools, councils and other services
Watch: How a server outage took down Microsoft Teams and Outlook
Surfing speedster Beardman gives a glimpse of Ashes future
Rosalía scoops historic third best album award at Latin Grammys
Nigerian university in mourning after four students die at post-exam party
The driving-maul try machine - why rugby's steamroller gained traction
Fears 150 jobs could be lost at university
Water firm pleads guilty after four killed in blast
'I feel it's a sign of what's to come': Office workers on Microsoft outage
Man charged over multiple sex assaults at university
Boy died from multiple injuries in Cyprus hotel fall
Fernandes rejects second Man Utd contract offer
Heat pumps: How much heat does your home really need?
Australian cricket's sandpapergate is back - and it cuts deep in a 'nation of good sports'
Smart glasses banned from Welsh Parliament after ruling they could be used for speeches
What happened overnight with the Microsoft global outage?
African Miss Universe beauty queens in limbo as US visa restrictions bite
Laughter and learning at BBC Children in Need-backed homework club
Scotland created Grand Theft Auto - is its video game industry still thriving?
Young, Welsh and into politics - but with different views on independence
Politicians back focus on cost of living
My physical deformity left me feeling invisible - but one surgeon saw me
Cider makers fear future for orchards as costs grow
Youth scheme branded 'failure' over success rate
Whatever happened to the $300,000 diamond that went missing in F1 crash?
How Children in Need is helping young people grow in confidence
Firm offers to fake artworks for wealthy migrants seeking UK 'talent' visas - BBC investigation
North Korean hackers used fake video calls in $400m crypto hack, says FBI
Will the Eurovision Song Contest succeed in Asia?
Zelensky welcomes US bringing Europe into Russia-Ukraine peace talks
'My window faces a brick wall': What's your rent in NYC?
Burnham says 'win-win' deal can be agreed between UK and EU
Doctor burnout putting maternity patients at risk, says regulator
MI5 will need proof to be believed in future, says Leveson after BBC investigation
The school where white working-class pupils defy the odds
Why midterm vote-counting is taking so long in America's largest state
Cricket sandpaper scandal claims '100% wrong', Australia captain says
Skye Newman gets 'goosebumps' over record-breaking Brixton Academy run
Neither war nor peace in Tigray - is Ethiopia's latest conflict really over?
Brand will face 'hell on earth' in Wandsworth prison, says former inmate
Ankle injuries are more common than you think - here's how to protect yours
The rise of 'housefishing' - when does using AI go from enhancing to misleading?
Military cemetery decorum: The tradition behind Hegseth's Veterans Day reprimand
US doctor kills building manager after long-running dispute over mould, police say
Scandal-hit Nvidia CEO Jensen Huang quits, plunging AI chipmaking giant into turmoil
'A lie' - Palmer committed to England, says Rogers
Young, Welsh and torn on independence
Flood victim, 95, lived in Wetherspoons after her home was destroyed and died before she could return
Trouble at the top - the crisis of confidence in Scotland's NHS leaders
How many sewage spills have happened in your part of Scotland?
Gauff battles through back injury to keep WTA Finals hopes alive
Rolls-Royce gas leak prompts emergency response
Military base asylum plans granted planning approval
Grealish apologises for absence after breach of discipline
Where does Kane rank among all-time England greats?
Gritty Arsenal show different side in Barcelona draw
Microsoft users report outages amid tech giant 'connectivity issues'
Weekly quiz: Who's joining Wayne Rooney in the I'm A Celebrity jungle?
Jensen Huang has resigned, what's next for Nvidia?
Russian warship hit by Ukrainian drone in Gulf of Finland
What we know about Brooklyn building collapse that killed eight people
Duran Duran drummer quits band due to tinnitus
Man jailed for 'appalling' catalogue of coercive control and abuse against partner
Hegseth awards medal to war memorial guard who reprimanded him and group
'How does a building just fall?' Neighbours grieve after deadly Brooklyn building collapse
Can Burnham avoid another Labour welfare rebellion?
"A mammogram can save your life."
Some childhood offenders may no longer have to reveal convictions to employers
Parliament date set for 'summer of sex' debate
Fourteen dead after truck loses control in 23-vehicle crash in UAE
How AI visionary Jensen Huang was undone by his own bad decisions
How Pochettino came on Man Utd's radar - and what sacked manager Carrick was told
The rise and fall of Jensen Huang - how the tech superstar became mired in scandal
Millions of Ebola dollars missing with staff unpaid while virus spreads, charity says
Ukraine says military Starlink disrupted again as US envoys meet Putin in Moscow
Who is Nvidia's interim CEO Colette Kress - and who could take over permanently?
Clean-up begins as oil spill shuts 18 Kent beaches
Andreeva beats world number two Sabalenka to reach WTA semis
Israeli strike on Gaza hospital kills six Palestinians, health ministry says
McNabney set for debut as Irish make seven changes
McIlroy makes strong start in bid to equal Montgomerie's record
Before Scott Colom, these two men were the last black US senators in Mississippi
Eight killed in Colombian air strike targeting Gulf Clan gang
Russell Brand's social media accounts disabled by Meta
Faisal Islam: Why the UK economy is surprisingly resilient
I'm burnt out and feel forgotten as a young carer
Two men found guilty of spying for Iran over plan to target UK-based journalists
'We've got to run': Inside ruined Ukraine power plant under constant drone threat
Teenage girl admits murder in row over boy
MPs urge Labour ministers to get on with trophy hunting ban
Watch: The latest in the Jensen Huang Nvidia scandal
Schools, libraries and parents face 'difficult decision' over David Walliams books
Suspected bomb hoax threats force fresh evacuations of Italian schools
Resident Evil Requiem sweeps Golden Joystick Awards
Palace sack Sage after 16 games with Frank in advanced talks
CMAT joins Philomena Begley on stage in surprise appearance
Which antidepressants are the most effective?
Pollock starts alongside Ojomoh and Joseph in bold England side
Intelligence officer's rare Aston Martin to be sold
Media industry could be forced to improve safeguards after Walliams allegations
King Charles appears on Elton John's radio show in secretly recorded birthday episode
Housing association worker was stabbed in heart before crashing car, inquest told
UK economy grows at fastest rate for more than two years
Five new miniature frog species found in eastern Himalayas
Burnham says climate consensus 'gone' but pledges 'new era of leadership' in COP31 speech
Woman, 80, set on fire outside own home, say police
Man arrested after sexual assaults at University of Huddersfield
Activist Daniel Thomas admits criminal damage after slashing migrant dinghy in Channel
The chaos that took Carrick from two-year deal to sacked within 15 games
British woman missing from cruise ship in Atlantic
School exam boss to step down after two years in post
England legend Anderson, 44, joins Surrey
Why has a Reform MS been banned from speaking in the Senedd?
Watch: 'Life-changing moment' boy turns on Tourette syndrome device to help stop tics
Oranges investigated after four girls die in suspected Uganda school poisoning
Robertson set to make history but his hero Dalglish will always be King
Are branded cold and flu tablets really worth the extra money?
Gas bills to rise as Middle East turmoil persists
Handwritten 200-year-old dismissal letter found on roof tile
I saved a stranger's life and my husband's at the same time
Drugs running was like 'a paper round' for exploited son, mum says
Australian teen missing in bush for six days rescued alive
Trying Tourette's device was the best day of my life
How much art does your council own and is it locked away or on display?
Democrat Scott Colom seals historic win in Mississippi Senate race
'You're triggering me': How to understand your therapy-speak teen
Andreeva wins 11 games in a row to thrash Sabalenka at WTA Finals
Nigeria's president launches re-election manifesto but can he regain voters' trust?
Burnham's push for closer EU ties causes ripples in his party and others
Sunbed firms must not downplay cancer risk, says watchdog
Significant drop in levels of toxic 'forever' chemicals in England's rivers
Are max strength cold and flu pills worth the money?
From Paris to DC - why offices are being turned into apartments
Some under-25s should get less benefits, Milburn review to say
New York building collapse kills one person and injures 12
'Summer was a wake-up call, winter could be dire' warning over food supplies
Free SAD lamps given out as disorder 'makes it hard to do anything on darker days'
British soldier charged with rape of woman serving in Cyprus
Welsh NHS bosses call for multi-year health funding
Lego marketplace BrickLink offline after 'unusual activity' detected
Hegseth and advisers reprimanded by guard at Tomb of the Unknown Soldier
'Not the answer': Labour MPs speak out against Rosebank as decision looms
Author says there were 'real concerns' about David Walliams within publishing industry
African writing award probe finds 'no evidence' winning story was AI generated
How would you describe your ethnicity on the census?
University's £16m savings will lead to 150 job losses, says union
Police believed Huntingdon train attacker had schizophrenia, jury told
Famed ship SS United States to be sunk off coast of Florida
Welsh students to start repaying loans earlier after thresholds frozen
School bomb hoax emails: 'Stay vigilant but not alarmed'
Missing 11-month-old baby rescued after being buried alive in a crate in South Carolina
Burnham signals backing for more ethnicity options on next census
Poundland founder writes to King for help
Former minister calls for phone tech to block live-streamed child sex abuse
Brad Friedel on Shrewsbury Town takeover
What is the state of our grooming laws?
Jailed undertaker lodges bid to appeal against sentence
Ex-parliamentary aide acquitted for spying tells BBC he was 'fall guy' but also 'naive'
Workers across Spain stage first general strike in 14 years
US Treasury Secretary Scott Bessent relocated after alleged Iranian threats
Leader, role model, extraordinary - how Kane's 'fairytale' came true
Indonesia's vice president resigns amid signs ruling alliance is fraying
Protesters gather in Spain for first general strike in 14 years
Schools across Scotland targeted with fresh hoax bomb threats
Russia-Ukraine talks turn to post-war security but end without breakthrough
Actor's reading of Blackpool soldier's final letter helps mother grieve
Japan want 'the sky to fall in' at Twickenham - Jones
Kidnapper, 74, escapes from house arrest in Argentina by abseiling from balcony
Three Iran-backed suspects plotted attacks including RAF Fairford incident, US says
Reform boycotts Senedd after member banned for saying white people being replaced
'Hoax' bomb threats sent to hundreds of NI schools
Toby Jones stars in film about UK Mars mission
UK falls silent to mark Armistice Day
Spain sees widespread disruption in first general strike for 14 years
Police treating threatening email sent to more than 300 schools as 'hoax'
A 32-year-old DJ from Scotland confirmed as victim of Krakow shooting
Turkey-based Bates replaces Binks in Scotland squad
Welsh Grand National-winning jockey O'Brien dies aged 39
Egyptian journalist's retrial adjourned as UN warns of 'assaults on press freedom'
Four grizzly bears killed in Canada after fatal attack on mother and daughter
Mauricio Pochettino and Manchester United are a decade in the making
Kenya discharges last Ebola patient in major milestone towards virus-free status
What are cold weather payments and who can get them?
MPs jostle for slice of £14.6m from axed leisure centre
Senior doctors call off two-day strike planned this month
Watch: UK falls silent to mark Armistice Day
Hundreds of Italian schools hit by threats in suspected bomb hoax
Haitian PM praises El Salvador after joint strike on alleged home of gang leader
US House blocks bid to impeach Defence Secretary Pete Hegseth
Assessing the reasons for Man City's decline in form under Maresca
Transport workers in Chile block highways in protest over surging fuel prices
New Indian mega library rocked by scandal over 'AI-generated books'
Littler expected 'pub players' on Netflix show
Dua Lipa to become first female British headliner at Coachella 2027
Pochettino ready to accept Man Utd offer to replace Carrick
'My darling girl, you are everything to me' - auctioned letters reveal WWI love story
Police helped remove Russell Brand after 'violent incident' at Jemima Goldsmith's home
Wayne Rooney leads I'm A Celebrity... Get Me Out of Here! line-up
Jonathan Ross 'horrified' by Walliams allegations and Brand conviction
The Global Story
Tearful Smith switches allegiance to Netherlands
Khawaja refuses to name Aussie ball tamperers
'I felt like I was being manipulated': Woman alleges Walliams groomed her as a teenager
Vinícius Jr's message to Sudan boy who received prosthetic legs after BBC report sparked appeal
Governments 'asleep at the wheel' over social care, says head of review
Christmas toy rush being driven by squishies and building sets
Prince George's artwork featured in Country Life magazine
US warns Madagascar over growing military ties with Russia
Temperatures to dip to -5C as first cold health alerts of season issued
Bid to restore rare Atlantic rainforest secures £6m lottery grant
Meet the visually-impaired actors creating pictures through sound
Does Pickford finally face serious competition for his England place?
Electricity bills to rise by 2.5% from March
Richmond upon Thames is happiest place to live in Britain, survey finds
Women in town hit poor health earlier than average
Why is Scotland's housing shortage getting worse?
Fears Wales' Mary Rose will stay in storage because of £27m bill
Acquitted 'China spy' tells BBC: I was fall guy for security services but also naive
Tonnes of dumped rubbish leaves £10m business park an 'apocalyptic' mess
In Mississippi, voters await cliffhanger Senate result with hope and frustration
New photos are 'essential evidence' of possible SAS war crimes, inquiry told
Duchy tenants may have to buy farms or leave as Prince William plans sell-off
'They will kill you too': Sonia Gandhi's turbulent journey in Indian politics
Students passing university assessments in minutes using AI, regulator warns
Vinícius Jr sends message to Sudan boy who received prosthetic legs after BBC report sparks appeal
Robot vessels take on the dangerous work of mine hunting
'It can kill us': Kenyans fear impact of El Niño with floods predicted
Antidepressant escitalopram more effective at preventing relapse, analysis finds
Poundland hopeful for last-minute rescue deal to stave off collapse
WTA Finals: Linda Noskova beats Coco Gauff to reach semi-finals, Jessica Pegula wins
Arsenal eye Real's Endrick - Wednesday's gossip
Nvidia hires major US law firm to investigate alleged Chinese spy affair
Why Walliams' unprecedented legal battle to stay anonymous failed
Injured Feyi-Waboso is our Robinson - Sinfield
Leicester and Brentford U21 into EFL Trophy knockout stages
Meghan's father Thomas Markle back in federal custody after allegedly removing ankle monitor
Man City thrash Inter to claim first CL win of season
Census should include black English and Asian English options, says MP
Why does Australia want Brits to swap Sydney for the outback?
Pocognoli to lean on Scotland's 'captain group of five'
Spain's king and queen attend memorial service for rail crash victims
US federal authorities could have prevented Epstein crimes, report finds
Watch: E-bike battery explodes into massive fireball inside Oregon home
David Walliams accused of sexual misconduct after losing injunction bid
US Army soldier suspected of spying for Russia arrested in UK
Watch: What we know about the allegations against Walliams
Violence erupts in Bangladesh as ousted PM's supporters stage protest
Deal agreed to end health visitor strike affecting baby appointments
Train attack driver's '10 seconds' to change line
Makers of GLP-1 drugs ordered to add warnings about rare eye condition that can lead to blindness
Seven in hospital after car 'mounts pavement' in Glasgow
Meet the Peaky Blinders, Ukraine's drone unit protecting a devastated front-line city
Malaysia's disgraced former PM leaves jail for house arrest after embezzling millions
Stevie Wonder leaves cafe staff £1,000 tip after Manchester gig
The Monaco summit that will decide the future of Carrick and Man Utd
Arrests made after visit from former US President Biden
Anti-homosexuality laws in Trinidad and Tobago overturned
Why are these purple flowers shutting down streets in Sydney?
Price of school dinners to go up for a second year in a row
Scottish Labour leader says the UK should re-join EU
Teens found guilty of murdering boy, 15, in park
US pilot arrested at Heathrow admits drugs offence
Inside devastated front-line city that Russia wants Ukraine to give up
Rare cancer discovered after mum underwent hysterectomy
Pochettino, Howe, Emery... or Carrick? Man Utd's managerial options
Twelve dead after motorway pile-ups in Bulgaria fog
School's strict rules led to boy's death - inquest
Needle-free allergy treatment in Guernsey?
Board of Peace says Israel's aid response after Gaza floods 'insufficent'
US military aircraft leave second UK base
Sales of tinned food and bottled water jump after 'Be Ready' campaign launch
Jury discharged in Chloe Mitchell murder trial
Formula 1 to finish season in Middle East
Thousands of 'off-grid' homes eligible for £250 to help with heating bills
'Blatant disrespect' - Row over DUP bid to veto Irish education bill
David Walliams' career and controversies including Britain's Got Talent and Little Britain
Anthropic heads for lower than expected $1.3 trillion valuation in stock market debut
Birthdays and broken lamps - at home with the Charles brothers
Arrests made in Mohamed Al Fayed probe in France, police say
Edinburgh Academy pupils suffered decades of 'dreadful abuse'
How did Mildenhall become crucial to the US Air Force?
Kompany back at Bayern training after collapse
Shopping centre will 'make Wakefield the city to be in'
Met Police investigating more 'potential criminal allegations' about Brand
York man, 19, shot and injured in Krakow attack
Australia doomed to live with stench of sandpapergate
Man who stole ambulance with patient inside jailed
New regulation for heating oil market, but no price controls
Tories pledge to cut benefits for children with 'milder cases' of ADHD
French wartime resistance heroine Solange Alexandre dies aged 104
California police investigate after 27 fall ill at half-marathon running event
Israel's new parliament to be sworn in as leaders compete to form government
Watch: Meghan's first public appearance since father arrested
Hill gets first England call-up as Konsa cover
Jockey Neale, 22, dies after fall during race
Amber alert as Scotland faces blood donation shortages
Police officer dies and another injured after backpack explosion in northern Spain
Israeli forces kill Palestinian boy in West Bank, health ministry says
Festival headlined by Andrea Bocelli scraps choirs fee after backlash
Kim Kardashian's Skims offers refunds for $148 advent calendar after backlash
Watch: Man smashes Chinese government building with excavator
Holiday hunger bill to face final Stormont hurdle
Faisal Islam: What the boss of US tech giant Nvidia told me about China and national security
DR Congo sentences 66 soldiers to death for being 'cowards'
Patch of one of UK's rarest flowers saved from falling into the sea
Oxford museum returns ancestral Naga skulls to India
To the day I die, I will regret putting a cigarette in my mouth
Dexter and dog Reginald offered place to stay before Christmas as part of PM's pledge
Divorced after five days: 'My sham husband made me believe he loved me'
The fans at the foggy FA Cup game no-one could see
Polish unity on show as thousands join silent march for Krakow shooting victims
Australia considers criminal penalties for rogue AI in wake of OpenAI hack
Californians reject wealth tax for billionaires
Qantas to outsource 850 local jobs with most roles moving to India
'Cruise for life' ship Villa Vie Odyssey seized in Singapore
Republican congressman to force impeachment vote on Defence Secretary Hegseth
Early prisoner release: More offenders to leave jail on Tuesday
The Papers: 'Brand jailed for 10 years' and 'shamed star caged'
Prince William wants more protection from harassment for service women
I took Vinted to court to get my money back
My life as the UK's youngest lighthouse keeper
Epstein associate who still runs model agency 'put me in danger' says abuse survivor
Plymouth Parkway beat Berkhamsted to reach FA Cup second round
Ukraine peace talks resume with 'some flexibility' by warring sides, US officials say
The superpower battle over energy – and what it means for your bills
Initiative launched to make UK world leader in women's sport
Headteachers say families will struggle after another rise in school dinner prices
Sabalenka wins WTA Finals opener despite wayward serve
Judge denies motion to dismiss Lindsay Clancy's murder case
Man Utd expected to sack head coach Carrick
NHS boss received nearly £400,000 'redundancy' pay-off when she retired
Phones to be banned from pupils' bags or pockets under stricter rules for schools in England
I almost died after a toothache led to sepsis and a rare heart condition
Brady ends association with Birmingham City
'Baffling but brilliant' post-apocalyptic novel The End of Everything wins Booker Prize
Brand's ex Jemima Goldsmith accuses him of violence and abuse against her
Zoe Kleinman: Nvidia CEO's affair will cause ripples across US and beyond
Trial date of alleged Charlie Kirk killer set for June 2028
Turkey steel factory blast kills at least 17 people
What happened inside court as Brand was sentenced
Nvidia shares tumble over investigation into Huang's affair with alleged Chinese spy
Millions fill Buenos Aires streets to welcome Pope Leo XIV
The facial recognition technology stopping shoplifters
People don't know full story behind England exile - White
How a civil servant got away with juggling five jobs for so long
England wing Feyi-Waboso out of Nations Championship
Russia's leading independent newspaper closes after eviction
Russell Brand sentenced to 10-and-a-half years in prison for rape and sexual assault
Detective stole more than £85,000 from police force
Civil servant who secretly held five jobs found guilty of fraud
Paramedic injured while assisting patient
Nine Zimbabweans caught allegedly trying to leave South Africa to fight in Ukraine
Men recruited to French gang as children to kill give rare insight into drug underworld
France accuses Iran of supermarket fridge hacking
Suspended Reform councillor found guilty over post
Poundland unable to buy new stock as fears over collapse grow
Aberdeen sack Robinson after league slump
Levenshulme community alley garden restored after clearance mix-up
Senior doctors at Glasgow hospital in care delay warning
At least 39 die after Europe-bound migrant boat sinks off Senegal
Real Madrid legend Raul named Real Oviedo manager
Action on energy costs is my overriding aim, says Fahnbulleh
What we know so far about Jensen Huang's affair with suspected Chinese spy
'Electrical items caused' fire that killed mum and kids
Ground Force and Homes Under the Hammer star Tommy Walsh dies aged 69
James Bulger's killer to stay in prison after parole hearing
Watch: Moment judge sentences Brand in court
How Hawkins overcame illness to star for England
Bronze named in World 11 for record ninth time
Who is the suspected Chinese spy at centre of the Nvidia investigation?
Incident-by-incident: Was it a bad weekend for VAR?
Thirteen migrants die after boat sinks off Crete
Rising cost of living tests UK's net zero ambitions
Passenger feared Huntingdon train attacker was suicide bomber, court hears
Man jailed over racist Badenoch death threats
Thick fog disrupts travel with further weather warning issued
Government's EV targets expected to be reduced this week
England clear way for Carse return and drop Bashir
Krakow shooting suspect has died in hospital, police say
Brand should acknowledge suffering, says granddaughter of Andrew Sachs
Psychiatric intensive care unit for women to open
Find out who's in the running for this year's Booker Prize
'I've got a band now' - Club anthem star Shygirl on why she's switching up her sound
Four killed in Gaza after sand embankment collapses onto tents, health ministry says
Woman says Al Fayed's brother drugged and sexually abused her at Highland estate
New GP contract deal a 'start' but more funding needed, BMA warns
Khawaja 100% accurate on ball-tampering - Warner
Is it the end of free school milk?
Sports Personality of the Year returns - with five awards decided by public
What do we know about Nvidia CEO’s affair with a suspected Chinese spy?
What we know so far about the next James Bond film
'My brother died, so I smashed up his TV'
Michael Ball's wedding surprise after radio proposal
Hut owner wins battle to keep living in off-grid home he built
How you can get council's £250 cost of living help
Cancer survivor calls for fertility funding change
Plane lifted into back garden as bunker takes shape
'Painful condition meant I had to leave my job'
Inside the French drug gangs recruiting children to kill
Pope delivers veiled rebuke of Milei's austerity measures
Cruise ship pianist rescued from sea after nine hours in Pacific Ocean
Society needs to act to help white working-class pupils, inquiry says
A glimmer of good news for Britain's sleepy dormouse
What's your love language - and does it actually mean anything?
Doing these things now will help you save money at Christmas
Top House Democrat 'a hard yes' on impeaching Pete Hegseth
Nvidia launches investigation into CEO's affair with suspected Chinese spy
Falkirk add goals and grit to McGlynn's guile on rapid rise
Norris wins gripping race after Antonelli and Russell errors
Doctor who treated victims of Krakow shooting speaks to the BBC
Oldham Athletic shock Sheffield Wednesday with extra-time winner
Norris brilliant in wet & Verstappen recovery extraordinary - driver ratings
Free school milk scheme could end after 50 years
Bizarre & thrilling theatre as Carrick's Man Utd future still in limbo
Aramco Tower hit in heart of Saudi capital as Houthis launch fresh strikes
Maya Jama steps down as host of reality TV show Love Island
Villa's Kamara on Chelsea watchlist - Monday's gossip
Palace consider replacing Sage with Frank among contenders
Who has made Troy's Premier League team of the week?
Where does Man Utd 4-4 Villa rank among best Premier League games?
Man Utd score twice in stoppage-time to share points in eight-goal thriller
Seven dead and more than 100 injured after trains collide in Egypt
Feyi-Waboso burns bright as England energy endorses Borthwick
Are 'outstanding' Brighton now Arsenal's main title challengers?
Paramedic sustains multiple injuries in hospital assault
Secondary schools told to stop teaching GCSEs before Year 10
Surgeon having lunch near Krakow shooting undoubtedly saved officer's life, colleague says
'Tinkerman' Alonso's Chelsea side still searching for identity
Alcaraz takes revenge on Shelton to win first Paris Masters title
Footage shows derailed carriages after fatal train crash in Egypt
Two arrests and police officers hurt after brawl outside bare-knuckle fighting event
'Time is up': Minister warns media industry to take abuse seriously in wake of Brand case
King leads solemn Remembrance service at Cenotaph
Iran executes three men for 'armed unrest' after January protests
Rahm pips Hatton & McIlroy to Abu Dhabi title
Nandy rejects claims of politicising Remembrance Sunday after Erasmus row
Dormice 'thrive' at National Trust site
Watch: Royals and veterans reflect at Remembrance ceremony
Last season difficult with injury and miscarriage - Muniz
Government 'looking seriously' at banning under-16s from Vinted and eBay
I didn't throw anyone under the bus with ball-tampering revelations, says cricketer Khawaja
How the deadly shooting in Krakow unfolded
'Cancer treatment plummeted me into menopause'
Drone footage shows Black Cat roundabout progress
We face paying £9,000 tax even though our second home is in a war zone
School Street fines at one location exceed £1m
Grenfell NHS support service faces funding cut
Onions in your socks? Why homespun cold remedies can work for some
'I can't believe he is one of us' - inside Salah's life in Trabzon
I won't let my daughter's killer live in my head, says Sarah Payne's mother
Traders 'priced out' of £12,000 Christmas market pitches
Airbnb cleaning rule changes will 'absolutely' hit Wales harder, says host
Former lorry driver, 91, knits 200 woolly hats
Two seriously hurt in 30-vehicle crash on the M20 in Kent
My parents chose to die together and I was left to grieve alone
Briton among six killed in 'far-right' shooting in Krakow
Ambika Mod wants to change how South Asian women are seen on-screen
Germans wrestle with what to do with Hitler's destroyed Eagle's Nest retreat
'Soap operas on steroids': Microdramas are going mainstream
Can the Zelda remake capture the magic of the original?
Thousands watch elaborate carnival cart procession
Labubu hype seemed unstoppable, now the fluffy monster mania is fading
What we know so far after Krakow gun attack
Israel's president tasks opposition leader Eisenkot with forming government
Rotherham end 10-game losing run with FA Cup win over Bromley
Adeeko's extra-time winner sends Fleetwood Town past Rochdale
Port Vale defeat non-league Scunthorpe in FA Cup
There's finally a treatment for my five-year-old's dementia - but it'll cost me £3m
Veterans shouldn't sleep rough this Christmas, Burnham says
Match of the Day
Glasner glee and Delap double - win could be lift-off for Forest
Ipswich Town's new club shop 'here to stay'
Can New Zealand's new government win over disillusioned voters?
Notts County beat Altrincham in incredible fog-filled spectacle
McGeehan hat-trick powers Barnsley to 7-2 win over Aldershot
World number one Rybakina withdraws from WTA Finals
Wales let themselves down despite win - Lake
Scotland's familiar frailties brutally exposed in All Blacks schooling
Maresca's dream start turns into nightmare as title hopes hit
Norris takes pole in rain-delayed qualifying
Maresca looking to understand Man City's 'lack of intensity'
Delap double inspires Forest to stunning win over Man City
Muniz strike denies Newcastle and Jaissle much-needed win
Another 1-0 for relentless Arsenal - but did Odegaard spare VAR blushes?
Rob Brydon's battle to stay in character playing Peter O'Toole
US offers $20m reward for information about Iran's nuclear programme
Gaza wedding festival sees 250 couples married at the same time
Andy Burnham wants to get closer to the EU - but he shouldn't expect a smooth ride
Houthis say at least 25 killed in Saudi air strike
Italian foreign minister says hackers leaked his personal data
Tens of thousands of tents flooded after heavy rains in Gaza
Third person arrested after car damaged by gunshots
No clear winner after tight New Zealand general election
Evacuations in Liverpool city centre after car crash causes gas leak
Baxters fish soup cans recalled over fears they could 'swell and rupture'
Ireland going from strength to strength - Murray
Knicks defend Taylor Swift after players name her 'fakest celebrity fan'
UK cannot 'cherry pick' EU single market deal, Barnier tells BBC
Ukraine's power network suffers further damage after fresh Russian strikes
My dream is to win Ballon d'Or - Gabriel
Relief, tears and sadness: Married at First Sight UK cast react to show being axed
Roman settlement dating back 2,000 years found under new-build estate
Victims in rape cases must not feel like they are on trial, Burnham says
Monty Don bids 'final goodbye' to Gardeners' World after two decades
Two men arrested after boy injured in sword attack
From young offender to resident doctor: 'I wrote a plan and stuck to it'
Boy, 4, dies after Range Rover crashes on country road
Texas mayor instructs police to limit co-operation with ICE
AI in property listings is false advertising, house-hunters say
Period products 'essential not optional'
Paraguay's president impeached after collapse of bank
I left Man City for my mental wellbeing - Trafford
We thought mum abandoned us - then we discovered she'd been murdered
Pope in 'pretty good health' as he starts Latin America tour
'You feel that you're not alone' - the young people finding community in grief
Beach homes face demolition months after being sold
Parliament restoration delays 'frustrating', says Commons Speaker
The Papers: 'Meghan's father charged' and 'Brand investigation widens'
One of the year's most prolific meteor showers to light up the night sky this weekend
Skepta: 'I'm what it looks like if you give an immigrant child a chance'
'My mortgage is going up £200': How rising interest rates are hitting people's pockets
Gladiator II stuntman sues over injuries from on-set explosion
This man refused life-saving treatment because of his religion - days later the rules changed
The young Somali woman changing how the world sees Mogadishu
What happens if all the lights go out? This is the plan for a 'Black Sky' event
Bristol Rovers shock Cambridge United to reach round two
Coventry City: Frank Lampard questions decisions after Sky Blues fall at Everton
Whole Australia team knew of sandpaper use - Khawaja
Man, 41, and boy, 16, arrested after car damaged by gunshots
'Big decisions' affected the game - Lampard
Not a good performance, but we got a result - Moyes
Alcaraz beats Fritz to help Jodar reach ATP finals
Barry scores twice as Everton fight back to beat Coventry
Man, 35, charged with murder of Carrie Mullane
WTA chair apologises to Pegula for airing of 'diva' comment
Cornell faculty pass no confidence vote over leadership's handling of Jane Doe allegations
Keenan hat-trick as six-try Ireland beat Pumas
Raith Rovers go top with Dunfermline draw
Child, 6, dies weeks after Waterford arson attack
Meghan's father Thomas Markle appears in court over child sex abuse material
Real Madrid and PSG keen on Suzuki - Saturday's gossip
Ferrari's Hamilton-Leclerc problem - and other F1 stories to follow
Harry and five others seek to challenge Mail publisher privacy ruling
Why the US midterms sparked an AI stock selloff
Dutch launch shows smugglers are adapting, says MP
Should energy drinks be banned for under-16s?
Spain's rail authorities face European fraud probe after Urda rail disaster
Why smoky bacon crisps threaten to reignite rows over EU rules
Under-16s could be banned from buying energy drinks in Wales
Dozens of Democrats eyeing 2028 presidential run, says former Obama aide
Brand's barrister refers himself to regulator after report he confronted journalist
Food bank to close amid rising costs
Winter support for residents facing cost pressures
Spate of bomb threats poses serious challenge to airline industry
New wave of bomb threats hit European airlines
RuPaul's Drag Race UK crowns winner as BBC axes the series
AI stocks climb after trillions wiped from market values
Watch: Is it the end of the road for Tesla's Cybertruck?
Tanzanian opposition leader found guilty of inciting unrest but acquitted of treason
Workers' rights 'second place' to economic growth
Burnham says he was not aware of Brand's 'horrific' crimes
Bonfire Night violence condemned as six arrested
Kenyan doomsday cult leader given life sentence for murdering 191 people
Policing needs reform to cope with modern criminals, Met Police chief warns
Two dead after bus crashes in France, officials say
Some media firms evacuated after hoax bomb threats
Portugal coach 'knew nothing' about Ronaldo retiring
Two Gloucester schools in lockdown after boy hurt in incident
Childminder who left more than 20 children alone in her home jailed
'Incredible achievement for the family' as Bellingham brothers called up
Fly-half Smith fit to steer England against Wallabies
Met chief says he wouldn't be surprised if more allegations made about Brand after rape conviction
Harborough sign 6ft 9in striker Hudlin before FA Cup tie
Tube drivers to stage strikes in Christmas run-up
Talking points as Premiership prepares for international break
England secure group top spot with Ireland win
Women's rights matter more than any league, say Afghan cricketers
US midterm results spark fears in Israel over future of two countries' ties
Train worker recalls repelling Huntingdon attacker with frying pan
Parents warned to be on alert after school data breach
Wales scraps controversial Uganda tree-planting scheme
Katherine Ryan says she feels 'grief and relief' after Russell Brand conviction
Westwood worried for DP World Tour after LIV collapse
'It would be pretty special' - Chessum on England captaincy links
Russian extremist group denies sending hoax bomb threats
Man investigated for leaving 17-year-old on Germany's highest mountain
MTV Dirty Sanchez star Michael 'Pancho' Locke dies aged 47
How 2000s lad culture helped Russell Brand to hide in plain sight
'Clicky Ponting' cheating scandal cricketer banned from sport for two years
Has Anderson lived up to the hype after Man City move?
Palmer misses too many chances to impress - Tuchel
'I've taken an extra job to pay for heating oil'
Jail and health board admit criminal charges over Covid death prisoner
Newcastle's Dedic stopped by police after being spotted with bow and arrows
Olivia Rodrigo's Christmas song sounds familiar... on purpose
'Major milestone' as beavers released into Loch Ness area
'Leave us alone, just let us run' - the women harassed and followed by men at night
Homes and temples glow across India as Diwali celebrations begin
What to know about the presidential wiretapping scandal rocking Indonesia
Algorithm allocates Highland 'significant increase' in asylum-seeking children
Elon Musk appears to signal the end of the road for Cybertruck
Two boys charged over Halloween party stabbings
How does it affect me if share prices fall?
Somalia's top court rejects president's term extension amid political crisis
Major construction ongoing near Iran missile bases, satellite images suggest
Dolly Parton's scheme to send free books to children brought back
Macau jails pro-democracy campaigner in city's first national security case
Reform councillor's post branded racist by Labour
Health minister instructs trusts to pause cuts to Phone First service
How computer game Worms went from classroom to classic
'The veil of shame around postnatal depression needs to go'
Glasgow children's hospital begins robot-assisted surgeries in world first
'He'll regret it': The day Alex Ferguson quit Aberdeen for Man Utd
AI teddy for three-year-olds makes unprompted 'I can't help with killing you' remark
'Misleading' student loans information left out examples of higher-salary repayments
Did a data centre revolt affect the US midterm election results?
A wildfire killed their loved ones in Spain. These British families demand to know why
Home Office investigating after BBC catches lawyer offering to make fines go away
Democratic socialist defeats incumbent Karen Bass in Los Angeles mayor's race
How unprecedented changes to the polar vortex may impact the UK's weather
Tempted by snacks before bed? Here's why - and what you can do about it
Andrew received up to £2,000 per month from sub-letting, watchdog reports
Duran & Osmand spark Celtic into life - but where does that leave Hogh?
Thatcher's Right to Buy split my estate. Now its days could be numbered
The engine parts that 'fight the laws of the universe'
Major tech stocks plunge as US midterms add to fears of AI slowdown
Police officers reunited with baby they helped deliver in back of car
Pope begins lengthy trip to Latin America weeks after lung cancer surgery
'I was asked if I was a crier': Your worst job interviews revealed
'Not my job to set a budget,' says secretary of state
Anderson could be given chance to join Surrey
Delhi's toxic winter air is back - is the Indian capital prepared for pollution?
Police car set alight in Glasgow amid Bonfire Night trouble
California governor commutes sentences for state's 548 death row inmates
Firms told to publish salaries in job adverts ahead of new law
Forest need balance between Woodstock and military - Glasner
Keep or sell Konsa? - FPL gameweek 10 dilemmas
King relishes 'politically charged' deployments, Palace aide says
Nigerian court rules opposition candidate cannot stand in elections
Friday's gossip: Man Utd contact Deschamps
UK doctor infected with Ebola being treated at London hospital
Antonelli says 2027 preparation starts now
More Mandelson papers set to be published before Christmas
Over 1,000 tonnes of sewage seen at landfill site
Who could be behind hoax bomb threats to European air travel?
Zimmer frame thrown at train attacker, jury hears
Eight killed in series of shootings in western Turkey
Chris vs Chris: Who's running and what's at stake this New Zealand election
Met 'reset' means fewer police at major events
England check on Palmer - what are Tuchel's other big choices?
School failed to deal with racist bullying, father claims
Henry Nowak’s killer has minimum term increased to 25 years by Court of Appeal
'I don't fear for my safety from online abuse - because we're so used to it'
Russell Brand found guilty of rape and sexual assault
Messages reveal how hoax threat was passed on by air traffic control
Paraguay President Santiago Peña resigns after bank collapse
Hoax bomb threats target European airlines and airports for second time in a week
Swinney criticises UK move to ban new North Sea drilling
Brothers warned health trust days before man's death
Watch: Met Police release Brand interview footage
Met PC who taunted and hurt homeless man is sacked
'Flawed' training contributed to officer's death
Everton's Grealish unavailable again after 'breach of discipline'
Drunk and dangerous e-bike riders face on-the-spot fines under crackdown
Why do veterinary fees and sausage rolls vary in price across London?
More women likely to come forward, says detective who led Russell Brand investigation
Six dead and others injured in fire at New York City building
What new Kane deal means for England and the Premier League record
France holds new strikes and protests as unions demand immediate answers
The Russell Brand I saw in court was not the flamboyant character most people will know
Family thankful for support as De Miguel funeral held
A bitter end for Ronaldo - the icon who transformed Portugal announces international retirement
Watch: How rapist Brand was never far from controversy
Pegula calls Andreeva 'a diva' after practice session
What does the raise in interest rates mean?
AirTag hidden in historic wall reveals stone thief
'You've had a wonderful life Tommy, but it's over' - Sir Tom feared he was dying
Joshua Wong, face of Hong Kong's pro-democracy protests, jailed for 10 years
Two more arrests after Halloween party stabbings
Scotland's Russell and Tuipulotu return to face All Blacks
Putin not invited to G20 summit in Manchester, says Burnham
Could this be the last Bonfire Night for noisy fireworks at home?
Faisal Islam: How high will interest rates go?
'Taking people for fools' - Gloucestershire to rebrand as Bristol for T20 Blast
Three ways the interest rate rise could affect you
Married at First Sight UK cancelled after BBC revealed rape allegations
Midwives concerned over possible baby unit closures
The Pitt and ER are similar enough for lawsuit to proceed, judge rules
Welsh aviation firm AerFin bought in £475m deal
Watch: Was an Italian chef really fired over refusal to put pineapple on pizza?
Former F1 champion Jones dies aged 80
Second buyer makes rescue bid for Poundland as retailer faces collapse
India's costliest film retells a beloved Hindu epic - but divides critics
Altar Stone mystery continues as Stonehenge theory overturned
Former permanent secretary alleges he was 'bullied' by education minister, says MLA
Food, fuel and taxes – can the Democrats actually make life cheaper?
Knitalian: Artist uses yarn to create Italian deli
Parliament faces 'grave risks' as more asbestos discovered ahead of revamp decision
UK commits to 'time-bound' talks on slavery apology
Pope Leo hosts Bob Dylan at official residence in Rome
Australia's oldest department store David Jones folds after 188 years
Would you take a test to see if your life will be cut short? I did - and it changed me
Why a US-funded vaccine trial on babies was cancelled in Guinea-Bissau
The NHS is relying more on charities - and that might be creating problems for patients
Interest rates expected to rise for first time in over three years
Mother and daughter die after suspected grizzly bear attack in Canada
Pound rises to its highest level since the Brexit referendum
Why Iraola's Liverpool are still a work in progress
World record 51 red cards shown in Brazilian youth game
Typhoons batter East Asia as El Niño makes Pacific 'burn with fever'
Surreal moment Tarantino and Kylie Minogue came to my hometown to star in my new film
£200m taxpayer-funded trains sit barely used for three years
Police in Scotland to escort fire crews in latest crackdown on Bonfire Night disorder
Ukraine says bodycam video shows deadly Russian double-tap bombing
Como score nine to make Champions League history
No end in sight for Russell as he eyes famous All Blacks win
Another 'miracle' in Istanbul - but this one hurt Liverpool
'Hopefully things get done': Americans react to historic political shift
LIV Golf to wind down after backers withdraw support
Dortmund take narrow win over Real Betis
Emphatic Porto thrash Napoli in second-half romp
Haaland scores winner as Man City beat Leipzig
Arsenal survive late Slavia scare for hard-fought win
How voter shifts in Texas helped elect a Democratic senator and governor
Fewer mothers to appear in court days after giving birth under new guidance
An island in mourning: Tenerife processes death of De Miguel
British man infected with Ebola in DR Congo to be flown back to UK
US midterm results a 'victory' for Canadians hopeful of tariff relief
What Democrats can and can't do with their new power after taking Congress
Cocaine overtakes heroin as leading cause of drug deaths in England and Wales
Palestine Action ban undermined confidence in anti-terror laws, Supreme Court told
Tributes paid to drummer with dozens of number ones
Police launch inquiry after two inmates die in prison
Man hid woman's body in freezer for three years, jury told
Power deal between Labour and Greens in Sheffield
Watch: PM and Ed Miliband play steel drums in Antigua
The young politicians with African roots making history in the US midterms
Brigitte Bardot inheritance row deepens after private letter to partner leaked
UK government to outlaw new North Sea drilling
Israel's president begins consultations with parties after election deadlock
Secret police files released in Hungary, 37 years after fall of communism
Police seize £12,000 of fireworks set to be sold online before Bonfire Night
Russian hacktivists say they were behind freezer hacks, but speculation remains
Mother of Ghanaian boy killed in US 'wants justice' as she flies for funeral
Kellogg's admits snap, crackle and pop is quieter after uproar over Rice Krispies recipe change
Man fighting for custody of badger he nursed back from starvation
Ocon dropped - is it the end of his F1 career?
Time to focus on cost of living, says PM after US election results
PSNI pays damages to relatives of murdered UVF victims
James Talarico becomes first Democrat to win Texas Senate seat since 1988
Casey, Jansen and Timoney start against Argentina
Effigy of Fifa president chosen for bonfire event
Everything you need to know from the US midterm elections
Chloe Mitchell murder accused 'dismembered body', court told
'Such terrible waste' as health trust buildings could cost an extra £20m
Elon Musk's millions fail to deliver Texas for the Republicans in fierce midterms
Nadal set to join Real Madrid board of directors
Huntingdon train attack passengers thought stabbing was a 'joke'
Stonehaven train derailment could have been avoided if drain built correctly, says sheriff
Five reasons why Republicans lost so badly
Angler's 52kg carp catch hailed as world record
Sharp objects found in Halloween sweets in three European nations
Iran's chief negotiator says Americans voted 'no to war'
Poundland owner in crunch talks as retailer's collapse looms
West Ham confirm Parker as boss
LIV aimed to 'destroy the European Tour' - McIlroy
Could Hyrox's Olympic ambition spell the end for triathlon?
Real Madrid reach verbal agreement to sign Gabriel
Fourth arrest after Halloween party stabbings
ANC under pressure to reverse South Africa decline
Rwanda's army team removed from Africa league after US sanctions, NBA says
Daniel Thomas faces trial in 2027 over migrant site accusations
Goalkeeper Owono 'would never intentionally hurt anyone', team-mate says after De Miguel death
Children spending too long on maths app TT Rockstars, MP warns
Celebrity hairstylist John Frieda dies aged 75
Fleabag star offers rent-free flat to new writers
Scottish government needs to act faster on grooming gang inquiry, says survivor
GB's Stojsavljevic, 17, claims first WTA Tour win despite short notice
Left-wing Democrat Abdul El-Sayed wins in Michigan to become first Muslim senator
How America voted in maps and charts
Tears, celebrations and selfies: US midterms in pictures
Delhi air quality worsens ahead of Diwali as firework restrictions enter force
Florida Republicans fend off Democrats as state elects first black governor
Housing targets threaten ancient woods, campaigners warn
Scottish colleges need £2.5bn investment boost by 2037, report warns
Family 'in hell' as critically ill baby stuck abroad
Swim and gym prices set to rise above inflation
Code cracked for shipwreck padlock solving 400-year-old mystery
Hampshire woman, 101, gets Ohio birthday card in mayoral mix-up
Warning after 'metal pins' found in Halloween sweets
Miliband says slavery apology will not bring cost for UK taxpayers
Killer who escaped Tennessee prison captured after week-long manhunt
Chill to grip Bonfire Night as temperatures dip into single digits
Why Kim Kardashian came back to 'the worst TV drama ever'
Scammers using AI-generated images of missing pets to demand reward money
Canva announces major job cuts after 'our hardest year yet'
Graduates are managing AI - but are they learning much else?
'Multi-cancer' blood tests coming to some GP surgeries in England
'I'm not a quitter': Kim Kardashian on retaking the bar exam
Emery takes positives - but Villa 'have work to do' to reach Barca level
Jesus de Miguel: Tributes paid across Europe to Tenerife striker
Champions League comebacks: What are the other best after Manchester United beat Roma
We don't need to save anyone's job, says Man Utd captain Fernandes
Swansea City: Stephen Welsh knee injury adds to misery at Portsmouth
Prince William says UK faces terrifying risk of more wildfires due to climate change
Spanish transport minister resigns days after deadly train crash
NTSB says crucial plane parts found three miles from Florida crash site
Newcastle and Palace progress in EFL Trophy
Man Utd eye Man City's Ait-Nouri - Wednesday's gossip
Ocon dropped by Haas for rest of season after row
Rural health board shake-up opposed as locals fight cuts to hospital beds
Seven flights across Europe targeted by suspected bomb threats
Welsh government mini-budget passes after Plaid-Labour deal
King calls slave trade a 'shameful chapter' during Commonwealth address
Death threats for Briton Burrage on WTA Tour return
Queues, smiles and Uncle Sam: The US midterms in pictures
Andrew Mountbatten-Windsor called to give evidence in fraud trial in December
Reform UK councillor charged with rape and sexual assault
Lorry driver electrocuted after vehicle hit overhead power line
I was told I was too young to have cancer
Rape accused 'told woman would pretend to be asleep'
How 'mogging' went from toxic term to mainstream
Speeding driver jailed for fatal Lamborghini crash
Irish Olympian Ciara Mageean was a 'talented and inspirational human being'
No babies to be born at hospital from end of November
King says slave trade a 'shameful chapter' that 'fills my heart with horror'
Death toll rises in Ukraine after Russia attacks aid centre, hospice and hospital
Keeping mortgage interest relief approved
Binance says fake job interviews used as part of $6.3bn crypto hack
Cambridge scientist killed in Spain train crash was 'a light for all of us'
What next for the DUP following Carla Lockhart's resignation?
How sporting events are being impacted by Middle East conflict
Teen admits bank holiday stabbing on beach that left 17-year-old with amputated leg
Americans on the value of their votes
Asda hires ex-Morrisons boss in bid to grow firm
DUP leader 'very sorry' Carla Lockhart has quit the party
Rio Tinto joins fight to stop killer toad march across Australia
Libya's top religious authority rules against wearing Nike clothes
Jury in Russell Brand rape trial begins considering verdicts
RFL backs Wilkin's £30m funding plea to Burnham
Third teen arrested after Halloween party stabbings
Charity warns about damage of over-foraging fungi
Celebrity loses injunction bid but will stay anonymous pending appeal
'Fully loaded' All Blacks out to preserve Scotland record
England's Mitchell ruled out of Nations Championship
The Crown star Josh O'Connor reacts to Bond rumours
Binet 'embarrassed' by cancelled appointments
Watch: Why is 'Mogging' the word of the year?
Europe on alert after supermarket freezers hit by cyber-attacks in 10 countries
Girl who rescued injured boy from bonfire acted 'on instinct'
Jet may have broken apart before Florida crash, officials say, as family named among victims
UK meat industry hit by cyber-attack which targeted European supermarket freezers
West Ham approach Parker after sacking boss Nuno
US urges Venezuela to release remaining political prisoners
UK and EU agree draft deal to scrap Brexit red tape over food exports
Alton Towers closes World of David Walliams
Drivers may get compensation offers before car finance saga ends
Indian tourist killed after two helicopters collide near Everest base camp
US strikes Iranian island ahead of midterm elections
'I never enjoyed exercise at school as I was bullied' says DJ, ahead of 400-mile bike feat
McTominay returns as Penrice earns first Scotland call
Work finishes at rail junction near power plant
Proposal for free bus service scrapped
'Quiet quitting' could be hitting the economy - here's why
Mahmood refuses to put cost on care worker settlement climbdown
MI5 will not face contempt of court charges despite admitting its evidence was a lie
How the US midterm results could unfold - as millions of Americans head to the polls
Which stars have made the leap into US politics? Try our quiz
North Korea denies being behind record $6.3bn Binance hack
When will we know the results?
How to follow the US midterm elections on the BBC
Why a US-Russia showdown left Morocco celebrating
Major study into 'forever chemicals' in people's bodies launched in UK
Asian Cup postponed in wake of attacks on Saudi Arabia
The referee who became a role model after bouncing back from Diaz error
James Blunt on Traitors: I tried - and failed - to get banished
New pictures released ahead of The Other Bennet Sister Christmas special
Police admit unlawful home entry and assault of couple
Public venues offer tea and warm welcome in winter
Secondary school teacher to crofter - life on the UK's most remote island
Family of girl murdered by ex given law change hope
Scientists detect signals from the zeptoverse - the smallest scale of nature ever explored
Police question Steve Wright about unsolved cases
Dry and chilly start to November after wet but sunny October
Christmas 2026 stamps unveiled by Royal Mail
'Mogging' is Collins' word of the year... but do you know what it means?
From scooters to shampoo - the people saving hundreds from dumpster diving
Apple unsure when more foldable iPhones will be available after selling out
PM plans debt re-set for Commonwealth nations as slavery apology talks begin
Indian film star Ranbir Kapoor on AI, movies and fatherhood
Thousands of European troops to rehearse Ukraine deployment in event of peace
'One heck of a rollercoaster' - foster carers urged to come forward
The Papers: Mahmood's 'Duty of care' or 'climbdown' and 'The new cold war'
Jeers again as home woes continue - Jaissle has big problems at Newcastle
Legal challenge to Australia's social media ban to start in High Court
From nightmare debut season to Everton hero - Barry's revival
Grealish can still have Everton future - Moyes
Indonesia's toxic haze is giving its neighbours a political headache
Jaissle unhappy with 'clear foul' before Barry goal
I was told I had anxiety but it turned out to be breast cancer
David Bowie's Scottish links celebrated in new exhibition
Mahmood scraps settlement plans for migrant care workers
Labour MPs pull their punches on immigration changes
Russell says F1 title loss 'tough to deal with'
Russian bombing kills 26 people at Ukraine aid centre, Kyiv says
US midterms campaign 'shattering' spending records to be most expensive ever
Two boys arrested after Halloween party stabbings
Man guilty of stealing cash from farm owned by South African president
What Florida jet audio and flight data tells us about its final moments
Prosecutors hint at retrial for Lindsay Clancy on murder charges
What are the planned changes to immigration rules?
Honey cast and creatives talk about love triangles, cast-mates and being transported back in time for darkly comedic Cold War thriller
Fake nuclear warning from hacked app sparks unease but not panic in Ukraine
If hackers can take control of a supermarket freezer, how vulnerable is other tech?
MP Carla Lockhart quits DUP in Drumcree row
Man who drugged and raped wife with strangers 'led double life'
'All this food is now useless': Piles of rubbish after shop freezers hit by cyber-attack
Fighting returns to Kherson region after longest Ukraine war ceasefire
Dutch police offer record €2m reward in hunt for drug lord
British adventurer Karl Bushby completes 28-year journey
Teen had leg amputated after stabbing on beach on bank holiday, court hears
Reform council leader quits after staff comments leaked
Labour ends power-sharing with Greens in 11 councils over Zionism row
No10 defends flight to Manchester to collect Andy Burnham
Can Alcaraz's ex-coach help Shelton challenge his former protege?
'I decided I was going to be Taylor Swift' - singer goes from busking to The Voice UK winner
Carrick says it's 'crazy' but he's looking forward to Roma game
Borthwick turned down my offer to work with England - Edwards
Driver who dragged head teacher to his death jailed for life
Huntingdon train attacker said 'I am the baddest', trial hears
Shop freezers in seven European countries hit by cyber-attack
'New kit' helps battle against bugs
Karl Bushby reunited with his mum at home
Wizz Air flight from Luton makes emergency landing with fighter jet escort after bomb threat
What we know about the alert app hack in Ukraine and Russia
Nowak family say police failed them multiple times
A Paralympian vs a former TV news anchor - and other US Senate races to watch
Poundland's former owner offers to invest as minister prepares to meet board
Channel 4 documentary and journalists 'poisoned the well' against Russell Brand, court hears
Former transport minister used phone while driving
Man caught in car with £14k of drugs as a lamb ate chips in the back seat avoids jail
Chris Mason: Home secretary to face scrutiny over changes to rules for legal migrants
Mother told to book appointment to give birth to her baby who had died
Ryanair says it may freeze workers' pay and raise airfares
Hunt for attackers after Halloween party stabbings
Uganda begins withdrawing troops from Somalia after 20 years
Bottom club Sunderland to stick with manager Le Bris
Woman saved by CPR has 'another chance at life'
Government making up China policy as it goes along, say MPs
Five arrested after South African farmer shot and tortured
Lifestyle guru Martha Stewart says she 'really screwed up' with homeless Halloween costume
What Americans are voting for in this election
Parents' concerns to trigger urgent checks in A&E
Popular Australian children's author jailed over child exploitation offences
Binance users withdraw $3.6bn after largest-ever crypto hack
Could this robot help cut gynae waiting lists?
'It took years to get pain-relieving surgery - I hope a robot means others won't have to wait'
Christmas donations gift demand up, charities say
Christmas shoebox appeal launches to help children
Drugs, cash and weapons found in raids as e-bikes 'blight' communities
'I could barely stand up straight with menopause after cancer'
'I couldn't be silent': Iranian teen's mother seeking justice after daughter shot dead
Iran killed her teenage daughter - now she is facing up to the regime
China state broadcaster pulls La Liga matches following Mbappé joke
Watch: King Charles III caught in torrential downpour at Antigua and Barbuda parade
How 20-year-old Kimi Antonelli 'blew everyone away' to make Formula 1 history
'We've got big problems' - Hamilton says Ferrari need 'serious talks'
Democrats have high hopes - but are the polls right?
France launches attempted murder investigation after petrol bomb thrown at police
Don't get caught out by new Buy Now Pay Later rules
Tributes to 'inspirational' Olympian Ciara Mageean after death at 34
Kimi Antonelli becomes F1 world champion as Max Verstappen wins Mexico City Grand Prix
Ukraine air raid app apparently hacked as users receive false radiation alert, Air Force says
'I've had people eating cat food': Rising cost of living top of mind for US voters
Antonelli - the boy 'born in a garage' who became world champion
Nine killed in 'horrific' Florida jet crash
'I felt ostracised due to cleft lip'
Cleft lip filler 'boosts confidence' - but expert warns of exploitation risk
Russian strikes cut power to thousands in Ukraine as Kherson ceasefire ends
Democrat endorses Republican candidate in key Michigan Senate race as party spat erupts
I'll tell my players to dive in future - Iraola
Warnock hid seizures from Liverpool as a youngster
Watch: Bundesliga highlights - matchday eight
From Fleetwood embarrassment to 'magical' Anfield win 14 years in making
Boy, 14, hands himself in to police over Bradley Lowery video
Arsenal move clear at the top with a rare win at Liverpool
'Everyone saw it' - Iraola confused by Isak penalty decision
Arteta credits Fleetwood loss for spirited win at Anfield
Peaceful protests in Germany spiral into violence and looting
Armed police start patrols in Sydney after Bondi Beach attack
Nowak family tell of 'unbelievable pain' of seeing footage of dying son handcuffed
Lindsay Clancy is back in court - where will her case go next?
After a 28-year trek around the world, homebound Karl Bushby crosses the Humber Bridge
Israeli strikes in Gaza kill eight including child, hospitals say
Thousands of jobs at Virgin Media O2 to be cut
At risk in-person postpartum mums' groups saved
‘My vote still matters’ - Americans weigh in on the power of their ballot
Cancer patients 'deteriorating' due to staff shortages, radiologists warn
Second night of drone disruption at Jersey Airport
King to address slavery during Commonwealth speech in Antigua on final leg of Caribbean tour
Green Party at 'crossroads' after Zionism vote, says former co-leader
Five teenagers stabbed at Halloween party
Seven arrested after city centre firework disorder
Yamaha will not travel to Qatar for MotoGP race
Police probe video of officer hitting youth with handcuffs
University of Cambridge scientist among those who died in Spanish train crash
More than 300 arrests at Palestine Action support protest outside US embassy
MP facing voice loss after surgery shows recovery signs
Crochet novices create cascading poppy memorial
Aquarium shark that helped 'dispel myths' dies
Shops looted as German cost of living protests turn violent
Sir Tom Jones mentors Cardiff singer to victory on The Voice UK
Britain's Dart wins first WTA title of her career
Sheff Wed appoint former Stockport boss Challinor
Reeves says UK's future should be inside the EU
Former European champion and two-time Olympian Ciara Mageean dies aged 34
Northern Lights dance across UK sky on Halloween night
Police tackle 144 Halloween fireworks incidents across Scotland
A severed hand and The Shining twins: The best celebrity Halloween costumes
New charity uses outdoors to improve mental health
Anfield, intensity, rotation - how Iraola is improving Liverpool
Energy bills help 'doesn't go far enough'
Diwali hampers to bring hope to families in need
India's opposition holds mega rally seeking election chief's resignation
University staff warned of 'difficult decisions' ahead over finances
Democrats are used to heartbreak in Texas - could Talarico turn the tide?
Watch: Heidi Klum as giant severed hand for Halloween bash
These firms you've never heard of are feeding fears the AI bubble could burst
How the downfall of Serbia's Vučiċ mirrored that of Hungary's Orbán
No more washing up: Airbnb's new house rules divide hosts and guests
The iconic 2005 Oasis concert from the City of Manchester Stadium
Who are the real winners of Celebrity Traitors?
Why Is Andy Burnham Saying He's Open To A Slavery Apology?
I've been stuck on a tiny Pacific island for years because of visa rules
Chelsea beat 10-man Man Utd to pile more pressure on Carrick
Brighton pick up first away league victory over Man City to go third
Coventry out of bottom three after win over struggling Sunderland
Enciso's stunning goal earns Ipswich draw at Hull
Spurs revival continues with victory over 10-man Crystal Palace
Evanilson scores again as Bournemouth beat Leeds
Thiago on target as Brentford beat Forest
Suzuki mistake gifts Fulham point at Villa
Mexico City Grand Prix qualifying result: Lewis Hamilton takes pole position
Crypto firm Binance covers 90% of losses after $6.3bn hack
'Fascinating' rare beetle found in Wales again after 60 years
Hospital admits full responsibility for 24 failures that led to toddler's death
Why did this Korean content creator throw a divorce ceremony?
Bowen double helps Cardiff beat pointless Ospreys
Thousands demonstrate in Paris as protests spread across Europe
Are De Zerbi's Spurs finding elusive consistency?
Fireworks and fancy dress for Derry's 40th Halloween celebrations
Verbruggen spreads belief as Brighton continue to impress
Glasner fears he will be next Forest sacking if wins don't follow
More goals for Lankshear, home woes for Hammers - Aaron McLean's EFL Takeaways
Tottenham mood 'totally different' - De Zerbi
Sage looking for solutions to Palace form
Sunderland's paradox - San Siro trip amid relegation battle
Saints come from behind to beat in-form Gloucester
World number one-bound Zverev loses to De Minaur
'Always under pressure' - patience for Nuno wanes at West Ham
'We came back from hell', say Ukrainians after years in Russia-occupied front-line city
Maresca's big test is to address mounting Man City issues
Man Utd held to goalless draw at Everton
It's not time to make compromises - Glasner
Watch: Youth Olympics Opening Ceremony
Usyk eyes 'final chapter' at cruiserweight against Benavidez
Le Bris shrugs off questions on Sunderland future
Closing urgent care centres would have 'dire consequences', objectors say
Martinez's 'inexplicable' 83 seconds cost Man Utd and Carrick
Laura Kuenssberg: Healey risks breaking minimum wage promise for younger workers
Emotional reunions with loved ones for Oleshky evacuees
'It's been killing me!' Celebrity Traitors winners relieved the secret is out
Emma Thompson, Kate Winslet and Hugh Grant star in a 1995 adaptation
Everton striker's relief family not home during burglary
More than 5,000 die from Ebola in DR Congo's deadliest outbreak
'Greedy' solicitor used fake will-writing invoices to defraud cancer charity out of thousands
Ethiopian PM puts ministers through military training
Burnham 'open' to calls for slavery apology but not reparations
South Africa v Australia: David Warner tears into former side as hosts race to win
Europe can no longer rely on US to 'bankroll' its defence, Starmer says
Evacuees from Russia-occupied city where residents ate weeds arrive in Ukraine
Watch: Blood donors get a Halloween fright in Thailand
I'm 87 and I've finished 400 Parkruns
New Zealand into semis with statement win over Fiji
Motorcyclist dies after falling into sea in cliffside beauty spot crash
Scotland men slip up at European curling before semi-finals live on BBC
Briton Dart reaches first WTA Tour singles final
'We fell behind' - what does new San Siro deal mean for AC Milan and Inter?
TikTok brings fame and queues to Brontë village for autumn
Listen: Shearer on MOTD, managerial jobs & scoring record
Wales complete Japan double to end WXV on a high
CCTV and zip ties: How US mail-in votes are secured and counted
Why does the legend of Sawney Bean and Scotland's cannibal clan persist?
Man guilty of rape after woman's phone recording
How man's Halloween house display has become bittersweet tradition
'He would be pleased': Family reflects on man's 1971 'Santa' protest to pedestrianise Oxford Street
UK police cannot 'intervene' over woman killed by father in US, despite 'unlawful' ruling
The childhood promise that brought professional ballet to a post-industrial town
Toddler heads to US for cancer treatment as family given 'glimmer of hope'
'I was heading for a breakdown, then books saved my life'
How do you navigate Halloween with food allergies?
Shearer on trials of MOTD & the manager's job that never was
Call for lottery gambling controls after dad's death
Profile
Spain train disaster clouds Sánchez chances of re-election
The Papers: 'Rush to recover stolen $6bn' and 'War on wind farms'
Mahmood expected to announce changes to rules around indefinite leave to remain
Suited and booted: How Joseph Kabila went from president to rebel leader
Watch: Traitor or faithful? Celebrities reveal their allegiances
Why North Korea's 'elite' hackers are the prime suspect in major Binance hack
The Indian chef who brought curry to America - then vanished
Responsible or panicked? Meet the people around the world already preparing for crisis
Global nature talks reach deal but money remains an issue
'The necktie is dead': How US midterm candidates are dressing for votes
UK could see 10 days without rain after 'wettest week in two years'
When a wedding fell apart, 11 strangers helped create something unforgettable
After 28 years and 36,000 miles, Karl Bushby is almost home
Why MPs keep talking about an early election despite Burnham's denials
Watch: Match of the Day
The Fight For The Future Of The Green Party
Sherrock happy to overcome 'hate' in beating Littler for £501,000
He questioned Thailand's monarchy dressed as Harry Potter. Now he's in jail for 34 years
How has the ceasefire in Russian-occupied Oleshky been unfolding?
Celebrity Traitors comes to a climax in nail-biting final
King visits Guyanese slave rebellion site on Caribbean tour
US approves sale of 500 Patriot missiles to Ukraine
G20 'family photo' cancelled after protests over presence of Russian minister
Leicester dominate Bristol to go top of the Prem
Soaring cost of Halloween treats spooks shoppers
Can Robinson work Hampden magic against McInnes' Rangers?
Crypto giant Binance attempting to recover $6.3bn stolen in hack linked to North Korea
Police deployed during stand-off over control of top Poland court
US tech stocks see sharp falls as AI spending nears $1tn
Why you should eat kiwi and pineapple skins
Leclerc fastest in Mexico City Grand Prix first practice
Canelo makes weight against backdrop of Saudi turmoil
Zverev thrashes GB's Fery to reach Vienna semis
Ministers vow online safety action after teen sextortion victim took own life
City of London chief tops UK Black Powerlist
Binance's $6.3bn crypto hack biggest in history
Why has Caf abandoned plans to hold Afcon every four years?
Treasury accepts role in staff member's death
County Down man among three jailed for planning mosque attack
South Africa-Australia set for classic finale – what does history suggest could happen?
Canada stops using 'avalanche dogs' for rescues in Rocky Mountains, stirring outrage
'No nation left behind' says Burnham after meeting first ministers in Glasgow
First minister says Welsh spending powers takes step forward after Andy Burnham meeting
What Howe could bring to Man Utd - and what are the challenges?
From her own Barbie doll to bench - how Ellie Kildunne slipped from Red Roses' XV
Stabbed boy felt Huntingdon train attacker 'was not sane', court hears
Burnham's Number 10 North goes on multi-million pound hiring spree
Men jailed for 'abhorrent' operation trafficking women from Europe into UK for sex work
Russell Brand accusers 'haunted' for years by alleged crimes, court hears
How a passenger's confession helped convict her cousin of murder
Democratic senator blames Egypt press crackdown on US military aid decision
Pope Leo XIV becomes first pontiff to vote in a US election
I gave birth in ambulance on A96 amid staff shortages at local hospital
Police watchdog to investigate Met over letter about Meghan's father
Wettest week for two years but still not enough rain to get out of drought
Yorkshire Water boss resigns after firm downgraded
Alaska Senate candidate denies knowing about alleged plot to put two Dan Sullivans on ballot
Mayor defects from Greens after Zionism motion
Popular and talented - but Grealish is running out of chances
US inmate Christa Pike says she woke up 'confused and in pain' after failed execution
Winter fuel cuts turned the Welsh against Labour, former leader Neil Kinnock says
Spain transport minister says he won't resign over high-speed rail disaster
Injured Tuipulotu a doubt for England's autumn Tests
Driver guilty of hitting cyclist and dragging him to death under car
Sir Ian McKellen leads tributes to 'beloved actor' Sir Patrick Stewart after his death at 86
Academic says he has been barred from UK over event with Palestine Action founder
The acting legend defined by Yorkshire who 'loved it to the end'
What we know about Binance's $6.3bn hack
Residents leave devastated Russian-occupied Oleshky as evacuation corridor opens
China denies allegations of spy operation targeting Nvidia CEO
Forest Green launch legal action over Savage approach
Russia's international ice hockey ban overturned
Mayors will be free to use share of tax to give residents grants
Who could be behind the Binance hack and what we know so far
Police Scotland carrying out 'active inquiries' into Andrew and Epstein Balmoral visits
From Bitcoin to Binance: Crypto terms and what they mean
Footage of Seoul crush to be removed from Call of Duty after backlash
Streeting denies 'kicking can down the road' in defence spending row
Prominent Russian newspaper shuts down under pressure from authorities
Helicopter carrying six people crashes in northern Indian state
Crypto giant Binance hit by $6.3bn hack suspected to be largest in history
Heartbroken bride visited Dad in hospital on wedding day
How Kenyans got caught in $130m US ghost student scam
Human rights lawyer couple sentenced to 10 years' prison in Pakistan
How video game remakes tap the power of nostalgia
Why managers must put their own health first - Pulis
'I made the wrong decision,' Hyrox athlete who soiled herself in race tells BBC
F1 has never had anyone like me - Hamilton
Traders' tools stolen every 20 minutes in UK
Who should pay on the first date?
'My low Vitamin D levels hit me like a truck'
'My six-year-old cries herself to sleep': How fireworks affect people with autism
We went on holiday with our neighbours and swapped families - it tore us apart
Hazardous driving conditions for morning commuters as fog warning issued by Met Office
P&R urged to speed up review of relocation grants
Scottish police to target sadistic online gangs forcing children to self-harm
Attenborough-backed appeal secures £30m estate
How major policy shift is changing police response to mental health call-outs
'They don't bother me at all': The man who chooses to sleep with bedbugs for science
How talking about Man Utd's cycle of doom became an industry
How Poundland grew from a market stall to a high street giant
'I run a spotless kitchen', says Michelin-star restaurant chef in wake of food hygiene debacle
Syrians struggle with soaring prices as crisis challenges post-Assad recovery
Gruffalo illustrator considering legal action against AI firms
New York police will now investigate Cornell sex complaints, governor says
Three dead after two helicopters collide midair near Oregon airport
Democrats in the US have an identity crisis - it won't be an easy fix
Watch: Why Australia's mushroom murderer may now die in prison
Mushroom murderer fails to overturn convictions in Australian court challenge
Biggest fibre boost could be scraps in your bin, experts say
I didn't know I was lacking in vitamin D until I collapsed at work
Student-backed election winners demand sweeping resignations in Serbia
Bombshell confession in The Traitors as faithfuls finally turn the screw
Dramatic clifftop rescue of bride and groom-to-be
Indians turn to start-ups to care for ageing parents as young become more mobile
From Levi's to Primark - the fashion chains selling mended clothes
What makes this golden eagle chick so important?
From watching Star Trek to knighthood - Sir Patrick Stewart on the BBC
PSG score late to hold struggling Man City
Ireland's Furlong cleared of groin grab by disciplinary committee
Google value plunges by $500bn as AI fears rattle Wall Street
Heart attack patient, 83, had to drive four hours for hospital appointment
Watch: Life and career of iconic actor Sir Patrick Stewart
Chelsea linked with Alexander-Arnold - Friday's gossip
Young athlete and former minister among victims of Spain train crash
Venezuela opposition leader María Machado calls for elections upon return
What have we learned from first round of Premiership?
'Continue your journey': Key moments of leaked Spain train crash audio
King Charles arrives in Guyana as Bahamas visit declared 'diplomatic success'
Cundy's 20-year reign as world champion ends
Zverev seals world number one spot after win
Sir Patrick Stewart: Actor who moved effortlessly between Star Trek and Shakespeare
Israeli opposition accuses Netanyahu of trying to 'delegitimise' election
'The city is alive': A brief peace in Kherson, but residents fear what comes next
Jury shown CCTV of Huntingdon train staff using frying pan in defence
More than 43 million ballots cast so far in midterms early voting surge
Grealish dropped by Everton after 'breach of club discipline'
Paris suburb shooting suspect targeted people of Muslim or African appearance, prosecutor says
Watch: Bull on the loose at M6 service station
MI5 false evidence in neo-Nazi spy case a serious failing, says intelligence watchdog
MP apologises over bullying and harassment
Ex-Top Gear host Richard Hammond's 'brave' new Welsh life wild swimming and running
The South West reacts to Budget announcements
What are the government's options for reducing welfare spending?
Met refers itself to police watchdog over letter about Meghan's father
Weekly quiz: What was wrong with the Spotify listing of Dolly Parton's Jolene?
Lib Dems and Reform UK in war of words over alleged shove
US interest rates held steady and economy grows - what it means for you
New law changes make vape vending machines illegal
Hundreds of GP practices lose online services after collapse of tech firm
Watch: Hundreds queue for city's new Lego store
Careless dismissals give Australia route to series win in South Africa
'I felt isolated from normal life after suffering a stroke at 22'
'Albinism means you are never invisible'
Further delays for major council overhaul in nine of 14 proposed areas
Faisal Islam: This Budget was micro and that was deliberate
Burnham says he wants to cut welfare bill 'as soon as we possibly can'
Bereaved families will not face tax bill over pension delays under new rules
'I died twice', says man saved by off-duty police sergeant
DoorDash to buy Instacart in $17bn deal it says will expand customer options
Flávio Bolsonaro calls himself 'leader of Brazil' after election loss
Economist and former Burnham advisor scores Budget 4 out of 10
Watch: Passenger fights off knife attacker with frying pan
Poundland's future hangs in the balance as chain edges towards collapse
Russian drone attack on Ukrainian train station kills at least 14, officials say
Michelle O'Neill says DUP has blocked her from PM meeting in Glasgow
Spanish rail crash: Shock of tragedy gives way to sorrow and outrage in politically divided Spain
'The internet's a less whimsical place' - YouTuber Jacksepticeye branches out
Toney nightclub assault trial set for June 2028
Rock collapse kills two in Turkey's Cappadocia, local media reports
Island Energy: No plans to remove gas standing charge
Minimum wage rise 'a massive blow' says farmer
Minimum wage increase accepted by minister
Philippine police obtain warrant to search Thomas Markle's devices
Is the double drop from the Premier League becoming more common?
'Painful' years ahead, think tanks warn, as living standards set to fall
Chancellor's £30m pledge for new train station is an insult, Welsh minister says
Russell Brand's wife tells his rape trial he is 'kind and a wonderful father'
Record number of purges as Xi emphasises 'party discipline' at China political gathering
Why is there only one Premier League match on Sunday?
The Bottom Line
Carney to push for closer ties at Canada-EU summit in Montreal
Serious pollution by water industry remains high despite £5bn investment
Vulnerable at risk as 'life-saving' drug needle site closes
Bereaved families appalled by footage of Seoul crush in Call of Duty
I earn £30,000. I'm angry there was no fuel duty cut in the Budget
Alaska governor orders probe into Democratic campaign's alleged links to same-name candidate
US sanctions Rwanda's defence ministry over DR Congo conflict
Audio reveals exchanges between control centre and drivers before deadly Spain train crash
'Hungrier than ever' - Paul to return on 24 December
Watch the moment bridge hit at least 45 times is driven into again
Sometimes managers need sacking for own good - Neville
Voter voices: Which issues matter most to Americans?
Concern over cut to young people's mental health crisis scheme
Treasury will not commit to reducing welfare bill before next election
Ofcom sets out social media age-checking methods ahead of ban
'I live with a ghost': The people saving money by moving into Japan's haunted houses
Audacious Indian jailbreak saga ends with 17 prisoners recaptured
Ethiopia acquires Russian fighter jets and air defence systems amid war in Tigray
Mourinho and chaos - is Real Madrid boss misunderstood?
Hello Kitty maker cuts ties with Japanese spy drama after China backlash
Ed Davey: 'It's a £76bn stealth tax rise'
Watch: VHS tapes and computers handed to police as Thomas Markle is investigated
Chancellor says government has 'moral duty' to help young people out of work
Mum goes to Iceland as pilot of daughter's flight
New rules for vaping and nicotine products... do you know them?
El Salvador sends 2,000 troops to Haiti to rescue four missing soldiers
Tower block residents plagued by intruders in scaffolding 'nightmare'
NHS Western Isles prescribing weight loss drugs at triple the rate of other health boards
'Like cutting up a Picasso': AI microdrama edit of Neighbours worries actors and crew
US Health Secretary RFK Jr to expand access to unapproved peptides
Microsoft profits soar days after announcing thousands of layoffs
Europe's youth is on the march - but does anything actually unite them?
Take our Celebrity Traitors quiz to find out which star you would be in this year's show
Mum says autistic son, 18, left abandoned and falling through cracks in system
Weight-loss jabs boom putting recycling centre workers at risk
Row over George Michael items up for auction - including Faith guitar
Building boom puts 300,000 people in the path of potential Himalayan disasters
Details of thousands of US immigration agents leaked in major hack
AI used to remove visible differences from photographs criticised
Newport mum of critically ill baby denied food at Grange Hospital
'My legs buckled when I opened my exam results during Covid'
Community group completes 'first' hostile buy-out of eyesore plot of land in St Andrews
Rare manx shearwaters returned to Isle of Canna in bird conservation bid
Carabao Cup draw: Fleetwood Town to face Everton or Newcastle in quarter-final
Russo scores hat-trick as Arsenal beat Benfica
Flávio Bolsonaro denies fleeing Brazil after landing in Miami
Girl seriously injured in wolf attack at German wildlife park
King Charles shows off dance moves on second day of Caribbean tour
High-speed train crash kills at least 68 people in Spain
Kompany discharged from hospital following collapse
Sancho rejects Getafe - Thursday's gossip
Bloodied, dazed and angry - how passengers' rail journey turned to disaster in Spain
What does John Healey's budget mean for Scotland?
Death of US actress Hayden Panettiere ruled accidental, ending local police probe
Chiefs coach defends decision to sign kicker Tucker
Israel's election deadlock is a sign of the country's deep divisions
Watch: King dances in the streets of the Bahamas capital
Restaurants sceptical over 'garlic and gherkins' plan
Netanyahu's bloc leading Israel election but short of majority, partial results show
What we now know about the UK economy in four charts
What the Budget offers for under 25s - and what it leaves out
Dharshini David: Healey buys himself some time, but big questions still unanswered
Elon Musk is a 'real genius', Putin says after satellite talks with SpaceX boss
Healey tells departments to make 1% cuts to fund defence
Watch: How did Flávio Bolsonaro end up in Miami?
Healey unveils £100 for energy bills and bank tax in first Budget
Burnham rules out early general election in next 12 months
Three ways the Budget affects you
Babydoll singer says life will 'never be the same again' after UK number one
The Budget explained in less than one minute
Tax thresholds remain unchanged - here's what it means for your pay
Netanyahu shares AI image of Arab voters during Israeli election
Will I get the £100 energy payment and when will I receive it?
Myanmar diplomat breaks down as he urges world to 'end our suffering'
Labuschagne's form hits record low but Australia hint at future
Budget 2026: Key points at a glance
Chris Mason: Budget felt cautious despite its range of small measures
Watch: At the scene of Spain's deadly train crash
Watch: What are the key points from the Budget and how will they be funded?
Tommy Robinson guilty of harassing two Daily Mail journalists
Train attacker asked man 'do you want to die?', trial hears
What are the standout points from the Budget?
How much is the minimum wage going up by?
How could Israel break election deadlock? Here are four scenarios
Israel's election result is messy - here's why
Badenoch: Budget 'does not come close to meeting the moment'
Your pay, energy bills and cash Isa: How the Budget affects you
Wife ran after husband Philip Young ‘brought someone into bedroom’, court told
Burnham insists 'no confusion at all' over his Brexit position
Legal bid to overturn Drumcree march ban fails
McClean leaves Derry City after contract dispute
All Spanish cup matches suspended after Madrid train collision
'Dissident republicans may be responsible' for hotel explosive device, police say
Russell Brand tells court allegations had devastating impact on him
MacAnthony's 'promise' to sell if Peterborough not in top 10
Chancellor takes to the despatch box for his first Budget
Briton Azim set for December return against Valenzuela
John Healey pays homage to predecessor Rachel Reeves
Multiple sclerosis patient living in 'horrific pain' due to UK-wide drugs shortage
How will the tax cut on gherkins help restaurants?
More cats abandoned 'due to rising costs'
What we know about the crash so far
'Relax, I love Kane and Lamine Yamal' - Henry defends his Ballon d'Or hosting
Terminally ill mum who can't talk, walk or dress herself refused Pip payment
Arsenal to appeal against Dowman red card
Carrick and Fernandes hold clear-the-air talks
Chancellor holds red box outside No 11
Overturned carriages and makeshift medical tents at crash site
Serrano to end career in Puerto Rico in January
Four investigations Democrats could launch if they win control of Congress
You may get the right to find out what your colleagues earn - here's why
Netanyahu and Eisenkot face difficult paths to power as neither set to win majority
Luxury cruise passengers stranded in Cambodia due to soaring fuel costs
What do you want from the Budget?
Tanzania celebrates first natural gas discovery in more than 10 years
Serbian shot dead after attacking officer outside Israeli embassy, minister says
Plaid demands more cash, but how could the Budget affect Wales?
Celebrity Traitors' Joe Lycett's tribute to viral TikTok nan
Former Conservative chancellor unsure Budget will 'fix big problems'
'Government to decide who to help and who picks up the tab'
Liverpool gambled on Jacquet and it is paying off
Anger in Kenya over extradition hearing delay for ex-British soldier accused of murdering woman
Goodbye to Wawrinka - an everyman who gatecrashed the greats
Women's alcohol deaths are increasing - my daughter died after fighting for decades
Gas is cut over unpaid bills despite payments made
Watch: What happens now after close vote in Israeli election?
A bust-up between mathematicians is fuelling fears that AI could undermine science
'Biggest night in club's history' as fearless Fleetwood stun Arsenal in EFL Cup
'An annoying buzz': The search for stealthier drones
Where does Fleetwood beating Arsenal rank in biggest cup upsets?
China's families are now supporting more old people than kids
King acknowledges 'suffering of the past' as Caribbean tour begins
Chris Mason: Budget needs to go some way towards delivering PM's promises
Ceasefire extended across Ukraine's Kherson region, officials say
Ex-wife of Zimbabwe's vice-president freed after collapse of attempted murder case
Is all processed food bad for you?
Dutch zookeeper dies after being mauled by leopard
What do we know about Chancellor John Healey?
Man Utd stick with Carrick: Inside a turbulent 48 hours at Old Trafford
Landline switchover could cut people off in emergency, minister warned
Adventurer completes 400-mile expedition after losing contact with team
Norway and Finland leaders hold rare call with Putin
Healey to promise £15m to tackle misogyny in Budget
Lancashire treatment of Anderson disrespectful - Broad
Men abused woman after her husband drugged and advertised her online, court told
Police criticised for delay in 999 mountain call response after two young climbers die
Watch: The Mbappé-Chairman Mao controversy explained
Australia fight back to keep Cummins out of unwanted club... for now
Flávio Bolsonaro's passports cancelled after he fails to surrender them
Unnamed celebrity accused of 'inappropriate sexual activities', court hears
Tiny zebra-striped bee sighting a 'huge surprise'
Russell Brand told police he never had non-consensual sex
Egyptian journalist Lina Attalah detained after court orders news site's closure
Funeral assault dad arrested after court no-show
Council rejects rollercoaster overlooking homes
Woman's Hour
Minimum wage set to rise but 18-20 year-olds will not get bigger increase
Political rivals, and their wives, vote in Israeli election
Parents who killed their baby have sentences increased
More than third of deaths of ex-prisoners on probation drug related, says report
Boy, 14, denies murdering teenage girl whose body was found in park
England in Pakistan: Harry Brook's side out after Sri Lanka beat hosts
UK and EU officials to discuss freedom of movement
Two charged over alleged plot to assist Iran in RAF Fairford incident
Ex-Britain First leader arrested in HMO attacks investigation
Carrick to stay in charge of Man Utd for Chelsea game
Mbappé sorry for 'ill-judged' Mao remark after backlash in China
Truce begins in Ukraine city where residents ate weeds to survive
Lawrie, 15, eyes £501,000 live TV win over Littler
Ex-FBI chief James Comey faces federal charges for third time
Turnout so far highest in decades as Israelis vote in pivotal election
More high winds hit parts of UK as Storm Boelo clean-up continues
What does Israel's election mean for Gaza and the wider world?
MPs and MSP detained by Israel and barred from entering West Bank
Apple to replace iPhone Duos affected by screen problem
Why it could take time for a new Israeli government to form
'A dream come true' - Harry Kane on his Ballon d'Or win
Rise in sales of radios and tinned foods, say retailers, after call to stock up
'I love to escape into a fantasyland of fairies': Fans rejoice as latest Sarah J Maas book hits shelves
First-time buyers hoping for help from the Budget
Boy who stabbed girl at school was radicalised online, says father
Jordan carries out deadly strike in Syria in retaliation for church attack
'What does it say if a woman can't give birth in her own city?'
Chris Mason: The Budget is imminent as tricky things pile up for Burnham
Keir Starmer's government discussed moving out of 10 Downing Street
Busted's James Bourne says 'hero' brother saved his life with kidney donation
Surprising things we have learnt from Anthropic's blockbuster share listing
Pope's South American trip to go ahead as planned after lung cancer surgery
Political battle intensifies within Labour over Rosebank oil field
Army officer killed by reversing Warrior with faulty alarm - inquest
Israel and the US are both going to the polls - the consequences will be global
Independent review announced into murder of student Henry Nowak
Howe and Nagelsmann high on Man Utd's list if Carrick sacked
Exercise helps woman recover from partying life
Anthropic warns of AI's 'risks to humanity' ahead of blockbuster share listing
Lula wins fourth term in dramatic Brazil election comeback
Burnham leaves door open to referendum on EU free movement
What is walking down the newly pedestrianised Oxford Street like?
Consultant doctors in England to strike next month
Who is Lula? From ex-worker and prisoner to Brazil's president again
Funding set to double for plan to get rough sleepers off streets by Christmas
Jordan arrests three men suspected of deadly church attack after shootout
On frontline at hospital denying online claims it is 'dangerous' and 'dreadful'
Can you tell ferritin levels from your face?
Healey to shield low-income pensioners from income tax in the Budget
Late Mbappe goal earns Real win at Barca in dramatic Clasico
Crowds welcome Venezuela's María Machado after months in exile
How a movement of students brought down Serbia's Vučić
Fireworks heard as BBC reports Lula's victory in São Paulo
Flávio Bolsonaro calls for elections to be annulled
Watch: How Lula turned it around to beat former president's son
Election victory was 'defeat of lies', says Lula
Is 'ferritin face' a real thing - and can you really spot low iron from looks?
India's cartoonists built an audience online - now their posts are being restricted
Faisal Islam: Healey's Budget needs to sustain the stronger economy through gathering clouds
A late goal and a knee slide - how Mourinho returned to haunt Barca
Big, noisy and coming to a town near you - why the data centre backlash is growing
Deeply divided Israel braces for pivotal election
Israelis prepare to vote in one of the most pivotal elections in the country's history
Serbia's Vučić concedes election defeat to student-led protest movement
Manchester United & Michael Carrick: Air of inevitability around manager's future but owners' problems far bigger
Pressure intensifies on Carrick as Man Utd lose to Bournemouth
Liverpool earn first league win at Anfield with victory over Brighton
Sage continues to struggle as Palace lose at home to Newcastle
Sunderland stay bottom after goalless draw with Leeds
Birmingham get first win of the season after edging past Charlton
Late own goal gives Liverpool point against London City Lionesses
Vangsgaard scores twice as Villa hang on to beat Everton
Illuminated
Letter making claims about Meghan's father written by his first wife, BBC understands
Pressure grows on Sage as fans turn on Palace boss
Isak finally living up to price tag as Liverpool patience rewarded
Board of Deputies of British Jews declares Greens to be racist party
Carrick future under major threat - can he survive?
England lose to Pakistan after improbable last-wicket stand
Venezuelan opposition leader María Machado returns after months in exile
Early reports suggest record high turnout in Serbia elections
Fernandes left out - Man Utd hammered, Bournemouth brilliant - how they rated
Suspect in deadly Paris suburb shooting sent for psychiatric observation
The Climate Question
Newscast
Burnham open to 'honest discussion' on EU free movement
Anderson stops short of retiring after Lancashire exit
Voters in Brazil head to polls as Lula goes up against Bolsonaro's son
Storm Boelo floods town centre of Largs, Scotland
El Salvador president says bodies found in Haiti are not those of hostages
More than 1,300 arrested as clashes follow another day of mass protests across France
More wet and windy weather to follow stormy weekend
Budget to include £1bn for social and affordable housing
Musk says SpaceX restricted Ukraine's Starlink connection as service restored
Meghan broke contact with father in letter citing abuse claims
'This is the only Clasico' - Mourinho's Real trying to stop Barca's shot at history
Author's camping trip inspired Hollywood film Wicker
Rosebank: Life on the oil field at the centre of a political storm
Wellbeing support demand for cancer patients grows
I lost my job in a primary school due to endometriosis
Four ways Labour could raise money in the Budget without hiking income tax
Why is Ukraine so reliant on Starlink and can Europe plug the gap?
Students like new tenancy freedoms - but landlords warn of higher rents
Antonelli stands on brink of history in Austin
What Are The Risks In Andy Burnham's EU Strategy?
The US Midterms Unpacked In 39 Minutes
The Draft UK-EU Deal To Scrap Brexit Red Tape
Are There More Russell Brands In The Media Industry?
The Most Expensive Affair In History?
Are Under-25s About to Lose Sickness Benefits?
Welfare Plans and EU Deals
Could The Russell Brand Case Change The Age Of Consent?
The Name's Milburn...Alan Milburn
Can Milburn's Neets Report Help Britain's 'Lost Generation'?
Russell Brand Guilty Of Rape
The David Walliams Allegations
The Californian whose pumpkin patch dream took root in Scotland
Who are the candidates in Brazil's presidential election?
Watch: BBC in Paris as police charge protesters and use tear gas during unrest
Spurs clinch rare Stamford Bridge win as Palmer sent off
Arsenal beat Everton to go level on points with leaders Man City
Penders error & Palmer sees red - player ratings for Chelsea v Spurs
'A massive storage of images': Arteta has technical area receipts
Why winning ugly is just as important for Wales
Watch: Fire engulfs Hitler's mountaintop Eagle's Nest retreat
Arsenal relieve pressure with Spurs win - can they kick on now?
Man City's leaky defence highlights Donnarumma & Guehi struggles
'It's harsh' - was Arsenal's winning penalty a controversial decision?
Arsenal fight back to beat Tottenham and ease pressure on Slegers
Highlights: Japan 0-17 Wales
Met Police says letter with claims about Meghan's father not shared with other law enforcement
Ukraine says Starlink connection 'now stable' after network limits
Wales grind out frustrating WXV win against Japan
Ferguson's first game as Glentoran boss postponed
Between quick wins and big dreams lies Burnham's biggest test
Arrest made after fire at Hitler's mountaintop Eagle's Nest retreat
Bayern Munich coach Vincent Kompany's recovery will take 'weeks' after collapse
Woman, 65, becomes second patient to die of Ebola in Kenya
Three released without charge after fatal arson attack in Ireland
Babydoll singer Jamie Miller reaches number one
What a spectre - Bond boys bounce around London
Parents call for tougher measures in schools to tackle allergies
How Brazil's changing working class is reshaping the presidential race
Met investigates reports of letter detailing claims about Meghan's father
Tory activist in 'contract killing broker' claim had worked for party HQ
Australian MP's condition improves after alleged car attack
How does the UK state pension compare with other countries?
UK to invest £100m in 'world first' AI Biosecurity Lab
The Secrets Of Creating A Budget
Strictly's new presenters - after mixed reviews have they found their feet?
Are California voters about to impose 'world's first' tax on billionaires?
Ruins of Limoges city hall a symbol of France divided by national protests
Student movement takes Serbia's Vučić to the wire in neck-and-neck election
Britain's posh schools are heading to India for students and profits
Celebrity Traitors left on a knife edge after a trip to the field of screams
Who actually controls Ukraine's access to Starlink?
GP says she was forced out of job after raising concerns about gender treatment
Prince William on how he once dreamed of becoming 'DJ Xara'
Green councillors face Labour deadline to disown Zionism policy
Meghan statement offers answers after years of questions about her relationship with father
Ex-Tory campaign chief and his wife receive suspended sentences over election bets
Police yet to receive £2m after A66 crash, says commissioner
Premiership preview: Form strikers in focus and will Rangers respond?
US justice department investigating Corey Lewandowski over DHS role
I thought I was dying but it was health anxiety - here's how to recognise the signs
PM defends Gogglebox appearance after Badenoch criticism
Why should I stockpile and what will I need?
'It's been relentless': IT workers scramble to fix PHP flaw described as worst crisis in years
Earnings limit of up to £140K for first-time buyers loan scheme
At least one dead and four injured in Paris suburb shooting
Meghan says she was informed about 'disturbing allegations' against her father in 2018
Burnham suggests stocking up on tinned food and bottled water
Emery's Villa 2.0 reboot restores optimism before Man City meeting
Family's plea after autistic son escapes school
Woman with Ebola in Nigeria confirmed as wife of Swiss diplomat
Final James Bond screen tests to take place this weekend, reports say
'No more Mr Nice Guy' - should Carrick drop Fernandes?
Call of Duty hit a low point last year - can Modern Warfare 4 win fans back?
The Indian workers filming their work to train AI
First personalised cancer vaccine cuts risk of disease returning in major trial
Infantino re-election hopes boosted by Asia support after u-turn
Have Manchester United become the unmanageable club?
Pupils pen special song to give classmates a voice
Don't leave AI to tech bros and oligarchs, UK's AI minister says
Chancellor says he will cut 'pointless paperwork' to save businesses up to £800m
Raye wins the Mercury Prize with This Music May Contain Hope
Rapid changes to care market risk to National Care Service, regulator says
Give more people weight-loss jabs on the NHS, say MPs
L'Oreal says weight loss drugs are impacting beauty and skincare sales
Items recovered in search for missing fishing boat and crew
Man Utd chief keen on Howe - Friday's gossip
Zuckerberg wins Meta deal to help him foot bill for possible California billionaire tax
Bruno Fernandes has home burgled while in Italy with Man Utd
Race to update services' computer systems after cyber-security flaw found
Sherrock one of 24 'amateurs' taking on Littler
Fernandes to remain Man Utd captain despite outburst
What are Real's attacking options during Vinicius Jr ban?
French weekend protests to be limited to union demos only, says Macron
Civil servant who juggled five jobs 'wasn't thinking straight', court hears
Tommy Robinson hired detectives to find journalists, court told
Why a student protest movement is challenging 12 years of Vučić rule in Serbia
Michael Carrick carrying on but senior Man Utd figures concerned by poor performances
Ilhan Omar says 'bizarre' pre-dawn raid on her home is forcing her to move out
The Briefing Room
AI discovered a massive cyber-security flaw - here's what happened
What is PHP and why did it spark an international cyber-security alert?
First human case of Shamonda virus detected in France, officials say
Russell Brand accuser said alleged rape 'really hurt', court hears
'Not what a captain should be' - the debate around Fernandes' outburst
Claims 'stabbed' woman tried to drive to hospital because of ambulance wait time denied
Two storms in two days as Austen and Boelo head for UK
Legendary video game studio BioWare closes after 31 years
El Salvador's president threatens Haitian gangs over military hostages
Zoe Kleinman: PHP is the cyber equivalent of an unexploded bomb
'500 new vulnerabilities' found in government, says AI minister
How do Israel's elections work and who are the main contenders?
Two killed in attack on airport in eastern Saudi Arabia, authorities say
UK working to identify exposure after global cyber-security warning
How Arab parties could hold critical balance of power in Israeli election
Like 'weeing lava': living with chronic UTIs
The 'trillion pound' oil fund the government believes Britain could have built
The grads ditching the UK for a fresh start abroad
Chronic UTIs affect millions in the UK - these women are out to end the stigma
Only one female scientist named in GCSEs, research finds
Diabetes and ADHD drugs to be tested on Alzheimer's patients in new study
Airbnb hosts can no longer make guests strip beds and wash dishes under new rules
Why is a peat fire so bad? BBC is in Indonesia to find out
Ruthless Roma put four past toothless Slovan Bratislava
Guirassy double helps Dortmund past Sabah
Rice strikes to earn Arsenal draw at Bayern
McTominay scores twice as Napoli beat Bodo/Glimt
PSG come out on top in six-goal thriller against Barcelona
Foden nets hat-trick as Man City beat AEK Athens
Mac Allister scores twice as Liverpool fight back to beat Villarreal
'What a goal, what a moment' - Rice snatches late equaliser against Bayern
Man Utd humbled by four-goal Como to pile pressure on Carrick
Paz, Fabregas and Como teach Man Utd a lesson
Chelsea eye Brighton's Ayari - Thursday's gossip
Pope does not need further treatment after lung cancer surgery
Fernandes rounds on Carrick after Man Utd humiliation
Rosenberg: US diplomatic push offers little hope for imminent Ukraine peace
Nigeria's first Ebola patient holidayed in Uganda, officials say
India 'cockroach' leaders who called on election chief to quit are freed from jail
Tributes paid to 'bravest' woman who died of 'stab wounds' after crash
'Playing for their careers' - Australia reeling after extraordinary day
Russia says it is ready to resume talks with Ukraine and US to end war
Websites taken down worldwide as critical cyber-security update issued
Civil servant admits he 'made mistakes' juggling five government jobs
Burnham defends Jackdaw decision as Badenoch urges PM to overturn ban on new oil and gas licences
Anderson, 44, not offered new Lancashire contract
Holocaust school lessons to be improved after 'shocking' antisemitism review
Jailed former DUP leader Jeffrey Donaldson being investigated over alleged rape inside Parliament
Macron accuses foreign leaders of exploiting French riots
How Jackdaw ignites row over climate and costs
Nigeria confirms Ebola case linked to East Africa
Woman told Russell Brand he 'treated her like an animal', court hears
Teenage boy guilty of trying to murder girl, 15, in school
Women welcome annual health checks for condition affecting millions
Christina Applegate says she was wrongly diagnosed with MS
Is Ebola under control in Kenya after nine cases confirmed?
'Lessons need to be learnt' as report into care homes during Covid published
Chris Mason: Jackdaw approved but tricky energy trade-offs remain
Australian MP loses both legs after alleged car attack, husband says
What is happening with the Jackdaw and Rosebank gas and oil fields?
Missing German WW2 U-boat found 82 years on
BBC inside Australian court as man charged with attacking MP stays silent in first hearing
Borneo burning: Life on the frontline of South East Asia's toxic haze
The Interview
The tech helping crack decades-old cold cases
Tighter rules planned to protect people from cosmetic surgery that goes badly wrong
Universities face 'substantial' funding cuts amid budget delay
Second Labour MP suspended over Covid loan repayments
Arsenal criticism from very small minority - Arteta
Man Utd revisit deal for Hall - Wednesday gossip
Cornell Jane Doe says embattled university head doubted her gang-rape allegation
UK government to make Jackdaw gas field announcement
Two re-arrested on suspicion of assisting Iran intelligence after RAF Fairford incident
Who is Chancellor John Healey? Labour veteran who quit as defence secretary
Sloppy England start winter with Pakistan defeat
Government failings allowed Covid 'to spread like wildfire' in care homes, inquiry finds
Christina Applegate says she was wrongfully diagnosed with MS
What do pupils think of GCSE Maths changes?
Burnham risks wrath of Commons Speaker for talking too much at PMQs
No 'protective ring' and visiting rules too strict - key points from Covid report on care homes
Marseille braces for more unrest after protests give way to 'apocalyptic' disorder
We asked teens what schools should teach them about work. This is what they said
Zelensky prepares for Oslo talks with US envoys as Rubio denies withholding intelligence
Man charged with attack on Australian MP as suspect's father says she is family friend
Woman describes alleged assault by Russell Brand as 'frenzied' and 'violent'
Armed police swoop as man, 61, arrested for murder and woman in car crash dies
Storm Austen to bring severe gales to UK as weather warning issued
Why Israeli Gen Z voters are drawn to the far right
How the attack on an Australian MP unfolded
Changes to GCSE Maths 'pulling the rug out from under pupils'
Five ways El Niño is affecting the weather around the world
Lampard 'proud' of Coventry performance in defeat by Spurs
Spurs beat Coventry to earn first league win of the season
Palace manager Sage facing fight to keep his job
Trial hears Robinson 'intimidated' Daily Mail reporters
Warning signs over threats to Australian politicians were rising before MP hit by car
Houthi missile strike on Yemen camp kills 50 security recruits, local authorities say
Obama blasts federal probe of congresswoman Ilhan Omar as 'so appalling'
Threatening hoax bomb email sent to hundreds of NI schools
In pictures: French landmarks damaged and destroyed by violent protesters
Are free-scoring Brighton genuine Premier League contenders?
Watch: Are the French riots a warning of an intense election to come?
Police investigating hoax threat emails sent to Scottish schools
Haaland a doubt, Semenyo out - what are Man City's options?
Woman says she 'closed eyes and tried not to be there' during alleged Russell Brand rape
Bereaved families could face 'unjust' tax bill after civil service pension delays
PM says youth unemployment is a 'catastrophe and a moral failure'
What we know about apparent attack on Australian MP hit by car
Man accused of mass train stabbing admits wounding
Kenya pastor accused of ordering parents to starve their children to death faces verdict
Severe weather warning issued ahead of potential UK storm later this week
Deadly fire at Canada military base moved a kilometre 'in 30 to 60 seconds'
Plan to deal with Troubles legacy to be debated in House of Commons
Bomb threat forces Israel to Austria flight into emergency landing
China's growth accelerates as AI boom helps boost exports
'It gives me the ick': Can you cheat on someone with a video game?
Don't fall for this - how to protect yourself from AI scams
Macron calls for 'calm and order' after riots across France
Ramos could make La Liga return - Monday's gossip
Madueke's 'anger and conviction' shows he's more than a 'finisher'
Sage feels 'shame' at Palace thrashing with future in doubt
What we know so far about deadly fire at Canadian military base
Impressive London City extend winning run against Everton
Bournemouth pick up first league victory with win over Sunderland
Leeds extend Man Utd's winless run to six games
Madueke's strike enough as Arsenal pick up narrow win over Forest
Gomez scores extraordinary goal as Brighton put five past Palace
Man and woman in their late teens die in collision
'Maybe we became arrogant' - Sunderland struggles continue
Shades of Barca and Beckham - Brighton aim to maintain superb start
Northampton beat Cardiff for only English win of Champions Cup openers
Hearts roll out red carpet ... and Celtic walk all over it
Mbeumo offers Carrick solace as Man Utd winless run goes on
Man Utd showed 'unity' in draw with Leeds - Carrick
Everything a struggle for Fernandes - Leeds v Man Utd ratings
Rumpelstiltskin fools Shrek into being erased from existence
What awaits Everton hero Ferguson in shock Glens role?
Man arrested after boy, 16, dies in crash
Polanski says he will not overturn Green Party's 'Zionism is racism' motion
Pope Leo XIV thanks wellwishers in first event after cancer surgery
Watch: Parisians wake up to protest damage and looted shops
Burnt out cars and shattered glass on Paris streets after protests turn to riots and looting
Several dead or injured in major fire at Canada military base
Reform politician says smart glasses help him make speeches in Wales' parliament
Heating oil customers face tough winter
The town swapping lie-ins for early morning raves
How day of protests unfolded as disorder breaks out across France
Emery praises Manzambi's 'skills and intelligence'
Manzambi heads Villa to victory at Newcastle
Haaland nets double as Man City go six points clear at the top
Everton did not play well - Moyes
Data centre developers may build 'climate-wrecking' gas power plant next door
Pope's health should not be taken 'for granted', says top Vatican diplomat
Why hasn't the UK had any named storms yet?
Miranda's tears, joy and dance moves steal show as deadly boredom sets in on The Celebrity Traitors
The Papers: 'Mystery drones over UK' and 'Troops heading to Poland for war games'
Why people who have never smoked are getting hooked on vapes
Chris Mason: Burnham and Swinney tussle over where power lies in Scotland
Police feared Andrew would delay search by saying King owned his home, documents show
Rahm sacrifices £75m to secure exit from LIV Golf
Collaboration with Off Campus star 'gave me chills', says Babydoll singer Jamie Miller
Our business ads were taken down for saying 'pregnancy' on Instagram
Do Manchester City have any grounds to win their appeal?
Inside Ukrainian offensive pushing Russia back on front line where Starlink plays a key role
Watch: Will Ukraine get the support needed as tensions with US rise?
Arteta told Arsenal job cuts will help create success
Covid vaccine compensation scheme set for overhaul after Inquiry criticism
Pope pictured for first time since surgery as he says Mass at makeshift altar in hospital
US senators call for investigation into Ukraine's Starlink restrictions
'I am telling you the truth' - Carrick on Martinez fallout
Minister warns people to save water amid drought
Sex was 'huge preoccupation for Russell Brand', ex-flatmate tells trial
'Massive challenge' to protect paedophile ex-MP Donaldson from harm in jail
GB's Stewart wins gold in thrilling points race
British father fined for causing his two-year-old son's death in Cyprus hotel fall
Temperatures to drop for weekend as stormy weather could return next week
Fuel costs squeezing margins for some businesses
Charity 'terrified' closure could leave mums suicidal
Are student protests being manipulated ahead of France's presidential election?
Living with a stink? Technology might help
I find it quite demoralising in store - why I do all my shopping online
Bus hits train stopped on French side of Channel Tunnel, with 19 injured
Kane poised to extend Bayern stay - Friday's gossip
Weekly quiz: Which star is lending his voice to Gromit?
Watch: What does Starlink have to do with the Ukraine-Russia war?
Houthi missile attack on Yemeni presidential palace kills two, minister says
Banks say Healey is planning Budget tax raid on their profits
What we know about the criminal investigation into US congresswoman Ilhan Omar
Equality watchdog writes to Greens over 'Zionism is racism' motion
Russell Brand accuser says he turned 'monster-like' before alleged rape
Former DUP leader Donaldson sentenced to 15 years in prison for child sex abuse
Severe drought declared and hosepipe bans in force - is your area affected?
Labour to break from Green council groups that back Zionism policy
Another man admits raping woman drugged by husband over 20 years
Nandy 'minded to intervene' in Sky's £1.6bn takeover of ITV entertainment arm
Infantino apologises to Fifa Council - but told he is still not fit to lead
Arrests made after couple and two children killed in arson attack in Waterford
GTA 6 - all you need to know about Rockstar's blockbuster game
GB win two golds at Track World Championships
AI giant Anthropic woos potential investors ahead of stock market debut
Severe drought declared in parts of southern England
Hospital doctors to strike as pay dispute continues
Man Utd a circus after Martinez comments - Keane
Brazil's Congress approves shorter working week in win for Lula
Who is getting weight loss jags on the NHS in Scotland?
Healey says surprise UK growth is 'sign of resilience' ahead of Budget
'Some think endometriosis is just a bad period, but it's so much worse'
Fewer than 800 Scots have received jabs for weight loss on NHS, BBC finds
Tiny critically endangered puddle frogs hatch at London Zoo
UK temperatures to rise to 23C before autumn chill sets in
'Nowhere to escape' - Indonesians share footage of orange haze blanketing towns
As Christmas rush looms, how do China-made toys find their way to the US?
Real Madrid stun Roma after dramatic late comeback
Yoro sent off as Man Utd stumble to defeat against Atletico Madrid
Musk says any limits on Ukraine's Starlink access down to US, not his firm
Why Zelensky's meeting with Burnham matters
Martinez's future at Man Utd in doubt - Thursday's gossip
Why is Starlink internet so important on the battlefield in Ukraine?
Netflix to lay off 1,000 staff in steepest cuts since 2022
Burnham rules out coalition with Greens after 'Zionism is racism' motion
Kenya confirms second Ebola case as relative of country's first victim
Russell Brand was a 'sexual predator', prosecution alleges as rape trial begins
'It's rough out here': Americans struggle with rising inflation
Toilet paper and secret recorders: What we know about the arrest of the Saudi OpenAI engineer
US inflation rises more than expected - here's what is happening with prices
Pope walking and recovering 'as expected' after surgery, doctors say
What we know about the Pope's lung cancer diagnosis
Pope's cancer diagnosis leaves Catholics questioning what comes next
Civil servant 'wore makeup to fake illness and juggle five jobs from home'
Starlink restrictions affecting Ukraine's front line operations, Kyiv says
Watch: Block of flats in ruins after Russian strikes on Ukraine
'I applied for 200 jobs' - How 'spray and pray' AI job applications can backfire
Lib Dems rally behind Davey as he pledges change
Zimbabwean author denies using AI to write award-winning story
How long will humans be needed for translation?
Missiles intercepted near Riyadh after Saudi coalition hits Yemen fuel depot
Russian strikes hit key power plant in Kyiv, Zelensky says
Who's to blame for the toxic smog choking South East Asia?
Zelensky and Burnham to meet in Downing Street
Pope diagnosed with lung cancer but had successful surgery, Vatican says
Cornell bans all fraternity parties over gang sex assault allegations
'If we don't scream, they won't listen to us': Student protesters speak to BBC in Paris
Argentina targets UK in legal claim over Falklands oil exploration
NI company in talks to save Poundland from administration
Ex-president named leader of new DR Congo rebel coalition
Rusty or something more? South Africa's concern after Australia loss
'Criticised for what?' - Maresca defends Anfield celebrations
MI5 chief warns of threats to UK from Russia, Iran and AI
Hundreds more prisoners being freed in second phase of early release scheme
Welsh government and Labour strike budget deal with £60m for additional learning needs
Car finance compensation payments delayed until next year
Poundland in rescue talks as owners seek buyer
Watch: Emergency calls from botched Christa Pike execution released
Super El Niño sets another record as it strengthens to 'unprecedented levels'
Cut screen time in classrooms to avoid long-term health issues, clinicians urge
How much did Man City's rule breaking cost your team?
Where the US midterm elections will be won and lost
Russia's offensive ability is broken, Kyiv's former top general tells BBC
BBC's Orla Guerin travels with Yemen's southern national security forces through desert battlefield
Why the prime minister wants to talk about Brexit again
Heating oil customers face tough winter despite shake-up promise
Coventry announce themselves back in the big time
Lampard keeping 'feet on ground' following big win over Newcastle
Coventry thrash Newcastle to claim first home win of season
Attorney General approval required for serious Troubles prosecutions
Burnham to push for new post-Brexit deals at EU summit
Why some have no choice but to pay costly oil prices
AI minister warns 'likely' UK's cyber defences will be breached
Which war is having the biggest impact on diesel prices - Iran or Ukraine?
Zverev secures year-end number one ranking
French supermarket fridges heated to 50C in 'unprecedented' cyber attack
Saudi minister vows 'serious response' to Houthi attacks on airports
Russell Brand appears in court for start of rape trial
Why is it so hard to fight the Houthis?
Key suggests Carse can return as England reveal contract list
New mental health directory launches
Watch: CCTV shows people take cover as missile hits Riyadh airport
Campaigners claim minister attempting to undermine 'Holiday Hunger Bill'
AI is less regulated than milk, says Microsoft president
Halloween 'bigger than Christmas', say businesses
Rejecting closer EU ties would be dereliction of duty, PM to say
Watch: Endangered orangutans released back into the wild after Borneo fires
Saudi capital airport hit by second Houthi strike in two days
Man City's statement win has feeling of irrelevance with season in limbo
Winless and an 'easy touch' - what's happened to the Anfield fear factor?
Orangutans released back into Borneo forest after devastating fires
Watch: Bundesliga highlights
'We deal with the noise' - Maresca 'proud' after Man City win
Burnham to release details of Man City meetings
Firefighters spend second night at scene of Glasgow scrapyard blaze
Emergency doctor 'completely terrified' of looming winter pressures on NHS
Pope Leo to have surgery after lump found on lung
Homes and bridges swept away as fresh floods hit Nepal
Riyadh airport attack another dangerous moment in already tense conflict
It's within DUP's gift to remove O'Neill as first minister, says Lockhart
Russo named England player of the year
Buildings swept away as flash floods hit central Nepal
Toxicity and uncertainty await Man City as they prepare to take on Liverpool
Several injured in attack on airport in Saudi capital Riyadh
Northern Lights stun UK down to England's south coast
Boos, anguish & fading belief -'worrying day' for under-pressure Carrick
US murderer Christa Pike discharged from hospital 10 days after failed execution
Drumcree parade ban was in interests of peace, says Bryant
Green Party MP wants to make sure it is 'not vulnerable to extremists'
France's school protests are about more than broken classrooms
NI secretary to ban the Drumcree parade
Arteta's conscience clear over Man City charges
US immigration officials defend ICE agents who shot man in same car as child
Ethiopia warns Eritrea it will defend itself after troops cross border
Yes, hang-xiety is a real thing
I've got my own questions on Man City case - Carrick
What reception awaits Man City at Anfield?
Ofsted faces fresh calls to halt graded school inspections in England
Report highlights flaws in ADHD and autism care
Drought declared in Yorkshire after dry weather
King pays Andrew's £1.5m repair bill on Royal Lodge
ICE agent shoots man in New York City
Autism, ADHD and mental health review: What you need to know
France promises 3,000 extra teachers in first step to calm student protests
Man City titles 'absolutely not' tainted - Maresca
Three Saudi nationals killed in Houthi attacks on Riyadh airport
Watch: Fleeing Kyiv for the countryside ahead of winter
Why is it so hard to put out Indonesian fires shrouding the region in toxic smog?
Russian strikes and approaching winter force some in Kyiv to pack bags and flee
Christa Pike has 'profound' health turnaround after botched execution, lawyers say
Why are more roofs not made of solar tiles?
Will El Niño and the polar vortex bring snow to the UK this winter?
ADHD and autism at risk of over-diagnosis, says government review
Burnham calls on Polanski to reverse Green Party's Zionism motion
Maresca says 'feeling is fantastic' among Man City squad
Infantino given re-election boost as Montagliani seeks final Concacaf term
Weekly quiz: How long did it take for Glastonbury tickets to sell out?
Protesters blame 'vulture funds' for Spain's housing crisis
Two Latvian men arrested on suspicion of trespass at RAF base in Cambridgeshire
Why the search warrants were deemed unlawful and what happens next?
Warrants used to search Andrew Mountbatten-Windsor's homes were unlawful, court says
How student loans work for tuition fees and living costs
Russian strike on buses kills at least 30, say officials, as deadly attacks on Ukraine surge
UK and Germany will face threats together, says Burnham in Berlin
Gazans face near-daily Israeli strikes a year into ceasefire
Seventh man bailed in connection with RAF Fairford incident
Clubs fear political interference in Man City appeal
Could Christa Pike face execution again and by what method?
Christa Pike now walking after failed US execution, lawyer tells BBC
New vape tax made me swap e-cigs for dartboards
'Every day there is killing': Palestinians in Gaza face Israeli strikes despite ceasefire as peace deal stalls
France's school protests: What lies behind the anger
Three people killed in Houthi attacks on Saudi Arabia airports, officials say
Texas carries out first US execution since Christa Pike's botched lethal injections
Cornell rape case accuser has received ‘threats’, attorney tells BBC Newshour
How oil-rich Alberta's economy might fare if it broke away from Canada
How toxic haze is causing Singapore’s landmarks to disappear
Christa Pike 'angry and confused' after failed execution, lawyers say
Man Utd and Liverpool eye Truffert - Thursday's gossip
Rahm to leave LIV Golf over 'unacceptable' terms
Two icons, a glorious farewell and a potentially bitter ending
Guardiola set to attend Man City's first home game since guilty verdict
Watch: What we know about Christa Pike's ‘shock’ recovery in hospital
Masked 15-year-old stabbed schoolgirl, court told
Eritrean troops move deep into Ethiopia's Tigray region, residents tell BBC
Eleven arrested as pro-Palestinian marches held in London
Watch: Stop firing stun grenades at student protests, French police told
Zelensky condemns 'vile' large-scale Russian attacks that killed 20
Ten people linked to Kenya's first-ever Ebola case quarantined as screening concerns grow
France halts use of stun grenades after boy's hand blown off in student protests
Neglect case childminder was 'master manipulator', say parents
Could Manchester City be expelled from the Premier League?
Senior figures worried about Man City being in next season's Champions League
Tuchel's England 2.0: What has changed?
Arteta signs new contract with champions Arsenal
Man admits sexually assaulting woman drugged by husband
Ex-Welsh Green Party deputy says Zionism motion 'pointless' after quitting party
Rainmakers: The drones used to seed clouds
What we know about Christa Pike’s ‘unprecedented' recovery after failed execution
UK set for coldest night of autumn so far
UK risks being 'uninvestable' if new oil and gas fields not approved, warns oil giant
Many Nepalis swept away in the floods aren't officially dead, leaving families in limbo
US death row inmate Christa Pike awake and speaking after failed execution, lawyers say
Watch: Riot police clash with school protesters and use tear gas in France
Cornell rape allegations expose 'loopholes' in laws around drinking and consent
Tear gas in Paris and Marseille as school protests grow across France
Why Tories are talking about winning the next election
Paramount takes over Warner Bros in $110bn Hollywood merger
British national arrested in connection with RAF Fairford incident
Kenya confirms its first Ebola death as outbreak spreads
Films and streaming prices - how the Warner Bros deal could affect you
Dad saw son, 2, fall to death from Cyprus hotel window, court hears
Childminder who left 27 children alone in her home pleads guilty to neglect
Watch: At the scene of student protests on the streets of Lille
Fear and disruption for Ukraine's rail passengers as Russia escalates drone attacks
Ofcom investigates Meta over Instagram Instants feature
LIV Golf secures potential $300m investment
Temperatures set to fall as rain and cloud sweep across UK
A simple guide to the US midterms
I won't accept exclusion, says Polanski after criticism of Zionism motion
What prompted the US bombers to leave RAF Fairford?
France braces for national day of school protests after injuries and mass arrests
Spain PM pins hopes on housing crisis to help win snap election
Gabriel in Man Utd team photo but no hint of reconciliation
King's funding for Andrew not to be used for legal action against police
Tensions exposed among Greens by 'Zionism is racism' conference vote
Did eviction of an 87-year-old trigger snap election in Spain?
What is the Green Party's 'Zionism is racism' motion?
What we know about Andrew Mountbatten-Windsor's legal action against police
Potty training scheme to roll out to 20 more areas
Death of girl, 11, 'unexplained' after body found in park
Police probe deliberate fire at Glasgow city centre pub
Quins disaster, salty celebrations and Test bolters - Prem talking points
Jewish Greens chair says she could leave party over 'Zionism is racism' motion
Andrew takes legal action over search warrants before his arrest
Spanish PM Sánchez calls early election after housing protests
Watch: How the eviction of an elderly resident in Madrid led to a snap election
£800m in, £800m out - Why Man City scandal shines light on Man Utd finances
Watch: How Brazil's dramatic election unfolded
Polls close in Brazil as Lula and Flávio Bolsonaro remain neck and neck
Green Party members back 'Zionism is racism' motion
France to close up to 500 schools on Monday over student protests
'We fought for every ball' - Hemp on Man City's thrilling win
Yemen's government announces all-out war to reclaim land from Houthis
Christa Pike's prognosis still unclear after failed execution, lawyer says
Watch: What we know about Russian strikes on Kyiv bridges
Ethiopian rebel forces withdraw from Tigray regional capital
Badenoch unveils plan to end £100,000 childcare 'cliff edge' ahead of Tory conference
What to know about Brazil's election pitting Lula against Flávio Bolsonaro
University asks staff to review some partnerships with China after MI5 warning
The Celebrity Traitors connections that might surprise you
Cornell president says university 'must do better' after frat house rape allegations
Man Utd & Arsenal eye Croatia striker - Sunday's gossip
Gloucester thrash sorry Quins to go top of the Prem
Ronaldo still 'greatest symbol' of Portugal - Fernandes
Tennessee prison chief to resign after Christa Pike's failed execution, governor says
Back-to-back wins for Man Utd as they see off Liverpool
Why has Brazil accused the US of election interference?
Russia hits second major bridge in Ukraine's capital Kyiv
UK-Iranian dual national arrested over RAF Fairford released on bail
Why beating Denmark matters to Wales' Euro 2028 hopes
Woman deceived ex-partner that she had given birth to his babies, judge rules
Cornell frat house rape accuser 'under siege' online, says lawyer
Is RAF Fairford Safe?
A Make Or Break Week For Zack Polanski?
Are The Public Ready To Vote Tory Again?
Will The Tories Make A Pact With Reform?
Which clubs did Man City's 'inflated' money flow to in transfer market?
Men charged over alleged plot to target Manchester Jewish community
Bath gain revenge on Exeter to win 11-try thriller
Met Police urge students to move 7 October protest
Riot police clash with students as education protests rage in France
King's Caribbean tour will not shy away from 'darkest days of our past'
McHaffie the hero as Edinburgh sink Stormers
Cardiff seal bonus-point victory against Zebre
US murderer Christa Pike unconscious and on ventilator after failed execution, lawyers say
How widely used is the death penalty in the US?
Woman at centre of Cornell rape inquiry was 'failed' by officials, says New York governor
Watch: Why has UK diesel price hit an all time high?
Sabalenka 'trying hard to be easier on myself'
Spanish PM Sánchez loses key housing crisis vote after eviction of woman, 87
Three reasons Middle East oil supply is nearly back to pre-Iran war levels
Intensified Russian strikes are tearing Kyiv apart, warns mayor
Watch: Why students in France are protesting
Belfast boxing legend Close dies aged 57
I've seen nearly 500 executions - but never one like Christa Pike's
School protests send shivers down French government's spine
Diesel prices in NI at highest level since Iran war began
Sky-high fuel prices push costs up on customers and charities
UK diesel price hits £2 a litre as US calls for Europe to release more stocks
Ethiopia and Eritrea cut diplomatic ties as northern conflict escalates
'Dark cloud' hangs over Cornell campus as anger at frat rape investigation grows
What does Man City guilty verdict mean for their squad?
Man City lodge appeal after being found guilty of breaching financial rules
How to see the Orionid meteor shower this weekend
Cornell students voice frustration at public hearing over rape case
Christa Pike in critical condition after surviving two lethal injections, lawyer says
Why Andy Burnham's about-turn on Manchester City matters
Highlights: Wales 2-1 Norway
Chaos, coffins and 'Claudiapatra' steal the show in Celebrity Traitors
What we know about Christa Pike’s condition after failed execution
UK-Iranian dual national arrested over RAF Fairford incident, police say
Fires break out at French schools as students protest over funding
Weekly quiz: How did two champions fight over marathon dates for next year's London races?
Man City not 'above the rules', says No 10 after backlash to Burnham remarks
'I took Fairford pic - then all hell broke loose'
'We must keep going' says charity hit by fuel prices
Is it time to ditch premium bonds?
Hundreds of criminals start leaving prison under new early release scheme
Prison conditions are 'awful', says released man
What happened in failed execution of Christa Pike - and what next?
Watch: Why are students protesting at schools in France?
Cornell case highlights 'draining' maze for victims to report campus sex assaults
Nine scandals that rocked the sporting world
Why are hundreds of prisoners being released early?
Pension tops £16,000 a year after 4.7% increase
US death row inmate survives execution attempt after two lethal injections
Ivan Toney denies Soho nightclub assault
Celebrity Traitors is back - here's what you need to know ahead of the first show
'I'm very shocked' - College students react to Cornell University rape investigation
The AI telling farmers when to harvest
Vape tax comes into effect - but prices won't rise yet
Trekkers helicoptered off mountains as more deadly landslides hit Nepal
Employers should teach primary-age children about work, says Milburn
Punish Man City this season, say other club chiefs
China funding UK research and sending it to Beijing's spies, MI5 warns
PM: I'd be 'really concerned' if Man City owners sell club
We fear for our lives after being told our abusive exes will be freed from jail early
Timeline of RAF Fairford incident and the investigation so far
Burnham 'really concerned' if Man City owners sell up after rule breaches
Execution of US murderer Christa Pike halted shortly before it was due to happen
Ethiopia fighting escalates in Tigray killing 52 civilians, medic tells the BBC
Criminal investigation? Relegation or expulsion? The key Man City questions
WhatsApp introduces optional parental controls for teenagers
Russia launches largest attack on Ukraine energy infrastructure since spring
Watch: Detail about new call to police changes RAF Fairford timeline
Move to rejoin EU among options for UK, says Burnham
Africa's richest man launches Kenya oil refinery despite land protests
Pie shop owner gets reply from Andy Burnham
Regulating AI 'not the right place to start' says Bank of England governor
Richards 'devastated' by Man City guilty verdicts
What we know about Cornell University frat house rape investigation
Tories would keep the triple lock as it is, says party chairman
The transfers that helped Man City dominate while breaking financial rules
Watch: Moment a government building collapses into a river in Nepal amid floods
Antisemitism on the rise at universities, charity warns
US Supreme Court denies Christa Pike's last-ditch bid to halt execution
More than 400 detained as France student protests escalate
France school students blockade hundreds of schools in protests
'Quantity of petrol' but no explosives found in three vehicles near RAF Fairford
Burnham to fight next election on pledge to change voting system
The intricate web Man City spun to con the Premier League
Could changing the pension triple lock pay for Burnham's big social care plan?
How did the RAF Fairford incident go from 'suspected bomb plot' to police bail?
Chris Mason: Burnham delivers deeply political speech with a personal core
Man City guilty of 'sham' contracts and misleading accounts
Burnham vows to end existing pension triple lock in 2030 to help fund care
Faisal Islam: Triple lock move is significant, but it's a gamble
What did Andy Burnham promise at Labour conference?
Five takeaways from Andy Burnham's Labour conference speech
Watch: How did Burnham's speech go down in the conference hall?
Burnham pays emotional tribute to his dad
Burnham announces plan for Great British Grid
Burnham to unveil public body to invest in electricity grid
Man Utd do not deserve Man City titles - Rooney
Andy Burnham: Northern PM's long journey to power
Should Andy Burnham call an early general election?
Apprentice star tells PM why pie shop is closing
Tennessee governor declines to halt execution of state's lone woman on death row
Infantino makes bigger cash pledge to Fifa members
French PM warns against escalation of school protests after 164 arrested
Man Utd & Arsenal eye Porto's Costa - Tuesday's gossip
Watch: RAF Fairford suspects are bailed, what happens now?
Five men arrested in RAF Fairford incident released on police bail
Man City CEO defiant over Premier League charges
US prosecutors reopen case of alleged gang rape at Cornell University
People escape historic Kyiv building hit by Russian drone
Here's how record UK diesel prices could get worse
Andy Burnham wants to fix social care - what are the options?
Is Burnham's leadership just about 'good vibes'?
Watch: Were the RAF Fairford arrests 'pure luck'?
UK diesel price hits all-time high, the RAC says
Childminder facing 'severe financial burden' as heating oil costs rise
My hometown shows that high streets have to change or die
Five arrested as counter-terror police investigate major incident near RAF Fairford
More than 50 arrested at Palestine Action support rally
Man Utd bag their first win of the season against West Ham
What we know about RAF base counter-terror investigation
Watch: At the scene of counter-terrorism operation near RAF Fairford
Police get more time to quiz suspects in alleged plot against Jewish community
Why Premier League faces uncertainty and chaos after Man City ruling
Injured Isak returns to Liverpool from Sweden duty
Man City? I feel cheated - when do Stoke City get our FA Cup?
Killer Christa Pike is to be executed within days but her defence say she's a victim too
Gloucester shock Exeter for superb victory
Man City maintain winning start with narrow win over Charlton
No Premier League appetite to strip Man City of titles - but threat remains
How long can Labour's feel-good factor last?
Manchester City charges: Legal fight could spiral out of control, says former executive
Legal challenge to Drumcree parade decision under way
The issues Mourinho is struggling to fix at Real
Weekend of mixed UK weather with sunshine before showers arrive for some on Sunday
Scottish drivers hit as diesel passes £2 a litre across the country
UK ticket holder wins 'life-changing' £111m EuroMillions jackpot
The computer hacker who tried to take down Man City
Iran offers US deal to reopen Strait of Hormuz in seven days
How fresh fighting in Tigray could spark wider conflict in Ethiopia
Russia targeting 'ordinary life' with attacks on Ukraine's data centres, Zelensky says
Man City fans face up to reality of guilty verdict
Clubs seek legal advice over Man City charges compensation
Man City found guilty of majority of 115 financial rule breaches
Man City guilty of majority of 115 charges - 5 Live reaction
Man City and the 115 charges - key questions answered
Who is hacker whose revelations led to Man City charges?
Jeffrey Donaldson victim describes 'profound impact' of child sex abuse
Watch: What could the potential sanctions for Man City be?
What to expect from Burnham's first Labour conference as PM
Drumcree parade decision expected to be announced
Girl, 16, killed in crash near north London school
Weekly quiz: How quickly did this six-year-old girl solve a Rubik's Cube?
Are we back in big tech's 'move fast and break things' era?
Rising fuel costs hitting businesses and customers
In Amish country, nurses go door to door to stop deadly spread of measles
Teenagers to be offered new vocational GCSE subjects in school
Ethiopia and Tigray accuse each of launching offensives, fuelling fears of new war
Ronaldo spurred on by 1,000 goals and Portugal glory
UK to step up fight against Russian disinformation and push global AI standards, PM says
Open wounds and eyes that can't close - women warn about cheap bleph eyelid surgery
Europe's car makers are in crisis. Will the threat of war rescue them?
Ukraine anger as EU removes Russian oligarchs from sanctions list
Plot targeting Manchester's Jewish community disrupted, say police
Developing El Niño becomes strongest on record weeks before expected peak
Arteta agrees new deal with champions Arsenal
Man admits causing the death of his son in hotel fall
'Nightmare' for taxi drivers as fuel prices soar
Iran must stop arming Houthis in Yemen, G7 says ahead of UN General Assembly
Rising fuel prices 'cost tow truck business £10k'
Watch: Ukraine's race to counter new jet-powered Russian drones
Soaring fuel costs hit small businesses
Schools not ready for AI and 'crying out' for government guidance, report warns
Paramount settles lawsuit with US states, clearing way for $110bn merger with Warner Bros
Atletico hit back at Mourinho over referee complaints
Was Neville right to call out Man Utd for a 'lack of effort'?
Will you get £13,000 a year when you stop working? Here's how to check
Nvidia boss rejects AI extinction fears as 'doomsday narratives'
Which emergency foods should you stock up on?
Human extinction fears make me want to flee AI and live on an island
Mourinho prints out 'red card' incidents after Real lose derby
Neville calls Man Utd 'pathetic' - but Carrick maintains belief
Liverpool boss Iraola makes winning return to Bournemouth
Carrick impressed Man Utd 'kept belief' to earn draw at Fulham
Who rated highest in Fulham v Man Utd?
Impressive defence seals solid start at Liverpool for Iraola
Largest attack on Moscow sees Ukraine fire hundreds of drones, mayor says
'People forget we exist': Why older LGBTQ+ people fear losing identity
Not all AI workers think the tech could kill everyone
Moyes demands more from Everton - but don't mention Europe
Coventry need to 'keep feet on the ground' after 'landmark' win - Lampard
Coventry win first points of season in dramatic win over Forest
Smoke seen near Riyadh airport after air raid alerts in Saudi capital
Saudi Arabia issues first air raid alerts for Riyadh since Houthis escalated attacks
A four-minute warning isn't enough: Russia's new relentless missile tactics exhaust Kyiv residents
Gabriel, 15, in Barcelona amid speculation over future
Will England boss Tuchel 'embrace the chaos'?
'Not a catastrophe' - Carrick dismisses Man Utd job fears
Sunshine to return to parts of UK with warmer and drier weather on way
'This is our company': Nigerians show off oil wealth after share-buying frenzy
Weekly quiz: Why did women's sports stars criticise actress Sydney Sweeney?
King Charles warns of 'existential danger' of AI falling into wrong hands
Verified video shows wreckage of Saudi fighter jet shot down over Yemen
Real Madrid keen on Man Utd forward Gabriel, 15
At least seven months of relentless rain needed to end drought, research shows
Why an escalating Saudi oil crisis could drive up prices everywhere
What next for Gabriel and Man Utd?
Microsoft says AI rival Anthropic could have 'disastrous impact' on humanity
What's happening to UK interest rates and what does it mean for mortgages?
Husband who drugged and raped wife for 20 years no longer part of trial
Petrol and diesel price rises push UK inflation higher
OpenAI boss says world 'right to be afraid' but should trust AI firms
Journalist and pilot among three killed after news helicopter crashes in LA
What is happening to UK prices?
Saudi Arabia says it shot down Houthi drone south of Mecca
A backlash over data centres is another threat to the AI juggernaut
PGA Tour not planning return program for LIV stars
Youth star JJ Gabriel, 15, on brink of leaving Man Utd
State pension likely to top £13,000 a year as UK wage growth slows to 3.9%
Will El Niño bring winter snow to the UK?
We must heed warnings of AI tech developers, says UK minister
What is the triple lock and how much is the state pension worth?
AI regulation faces political deadlock as calls grow for Congress to act
‘Great’ or ‘alarming’ - Should AI be reined in?
Man admits drugging and raping wife over 20 years
Africa's richest man launches continent's biggest share sale
What is AI, how does it work and why are some people concerned about it?
Could AI pose a threat to humanity, and can it be regulated?
Why are there concerns AI could threaten humanity, and how real are they?
China criticises idea it is in 'malicious competition' over AI
Familiar questions for Man Utd, now Carrick must find answers
MPs and Lords call for new law to address AI threat to human rights
Watch: Why a Russian strike on train near Ukraine-Poland border could mark an escalation
Joint-worst start since 1992 and fan protests - Man Utd's day to forget
Twenty-five years in the waiting - Coventry's nightmare top-flight return
AI staff 'genuinely frightened' for humanity's future, ex-Anthropic researcher tells BBC
Oil prices create 'huge worry' as winter looms
Anthropic boss Dario Amodei calls for AI development to slow down
Dramatic insider warnings over AI fall flat with some in Silicon Valley
Burnham and Badenoch revive red versus blue politics as Reform land 'gobsmacking' donations
Saudi Arabia shuts key oil pipeline after drone attack launched from Iraq
Running costs of vaccine damage scheme more than double amount paid to victims
US prices remain high as fuel costs squeeze household budgets
Anthropic blocks possible attempt to use AI to make biological weapons
Henry Zeffman: How Burnham got ready to govern with four key moments mapped out
Weekly quiz: Alan Carr collected a prize for which TV show at the NTAs?
Four killed and 60 injured in Russian strike on shopping centre, Ukraine says
Oil, gas and borrowing costs surge as fears over Middle East escalate
Arsenal close to finalising new contract for Arteta
Two arrested in London on suspicion of assisting Iran's intelligence service
Buy now or wait and hope? Families face gamble on heating oil
Russia's new jet-powered drones outpacing Ukraine's air defences with daily launches
UK needs new laws for AI in healthcare, says watchdog
Why some experts increasingly fear AI will take over
What next for LIV Golf's star players, and its fight for survival?
Russia and Ukraine exchange strikes as two killed at Moldova border
Is 15-year-old Gabriel set to become Man Utd's youngest ever player?
Petrol prices rise by 5p over a week as Iran war sends oil higher
Anthropic researcher believes more than 10% chance AI 'could kill all humans'
LIV Golf players free to leave after bankruptcy protection filing
Saudi Arabia vows to respond after Houthis attack cities and energy facilities
Argentina to file criminal case against oil company operating in Falklands
At least two people dead after Russian strikes on Kyiv
Drought and hosepipe bans remain despite wettest week since early February
Nepal cracks down on online abuse of flood survivors
Scammers demand ransoms from Instagram users over fake copyright claims
Israeli strikes in southern Lebanese village kill nine
Chancellor says UK economy 'turning a corner' despite debt concerns
Kyiv air raid alerts at record high as Russia launches round-the-clock strikes
Turning cooler with wet and windy weather forecast for UK this week
The volunteers risking their lives to defuse Indonesia's wildfire 'carbon bombs'
Peace talks rich in symbolism but fundamental differences between Russia and Ukraine remain
Arsenal reacted in an amazing way - Arteta
Shaw double leads Man City to victory over Birmingham
Man Utd cannot ignore more dropped points despite positives
How New Is Andy Burnham’s Labour?
US envoys arrive in Ukraine for talks after meeting Putin in Russia
Aviation faces hotter, stormier skies – and passengers might have to accept more disruption
US envoys arrive in Moscow ahead of Ukraine talks
Isak finally arrives as Gakpo proves value to Liverpool
Nepal bet nearly everything on hydropower - the floods show why that's a problem
Russia hits Ukrainian security headquarters in drone attack, Zelensky says
Birmingham relishing Man City challenge on WSL return
'A rare moment of joy': Nepal tunnel rescues bring hope for more flood survivors
UK petrol prices hit highest level since Iran war began
Nepal rescuers try to reach dozens trapped in tunnel after two found alive
UK support for Falkland Islands 'unwavering', No 10 says
US diesel prices hit an all-time-high
'Layer upon layer of miracles': How Nepal flood survivors were rescued from tunnel
Argentine leader threatens to sanction oil firms and reiterates Falklands claim
Watch: Moment workers are rescued from Nepal tunnel
ICE agent charged with lying about shooting Venezuelan man during crackdown
Fifa accuses Uefa of 'smear campaign' against Infantino
Weekly quiz: What has been named TikTok's song of the summer in the UK?
UN warns of 'supersized' El Niño as countries prepare for impact
Why Nepal floods should worry India
Burnham pressed on economy at first PMQs as UK borrowing costs rise
'Friendly fire' at Andy Burnham's first PMQs
About 700 prisoners to be freed on 1 October under revised early release plans
Thousands still missing as Nepal-Tibet flood relief and recovery intensifies
Zelensky says airlines should avoid Russian airspace as Ukraine escalates drone operations
Burnham promises more devolution and public control of essential services
More than 110 rescued a week after Nepal deadly floods, army says
Watch: Key moments from Andy Burnham's first Commons speech as PM
Flood chased me as I ran for 20 minutes, Nepal tunnel worker tells BBC
Israeli fire kills three in Gaza City during reported raid, medics say
Russian attack hits rail workers in new deadly strikes on Kyiv
Victims 'desperate' for details on early prison release scheme, commissioner says
Concerns over early release from prison and probation organisations
The final minutes before floodwater crashed through Nepal-China border
Orangutans in danger as wildfires blaze through Borneo
Nepal rescuers blast hillside in search of hydropower workers as families wait anxiously
Families welcome changes to early release scheme
The Papers: 'Killers blocked from early release' and 'Harry should fund security'
Nepal flood relief vehicles trapped as heavy rain turns roads to mud
Carrick 'really pleased' as Fernandes hat-trick sparks Man Utd comeback
Fernandes hat-trick inspires five-goal Man Utd comeback against Ipswich
Prisoners freed early are returning to jail at rapid rate, governors tell BBC
PC Harper's killers to stay in jail as PM announces changes to early release scheme
Iraola awaits first win as Liverpool rescue late draw against Forest
Deadly strike on Kyiv warehouse prompts evacuations
At least 37 dead and hundreds evacuated after strike on Kyiv warehouse
UK weather: Strong winds and more thunderstorms to kick off the bank holiday weekend
Satellite images reveal scale of flood devastation in Nepal villages
Videos show people survive floodwaters on balcony in Nepal
Watch: Why rescuers fear new barrier lake could cause another Nepal-Tibet flood
I used to live in a quiet area - now a data centre overlooks my garden
Time is running out for cyber security, warn top tech firms
Xbox boss 'thinking about affordability' of next-gen console

SOURCE: ITV
Burnham to say EU deal ‘taking pressure off cost of food’ in supermarket visit | ITV News

SOURCE: PBS
Experts say failed climate talks could worsen inequality, but progress not stalled
Why the global response to climate change is falling short
Court approves $7.25 billion Bayer settlement over claims Roundup weed killer caused cancer
Activists, leaders criticize COP31 climate talks as fossil fuels go unmentioned in draft deal
SpaceX's Starship returns from orbit and is captured by launch pad arms in a dramatic first
The U.S. flu season is off to a very early start. It's hitting the South and West now
Sen. Chris Murphy's stroke at 53 highlights a trend: Strokes among younger adults have risen
Seeds and preserved hair in tomb point to oldest signs of cannabis high 2,800 years ago, study suggests
A NASA space telescope plunged back to Earth after a mission that lasted 11 times longer than planned
Judge denies federal request to segregate California ballots, says it would 'wreak havoc' on voting
WATCH: How does The Associated Press call 2026 midterm election winners? 4 things to know
Republicans seize on controversy in Alaska's closely watched Senate race
Serbia's strongman leader Vucic concedes defeat to student-led movement in seismic political shift
Pope Leo's tests show he needs no further treatment for lung cancer, his doctors say
Pope Leo returns to the Vatican 4 days after lung cancer surgery
Iran-backed Houthis strike Saudi oil company Aramco's headquarters, officials say
What the Cornell case reveals about how sexual assault allegations are handled
News Wrap: Lawyer says Christa Pike 'angry and confused' following botched execution
Inside the study for a remedy to fight Congo's deadliest Ebola outbreak
WATCH: Senate candidate El-Sayed and former VP Harris speak at Black maternal health roundtable
SOURCE: NPR
FCC says SpaceX can deploy 1 million satellites for data centers in space. Scientists are skeptical
Sydney Sweeney has great jeans. Who made them? (Psst: Workers)
US has lost measles elimination status, global health authorities say
Do you know signs of a stroke? BE FAST are the words to remember
What's gone up even faster than gas or rent? The cost of caregiving
U.S. measles cases more than double what they were last year as outbreak spreads
Is your Medicare Advantage plan ending next year? Here's what to know
Pope Leo XIV leaves hospital days after lung cancer surgery
Hit a midlife wall? This test identifies your strengths and what matters to you
Zelenskyy sits down with NPR. And, Pope Leo diagnosed with lung cancer
As diseases loom, CDC's response to measles deaths stirs fears about agency's reliability
SOURCE: CBC
COVID-19 school disruptions still impacting students today, learning loss report finds
Ahead of Grey Cup game, Elks explain why coach’s change in facial hair symbolizes commitment to team
Christina Applegate asks if breast implants are behind symptoms after MS misdiagnosis
N.W.T. gov’t accepts all recommendations in review of deaths of 3 Dehcho residents
DNA profile created for grizzly behind deadly attack in B.C.
Unmanaged menopause symptoms cost Canada's economy $3.5B, experts tell MPs
NASA telescope predicted to plunge back to Earth after failed rescue mission
Canadian astronaut takes questions from International Space Station
Pope Leo will undergo surgery to remove a nodule on his lung
Gas prices are dropping. You can thank the 'winter blend' for that

SOURCE: ABC News
Why Harry Styles isn't coming to your city on his Australian tour
Where $24k can buy you a new home
Quiz: Come with us on a journey around the world
Mums describe how Chinese AI app lured daughters into abusive chats
Weight-loss drug boom could leave Aussies facing falls and fractures
Hobart stadium cost political debate still rages, despite its future being assured
Josh Duggan - ABC News
Meet the scientists working to save the corpse flower from extinction
Breaking: Analysts surprised as unemployment rate surges to 4.9pc in October
Adelaide-based body double recalls upstaging new Bond in outback pub
Observers concerned over alleged gaps in WA emissions monitoring
Breaking: Aboriginal woman's death in custody preventable, coroner finds
Renters on 'moderate incomes' falling victim to homelessness in Darwin
Tree protestors ordered to pay $150k for failed bid to halt golf course
Queensland community groups urge premier to act amid funding crisis
Compensation could encourage more Australian surrogates, supporters say
Man in custody after suspicious death of Whitsunday woman
Four Aussies chasing biggest payday in history of women's golf
Cambridge Dictionary names 'human' word of the year in rebuttal to AI
Routine dental check-up spots tongue cancer and saves woman's life
Tasmanian brand Coal River Farm enters voluntary administration
I'm celebrating my ostomy bag, even if it grosses others out
Jury hung in trial exploring dark chapter of Sydney's criminal history
Police charge 14-year-old boy over crash of allegedly stolen car
Woolworths customers report hundreds of dollars stolen from digital gift cards
Stranded turtle's 16-hour road trip to recovery
Looking for a summer job? Here’s what to consider
Litany of missed opportunities in Floreat murder tragedy
Clive Palmer says dilapidated luxury resort will reopen after decade in mothballs
Women's pelvic health surgeon among SA's Australian of the Year winners
NASA Swift telescope plummets to Earth near Indonesia
NASA's Swift telescope predicted to plummet back to Earth tomorrow
Interstate investors sparking 'astronomical' house sales in Alice Springs
Permit seeks higher antibiotic dosage for diseased Tasmania salmon
Calls for transparency as pressure builds on regional SA health system
Putin agrees to resume three-way peace talks with Ukraine and US
Pope Leo leaves hospital for Vatican four days after lung cancer surgery
'When fear takes over': Responding to the DRC's largest Ebola outbreak
SOURCE: RNZ
Will share prices now stop falling?
Lack of long-term economic direction an impediment to growth - survey
Saying goodbye to Maketū Pies
Wheels up: Air NZ to launch flights between Hamilton and Queenstown in 2027
Manufacturing sector slows slightly as fuel prices spike
The Pacific's water security challenge during a searing El Niño
How well do we actually know what’s going on in the economy?
Shares in cancer diagnostics company Pacific Edge rise after Medicare coverage of tests
Why NZ faces worst 'labour scarring' risk since 1990s
South Island businesses report Eftpos outages
Why can’t I use my KiwiSaver to pay for a hip operation? Ask Susan
Deadline for cleaning up Kerikeri's controversial Bing property expires

SOURCE: DW
US judge approves Bayer's $7.25 billion cancer settlement
Measles in America: Here's a constructive approach to beating the highly contagious disease, based on Brazil's experience
Nvidia beats Q3 expectations in first report post-Jensen Huang
Polish activists face opposition as they make abortion more accessible
SpaceX carries out first-ever spaceship capture
Paraguay Senate dismisses President Santiago Pena over bank crisis
EU court says CBD foods need approval for sale before they can be certified organic
Africa's shifting role in the global drug trade
EU says Montenegro on track to become bloc's next member state by 2028
UK's King Charles III decries the 'monstrous injustice' of the transatlantic slave trade
Brazil elections: Voting extended after transport complaints
France: 1 killed, 4 wounded after shooting near Paris
Pope appears in public for first time since surgery
How prepared is Kenya for an Ebola outbreak?
Brazil election: Early count puts Bolsonaro ahead of Lula
SOURCE: France24
Europe will take part in US-mediated Ukraine talks in Abu Dhabi, French FM says
'Is Republican Party able to pivot away from MAGA movement, or will it sputter forward leaderless?'
Iran offers deal on Hormuz Strait, Netanyahu wants to 'finish the job'
US Midterms: Democrats face leftward surge
How will the women's vote shape the US midterms?
EU natural gas prices top €100 for first time since 2022
Tens of thousands of Israelis living abroad expected to fly in for pivotal vote
French authorities ban some student protests after weekend looting and clashes
PSG end Barcelona's winning run as Liverpool fight back against Villarreal
KENYA CONFIRMS THIRD EBOLA CASE
Kenya reports second Ebola case, family member of first patient
Ebola outbreak reaches new areas in Democratic Republic of Congo
Climate catastrophe leaves Nepal mourning while the search for the missing continues
WMO chief says El Nino could be strongest in four decades
SOURCE: Rfi
India's fossil fuel stance shaped by 'a lot of mistrust', Indian activist says
Turkey talks green at COP31 while cracking down on activists
Inside Bunia’s fight to protect families from DRC’s deadliest Ebola outbreak
SOURCE: Rte
Who makes up the board of the Health Service Executive?
Healthcare assistant jailed for sexual assault of patient
New wheelchair centre named after IWA founding member
Teen told gardaí she hit Faulkner with pole, trial hears
Cocaine accounts for more than 50% of admissions - Tiglin
Pedestrian dies after being struck by a car in Limerick
Microsoft offers buyouts to around 60,000 employees
Met police received 'claims' about Meghan Markle's father
Two remain in custody over fatal Waterford arson attack
Pope to leave hospital following lung cancer surgery
€10 rise in State pension likely amid Budget talks
SOURCE: Yle
Finland sending €1m in humanitarian aid for Nepal flash flood victims
SOURCE: ERR
Elderly Jõhvi residents lose free travel on Kohtla-Järve city buses
Service dogs take on greater role as security situation worsens
