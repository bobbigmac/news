SOURCE: Microsoft
Lazare, veni foras: Reprogramming Dormant Neurons to Backdoor AI Agents
From synthetic enterprise data evaluations to real Microsoft Copilot AI confidence

SOURCE: nasa.gov
Dragon Returns to Earth Packed With Science and Cargo
Meghan Saephan
Apply to be a Moonwalker
Honoring NASA’s X-59 Test Pilots on Veterans Day
Episode 186: Supercomputing
CHAPEA Crew Leaves a Mark
Peter B. Tran
Artemis III: Paving the Way to Lunar Landings
SOURCE: science.nasa.gov
NASA Eyes Crop Candidates for Future Menus
Curiosity Blog, Sols 5056-5062: Charging Back Up!
Curiosity Blog, Sols 5050-5055: It’s Nazca, Our 49th Drill Hole
NASA Astrophysics Town Hall, 13 Nov 2026
THIS FRIDAY: ASD Community Meeting

SOURCE: Who
EBOLA BUNDIBUGYO VIRUS DISEASE OUTBREAK Democratic Republic of the Congo | Uganda Weekly External Situation Report 16, Data as of 30 August 2026

SOURCE: Caltech
Caltech Leads NASA Mission to Make the First Deep Ultraviolet All-Sky Maps
