SOURCE: Rt English
Microsoft moves to shed 60,000 employees amid AI spending boom
SOURCE: TASS
Putin surrounded by crowd of leaders in Shenzhen, exchanged few words with many — Kremlin

SOURCE: Aa
Bahrain says its air defenses intercepted multiple Iranian attacks
Former Israeli Prime Minister Bennett’s party backs Eisenkot to form next government

SOURCE: Belta
Chupris reveals details of new amnesty bill tied to Year of Belarusian Woman
Lukashenko submits amnesty bill focusing on women to parliament
Students from Russia, China and African countries design city for desert climates
Support for enterprises, prestige of engineering professions discussed in Vitebsk
Belarus drops requirement for swapping EU trailers carrying diplomatic cargoes
Minsk to host first round of negotiations on Eurasian Charter on 9-11 December
wo golds for Belarus at Open SCO Weightlifting Cup
Belarus, Russia discuss new formats of personnel training for tourism
MP: Warm welcome of Oleshky residents in Belarus is a lesson in humanity and mercy
Oleshky residents cross into Ukraine via Novaya Guta checkpoint

SOURCE: Al Jazeera
DR Congo Ebola cases surpass 12,000 as fighting disrupts response in east
Fossil fuel talks deadlock pushes COP31 climate summit into overtime
Jerusalem Daily: Mass funeral in Gaza as Netanyahu clings to power
Israel’s president picks Eisenkot over Netanyahu to form next government
Why Guinea-Bissau halted a controversial hepatitis vaccine trial for babies
High-ranking US Democratic senator suffers stroke
Health authorities probe two suspected Ebola cases in northeast Nigeria
Dozens killed after Houthi strike on military camp in Shabwa
Russia’s Lavrov to discuss US war and regional security during Tehran visit
Kenya confirms four more Ebola cases, bringing total to seven
Thousands rally for biggest protest in years against Tunisia’s Saied
Bolsonaro favourite to win: What Brazil’s first round of elections tells us
Scientists warn super El Nino could cause 450,000 deaths: Should we worry?
Israeli air attacks on Lebanon kill at least four
Why is Argentina reigniting the Falklands dispute?
Houthi fighters clash with Yemeni government forces in country’s southwest
Israel kills 3 in Gaza as far-right minister plans for Palestinian removals
