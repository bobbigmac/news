SOURCE: New York Times
Bipartisan efforts in Congress to regulate AI are gaining momentum, but they face an uphill climb due to the slow pace of legislative work and turf battles
The Overhead Lighting Debate
Obama Tells Incoming House Democrats to Keep Up Outreach in Red Areas
U.S. Loses Its Measles Elimination Status, a Historic Setback for American Health
Measles Is Officially Back in the United States. What Now?
Do You Need a Measles Booster?
Targeted by U.S., Armed Group Strikes Back in Colombia
Bomb Threats in Europe Probably a Coordinated Campaign, Ireland Says
Rubio Says Elections in Venezuela Would ‘Ideally’ Be Held Next Year
How The New York Times Tracks Election News and Tips
Authorities Capture Convicted Murderer After Weeklong Escape
Ebola Outbreak in Africa Reaches Widest Expansion Ever
Vatican Says Pope Leo Will Leave Hospital on Saturday, Days After Lung Surgery
What to Know About Pope Leo’s Lung Cancer Diagnosis
Unvaccinated Woman Likely Died of Measles Complications, Pa. County Coroner Says

SOURCE: Washington Post
Sources: Pete Hegseth and other Pentagon officials discussed using the Defense Production Act as leverage to pressure Nvidia's board to reinstate Jensen Huang
Pentagon watchdog to audit deals with defense tech start-ups
‘Grand Theft Auto VI′ reportedly passes $1B in sales a week before release
Gwyneth Paltrow goes next-level Goop
SOURCE: Latimes
Mary J. Blige won't let anyone ruin this for her
SOURCE: Time
Why NASA's Artemis III Mission Will Be One of its Most Complex Flights Ever
'The One About Matthew Perry' Is More Than the Typical Saga of Fame and Addiction
Hepatitis B Cases Could Surge Under New Vaccine Guidelines, Study Finds

SOURCE: Seattletimes
5 WA immigrants arrested by ICE during camping trip released on bond
National Guard monitoring ballot boxes in 7 Washington counties

SOURCE: Usatoday
LSU paid for Portal King Lane Kiffin. It got a jester blaming Brian Kelly
Martha Stewart's Halloween costume struck a nerve. Why it missed the mark
Katseye sparks fan backlash after 2 members miss VIP event due to illness
Hegseth fired Nancy Lacore from the Navy. Now he could help her get to Congress
Black unemployment recently spiked. It that a warning for the economy?
Pope Leo XIV promises slow return to papal duties post-surgery
2026 midterm betting odds. See who's favored to win House, Senate
Look up: Dramatic changes are happening on mountaintops
2026 midterm election odds. Who's favored to win the House, Senate?
Chaos in the death chamber: Timeline of Christa Pike's botched execution
SOURCE: Detroitnews
2026 LA Auto Show Top 10: Cybercabs, Elantras, Pod Racers, more
North American Car, Truck and Utility Vehicle of Year finalists set
Trieu: Michigan State in play for 'physical' River Rouge standout
One in three Americans back second execution attempt after failed one, poll finds
SOURCE: Nwfdailynews
'Dancing With the Stars' season 35 finale: Amber Glenn, Pasha Pashkov
Northwest Florida Daily News: Local News, Politics & Sports in Fort Walton Beach, FL
Florida ground stop live updates: FAA grounds flights nationwide
Watch live: Airports, flights affected by nationwide FAA ground stop
'Advocating for children': Incumbent, newcomer win Lee School Board
Voters say 'yes' to single-member districts for Lee County - The News-Press
Patronis defeats Valimont to retain U.S. District 1 congressional seat - Pensacola News Journal
SOURCE: Onlineathens
Stonehill Challenges Traditional Organizational Design as Companies Rethink How Work Gets Done
Officer Fires at Vehicle Fleeing Traffic Stop in Winterville - Online Athens
Georgia basketball coach Mike White gives his take on subpar opening win - Online Athens
Check out our Georgia basketball vs. NC Central photo gallery: Best images - Online Athens
Check out our Georgia WBB vs. West Georgia photo gallery: Best images - Online Athens
No bad surprises for Georgia WBB, Ayla Guzzardo's first game - Online Athens
See Athens-area high school teams in GHSA cross country finals here
Vote for Piedmont Athens Regional high school athlete of the week: Nov. 2
Ariana Designs & Interiors Explains Why Beautiful Rooms Still Feel Wrong - Online Athens
Former 'Bachelor' host Chris Harrison to premiere new show in Athens
What is Georgia voting for today? See the major 2026 midterm elections
Midterm elections: Ossoff vs. Collins, Bottoms vs. Jackson | Live Updates
Georgia governor race sees Jackson, Bottoms raise $150 million - The Augusta Chronicle
Among the 12 best Christmas destinations in US, this GA town makes list
'I thought we played pretty bad': Georgia basketball blunt on opening win
Prosecutor in Elijah Wood murder case earns national DOJ honor - Online Athens
Port Everglades CEO outlines $1.7 billion in potential cruise investments - Online Athens
SOURCE: Palmbeachpost
Overturned fuel tanker closes portion of Florida highway

SOURCE: Miamiherald
U2 creates magic in Thanksgiving Eve halftime with Dolly Parton tribute
Grand Theft Auto VI Launch Guide: Jason And Lucia, Leonida, Pre-Load, Ultimate Edition, And What We Still Don't Know
Xbox Turns 25: A Look Back At Halo, Xbox Live, Game Pass, And What Comes Next
10 Early Black Friday 2026 Deals You Should Know About
It's getting closer. GTA 6 to start preloading onto consoles Tuesday
The IKEA and Xbox Collab Just Dropped Heavy-Duty Gaming Furniture for Grown-Ups
SOURCE: Kentucky
See when newly elected Kentucky officials start their terms
Disc golf players rejoice: Lexington opens new course after 5 years of delays
After 3rd win, what’s on Lexington Mayor Linda Gorton’s to-do list for the next 4 years?
When do Kentucky’s newly elected officials take office? Here are key dates
Lexington council, mayor, judge school board and more: Our coverage of local results
Linda Gorton wins third term as Lexington mayor. Why it’s historic.
Fact Check: What would Gorton, Carter do to increase housing in Lexington?
Carter leads Gorton in fundraising in Lexington’s mayors race. See the numbers
SOURCE: Modbee
Turlock Mayor Bublak leads Reape in early election results. Council incumbents also ahead
Driver reported hitting a deer in North Carolina. Police say it was a man checking a flat tire
One victim lost over $219,000 in a California food truck scam. The total: $1.5M
SOURCE: Idahostatesman
Sam's Club prepares for its final opening of 2026. See where | Idaho Statesman
SOURCE: Thenewstribune
Sam's Club prepares for its final opening of 2026. See where | Tacoma News Tribune
SOURCE: Kansas
Wichita police identify victim in deadly south-side shooting

SOURCE: Courant
Russell Richardson Obituary | October 18, 2026 | Hartford Courant
Allen Schindler Obituary | October 10, 2026 | Hartford Courant
Thomas Rathier Obituary | October 19, 2026 | Hartford Courant
Kelly O'Dwyer Obituary | October 19, 2026 | Hartford Courant
Vernon Wells Obituary | October 17, 2026 - Hartford Courant
Marianne Moore Obituary | September 22, 2026 | Hartford Courant
Patricia Dupuy Ruth Rees OBITUARY - Hartford Courant
Sandra Chevrette Obituary | October 15, 2026 | Hartford Courant
Ann Fastiggi Obituary | October 17, 2026 - Hartford Courant
David Palaski Obituary | September 19, 2026 - Hartford Courant
Lawrence Ryan Obituary | October 20, 2026 | Hartford Courant
Thomas Brown Obituary | October 3, 2026 | Hartford Courant
Eleanor Kyc Obituary | October 21, 2026 - Hartford Courant
Margarite Monterosso-Hunt Obituary | October 22, 2026 - Hartford Courant
Sandra McGarrah Obituary | October 13, 2026 - Hartford Courant
Thomas Connors Obituary | October 19, 2026 | Hartford Courant
Halloween candy sales are off to a slow start amid high chocolate prices and affordability concerns
Top Democrats and allies join the wealthiest to fight a California billionaire tax
SOURCE: Chicagotribune
Judge slaps DOJ effort to derail ‘Broadview Six’ hearing, calls AG’s evidence production ‘noncompliant’
SOURCE: Nydailynews
Democrat Scott Colom on brink of winning Mississippi Senate race after big update

SOURCE: Sfgate
Airbnb guests no longer have to wash the dishes or strip the beds at checkout
SOURCE: Timesunion
How to save on Grand Theft Auto VI: Deals on PlayStation and Xbox gift cards
Democrats are weighing impeachment of RFK Jr. while courting his supporters
Mopco Improv Theatre celebrates 10 years at its Jay Street home

SOURCE: Oregonlive
Jerry Small Obituary (1937 - 2026) - Stanwood, WA - Skagit Valley Herald - Legacy
Matthew Ainslie Obituary (1983 - 2026) - Schenectady, NY - WKTV - Legacy
Russell Houppert Obituary (1936 - 2026) - Lowville, NY - WKTV - Legacy
Stacy Lynn Flint Obituary (1972 - 2026) - East Stroudsburg, PA - WFMZ-TV 69 News
Gregory Paul "Poppy" Apted Obituary (1960 - 2026) - Summerville, SC - Charleston Post & Courier
William Armstrong Obituary (2026) - Grand Rapids, MI
David Gallob Obituary (1938 - 2026) - Crawford, CO - Delta County Independent - Legacy
James M. Miller Obituary (2026) - Allentown, PA - WFMZ-TV 69 News - Legacy
Joan L. Palm Obituary (2026) - Quakertown, PA - WFMZ-TV 69 News - Legacy
Brenda W. Carl Obituary (1944 - 2026) - Reading, PA - WFMZ-TV 69 News - Legacy
Samuel Fritzlan Obituary (1959 - 2026) - Paonia, CO - Delta County Independent - Legacy
Marilyn L. Andrews Obituary (1938 - 2026) - Marion, OH - Crawford County Now - Legacy
James F. Young Obituary (1937 - 2026) - West Reading, PA - WFMZ-TV 69 News - Legacy
Jennifer James Obituary (05/13/1984 - 10/31/2026) - Walker, Michigan, MI
James Muller Obituary (1953 - 2026) - Whitesboro, NY - WKTV - Legacy
Edward Fadeley Obituary (1958 - 2026) - Oneida, NY - WKTV - Legacy
Christine Cacozza Obituary (1950 - 2026) - Utica, NY - WKTV - Legacy
Lawrence Loffredo Obituary (1933 - 2026) - Cazenovia, NY - WKTV - Legacy
Teddy Green Obituary (2026) - Fountain Inn, SC - Post and Courier - Greenville
Jennifer J. Gorman Obituary (1966 - 2026) - East Greenville, PA - WFMZ-TV 69 News
Debra Ann Libutti Obituary (1954 - 2026) - Easton, PA - WFMZ-TV 69 News - Legacy
Shawn Andre Lewis Obituary (1965 - 2026) - Cincinnati, OH - LINK nky - Legacy
Dorienne Sorter Obituary (1933 - 2026) - South Egremont, MA - The Berkshire Eagle
Juanita Strain Obituary (1930 - 2026) - Washington Court House, OH - Record Herald
Joan W. Sell Obituary (1937 - 2026) - Hellertown, PA - WFMZ-TV 69 News - Legacy
Rebecca Parker Obituary (06/06/1944 - 10/16/2026) - West Linn, OR - The Oregonian
Fred A. Lindenmuth Jr. Obituary (1931 - 2026) - Frackville, PA - WFMZ-TV 69 News - Legacy
Carol Alexander Obituary (2026) - Kendallville, IN - KPCNews - Legacy
Patricia Salcido Obituary (1934 - 2026) - Alamogordo, NM - Legacy
SOURCE: Lehighvalleylive
BrüMate's newest tumblers trade basic Christmas prints for festive plaid and bows
Navy splits $7.1 billion ship-defense job between 28 companies - lehighvalleylive.com
When will Medicare costs increase? Early 2027 premium predictions - MassLive.com
Separate boat capsizings near Greece kill 12 migrants, including infant - Lehigh Valley Live
4th measles-related death reported in Pa., an 18-year-old - PennLive.com
Pa. breaks another measles milestone as cases top 600 - PennLive.com

SOURCE: Wltx
Vatican says Pope Leo to be released from the hospital Saturday, 4 days after lung cancer surgery

SOURCE: Wivb
Wayfair to open Amherst storefront in 2028
SOURCE: Keloland
Stephanie Herseth Sandlin reflects upon father's legacy
SOURCE: Wkrg
MORE DETAILS: Semmes mom slaps, points gun at 12-year-old boy after he got off bus
One dead after vehicle enters water in Escambia County, Florida
SOURCE: Wreg
U of MS says investigation into racist video will continue, addresses another racial incident
SOURCE: Wwlp
Holyoke Mall welcomes Santa for holiday season
Firefighters dig through rubble after NYC building collapse kills 2 and traps people in wreckage
New respiratory health initiative targets asthma in these western Mass. cities

SOURCE: Denver7
First look at Grand Theft Auto 6 gameplay released on Netflix ahead of November launch
SOURCE: Kjrh
First look at Grand Theft Auto 6 gameplay released on Netflix ahead of November launch

SOURCE: Kait8
Pyke scores 20 as Arkansas State defeats Southern Utah 104-102 - KAIT
Why Eversource says it needs a rate hike
Jackson firefighters investigate business fire on Richardson Drive
Don't feel like cooking? Here's what's open on Thanksgiving
Memphis Zoo bonobos being moved out of Memphis - KAIT
Over 6K without power in Greenville County
Delta says system restored after tech issue causes flight delays at Atlanta airport
A-State falls to North Texas in opening game of Hoopfest Challenge, 71-74 - KAIT
Woman allegedly killed by husband texted sister she was 'not good' days before her body was found
Allegedly impaired driver strikes group of cyclists, killing 1 and injuring 20 others - KAIT
#2 Harding rushes for 684 yards, clinches 4th straight GAC title - KAIT
Hero dog who was shot twice saving his owner from her ex now needs surgery - KAIT
Cornell faculty votes 'no confidence' in president over handling of sexual assault allegations
A-State falls to Florida Gulf Coast on the road 89-59 - KAIT
Robot Gladiator League competition held at Dunbar High School - KEYC
Hoxie alum Shunderrick Powell advances to Grey Cup - KAIT
Child allegedly fires gun during family disturbance at Canby apartments - WIS
Federal agents search Rep. Ilhan Omar's home as part of a criminal investigation, AP sources say

SOURCE: Nbcnews
NY Gov. Kathy Hochul signs a bill banning AI chatbot toys for five years, starting in February; California Gov. Gavin Newsom signed a four-year ban in September
Flight disruptions follow nationwide ground stop, and SpaceX makes history: Weekend Rundown
SOURCE: CNBC
S&P 500 correction: Five forces behind the market sell-off
U.S. officially loses measles elimination status amid ongoing outbreaks
Measles is surging in the U.S. — and outbreaks can cost millions
Israel’s president taps opposition candidate Eisenkot to form a government, in setback for Netanyahu
Strand bookstore to pay nearly $1.5 million over Covid loan tied to Sen. Wyden's wife
We're raising our price target on Eli Lilly as the obesity-drug boom rolls on
We're cutting our Amazon price target after a rough quarter. But it isn't all bad
SOURCE: Eonline
Why JWoww Is "Holding on for Dear Life" With 12-Year-Old Daughter Meilani

SOURCE: Abcnews
US officially loses measles elimination status, PAHO says
New York state reports measles-associated death in child amid outbreak
SOURCE: 6abc
Philadelphia City Council examines foster care oversight after Malayshia Allford's death
Calling out sick for GTA 6 release? XBOX, DJ Khaled have your doctor's note for video game players
Gunman sought after man shot multiple times in Philadelphia's Cobbs Creek section
Public health advocate says Pennsylvania measles surge is a warning sign
SOURCE: Abc7ny
Driver in suspected abduction rams vehicles, before being shot and killed by police on Belt Parkway in Brooklyn, New York
Fire in industrial tunnel used by Con Edison sends up smoke
Vigil held for slain Brooklyn jogger as search continues for killer: 'We are praying for them'

SOURCE: CBS News
Investigation: Nvidia sells its most advanced chips to at least two Chinese-owned California companies, which have leased or sold some of them to firms in Asia
Scientist fired after 6-year-old girl dies in gene-editing trial
Doctor says U.S. losing measles elimination status is a "huge public health failure"
Dr. Deborah Birx on U.S. loss of measles elimination status
Billy Evans on "You Can See Everything"
Billy Evans tells his side of "You Can See Everything"
The sinking of the SS United States
Man in his 70s diagnosed with heart defect usually found in infancy
Detroit transit officials call horses on bus an opportunity to retrain transit operators
Bolton reacts to Iran threats as Bessent is forced to live in military base
How men can guard against prostate cancer
GLP-1s must now include warning for potential increased risk of vision loss, FDA announces
FDA warns of rare vision-loss side effect from GLP-1 drugs
Nvidia investigates CEO Jensen Huang amid allegations he was target of Chinese intelligence effort
No one knew why a dad couldn't eat. Then a surgeon took a second look.
Almanac: November 1
Midterm elections preview: How might this year's vote change Washington?
What the Cameras Saw | Post Mortem
She spent 18 years believing she had MS. Then her diagnosis changed.
What early voting numbers tell us about the midterms as campaigns make final push
Department of Justice investigating Alaska Senate race just days ahead of midterms
Linda Mason, CBS News veteran and trailblazing journalist, dies at age 84
France vows to crack down after protests spiral out of control
Pope's surgeon details operating on "ideal patient" after lung cancer discovered
Pope Leo resumes some papal duties after surgery, Vatican says
Pope Leo XIV's brother Louis Prevost also battling cancer, wife tells CBS News
Pope Leo hospitalized ahead of surgery on lung nodule
Breaking down the latest midterm polls with Democrats threatening in GOP strongholds
Russian foreign minister accuses Europe of blocking Ukraine peace talks

SOURCE: Sky News
Driver suspected of causing tanker crash in Egypt that killed 31 detained
Airline suspends all flights - as carrier faces bankruptcy
Crest Nicholson chair to step down amid urgent lender talks
'I'd lost the plot': Disgraced Huw Edwards speaks in 'important' new film
Security incident reported at Royal Navy headquarters
Charity set up in honour of Princess Diana placed into administration
Myanmar says it will not comply with 'inappropriate' ICJ genocide orders
Channel 4 in talks to sell London HQ to property group Socius
Dubai wholesaler plans renewed bid for collapsed Poundland
UK writes to veterans to ready them for possibility of mobilisation
'Biggest shake-up of stalking laws in over a decade' unveiled
UK net migration falls to lowest level in three decades, excluding pandemic
Best 0% credit offers for Black Friday purchases
Major US tech index is on brink of crashing into a bear market
Child homelessness increases chance of being NEET, study says
Britain's weather could be about to feel very different, Met Office warns
Simon Le Bon pays tribute to Duran Duran guitarist Andy Taylor
Body found after man charged with murder of young woman
Stadium-sized crater left in asteroid after NASA 'Earth protection test'
US authorises SpaceX to deploy one million satellites to space
Asylum hotels, visas, arrivals: Test your migration knowledge
Poundland insolvency: What went wrong and what next?
Serial rapist who preyed on women in UK and abroad jailed for 17 years
Eurostar trains cancelled and delayed over 'unannounced strike action'
Two men appear in court accused of stealing cufflinks and a clock from William and Kate's home
Multiple chances missed to protect two-year-old murdered by his grandparents, report finds
Two children among six dead in plane crash
'Misperceptions' on immigration widespread among public, study finds
Colombian police storm supermarket, freeing hostages and killing gunman
Huawei guilty of plotting to steal trade secrets and bank fraud
Thomas Markle formally charged over child sexual abuse material
Anthropic plunges below IPO price in renewed tech sell-off
US investor Staple Street backs last-gasp German bid for Poundland
Former NatWest chief Rose to leave fintech FNZ
High street lender launches 'bank of mum and dad' mortgage - but there's a catch
Four in five Black Friday deals are duds, research finds
Morocco 'astonished' at decision to restore Senegal as Africa Cup of Nations champions
Murder investigation launched as woman, 80, dies after being set on fire
Hacker sentenced for leaking Grand Theft Auto VI clips
Badenoch and Farage: The battle for business
Major trial to examine if AI can help detect breast cancer earlier
Britain's next fighter jet could be last with a pilot in the cockpit, says RAF chief
NHS warns of 'alarming' rise in hospital admissions for 'silent killer'
Anthropic among big fallers in global stock market rout
EU reveals it suffered 'AI-powered' cyber attack
AI 'highly likely' to be used in attack on Britain's infrastructure
Pope makes public appearance a day after being discharged from hospital following lung cancer surgery
Pope Leo to leave hospital today after lung cancer surgery, the Vatican says
